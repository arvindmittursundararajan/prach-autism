/**
 * BCBA Clinical Assistant Platform
 * Media Player component for audio/video playback
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize Plyr for advanced media controls if available
    if (typeof Plyr !== 'undefined') {
        // Initialize audio players
        const audioPlayers = document.querySelectorAll('.audio-player');
        if (audioPlayers.length > 0) {
            audioPlayers.forEach(player => {
                new Plyr(player, {
                    controls: [
                        'play', 
                        'progress', 
                        'current-time', 
                        'mute', 
                        'volume',
                        'settings',
                        'pip'
                    ],
                    storage: { enabled: false },
                    speed: { selected: 1, options: [0.5, 0.75, 1, 1.25, 1.5, 2] }
                });
            });
        }
        
        // Initialize video players
        const videoPlayers = document.querySelectorAll('.video-player');
        if (videoPlayers.length > 0) {
            videoPlayers.forEach(player => {
                new Plyr(player, {
                    controls: [
                        'play-large', 
                        'play', 
                        'progress', 
                        'current-time', 
                        'mute', 
                        'volume', 
                        'settings', 
                        'fullscreen'
                    ],
                    storage: { enabled: false },
                    speed: { selected: 1, options: [0.5, 0.75, 1, 1.25, 1.5, 2] }
                });
            });
        }
    } else {
        // Fallback to basic HTML5 media controls
        console.log('Plyr not found, using native media controls');
    }
    
    // Add playback speed controls for native players if Plyr is not available
    const mediaElements = document.querySelectorAll('audio, video');
    mediaElements.forEach(media => {
        // Check if not already enhanced by Plyr
        if (!media.closest('.plyr')) {
            const container = media.parentElement;
            const speedControl = document.createElement('select');
            speedControl.className = 'form-select form-select-sm mt-2';
            speedControl.innerHTML = `
                <option value="0.5">0.5x</option>
                <option value="0.75">0.75x</option>
                <option value="1" selected>1x (Normal)</option>
                <option value="1.25">1.25x</option>
                <option value="1.5">1.5x</option>
                <option value="2">2x</option>
            `;
            
            speedControl.addEventListener('change', function() {
                media.playbackRate = parseFloat(this.value);
            });
            
            container.appendChild(speedControl);
        }
    });
    
    // Add timestamps to recordings with data-duration attribute
    const recordings = document.querySelectorAll('[data-duration]');
    recordings.forEach(recording => {
        const duration = parseInt(recording.getAttribute('data-duration'), 10);
        if (duration && !isNaN(duration)) {
            const timestamp = document.createElement('div');
            timestamp.className = 'recording-timestamp text-muted mt-1';
            
            // Format duration
            const minutes = Math.floor(duration / 60);
            const seconds = duration % 60;
            timestamp.textContent = `Duration: ${minutes}:${seconds.toString().padStart(2, '0')}`;
            
            recording.appendChild(timestamp);
        }
    });
    
    // Handle audio waveform displays if Web Audio API is available
    if (window.AudioContext || window.webkitAudioContext) {
        const waveformContainers = document.querySelectorAll('.waveform-container');
        waveformContainers.forEach(container => {
            const audioElement = container.previousElementSibling;
            if (audioElement && audioElement.tagName === 'AUDIO') {
                createWaveform(audioElement, container);
            }
        });
    }
});

/**
 * Create a simple visualization waveform for audio
 * @param {HTMLElement} audioElement - The audio element
 * @param {HTMLElement} container - The container for the waveform
 */
function createWaveform(audioElement, container) {
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    const audioContext = new AudioContext();
    const analyser = audioContext.createAnalyser();
    analyser.fftSize = 256;
    
    const canvas = document.createElement('canvas');
    canvas.width = container.clientWidth;
    canvas.height = 80;
    container.appendChild(canvas);
    
    const canvasCtx = canvas.getContext('2d');
    canvasCtx.fillStyle = '#f5f7fa';
    canvasCtx.fillRect(0, 0, canvas.width, canvas.height);
    
    // Connect the audio element to the analyser
    const source = audioContext.createMediaElementSource(audioElement);
    source.connect(analyser);
    analyser.connect(audioContext.destination);
    
    // Get frequency data
    const bufferLength = analyser.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);
    
    // Draw the waveform
    function draw() {
        requestAnimationFrame(draw);
        
        analyser.getByteFrequencyData(dataArray);
        
        canvasCtx.fillStyle = '#f5f7fa';
        canvasCtx.fillRect(0, 0, canvas.width, canvas.height);
        
        const barWidth = (canvas.width / bufferLength) * 2.5;
        let barHeight;
        let x = 0;
        
        for (let i = 0; i < bufferLength; i++) {
            barHeight = dataArray[i] / 2;
            
            canvasCtx.fillStyle = `rgb(33, 150, 243, ${dataArray[i] / 255})`;
            canvasCtx.fillRect(x, canvas.height - barHeight, barWidth, barHeight);
            
            x += barWidth + 1;
        }
    }
    
    // Start visualization when audio plays
    audioElement.addEventListener('play', function() {
        if (audioContext.state === 'suspended') {
            audioContext.resume();
        }
        draw();
    });
}

/**
 * Capture screenshot from video
 * @param {string} videoId - ID of the video element
 * @param {string} canvasId - ID of the canvas to capture to
 */
function captureVideoFrame(videoId, canvasId) {
    const video = document.getElementById(videoId);
    const canvas = document.getElementById(canvasId);
    
    if (!video || !canvas) return;
    
    const ctx = canvas.getContext('2d');
    
    // Set canvas dimensions to match video
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    
    // Draw the current video frame
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    
    // Show the canvas
    canvas.classList.remove('d-none');
    
    // Optionally convert to image data URL
    const imageDataUrl = canvas.toDataURL('image/png');
    
    // Create capture info
    const captureInfo = document.createElement('div');
    captureInfo.className = 'capture-info mt-2';
    captureInfo.innerHTML = `
        <div class="alert alert-success">
            <strong>Frame captured!</strong> 
            <button class="btn btn-sm btn-outline-primary ms-2" id="downloadCapture">Download</button>
        </div>
    `;
    
    // Replace any existing capture info
    const existingInfo = document.querySelector('.capture-info');
    if (existingInfo) {
        existingInfo.remove();
    }
    
    canvas.parentElement.appendChild(captureInfo);
    
    // Add download handler
    document.getElementById('downloadCapture').addEventListener('click', function() {
        const link = document.createElement('a');
        link.download = `capture_${new Date().toISOString().replace(/:/g, '-')}.png`;
        link.href = imageDataUrl;
        link.click();
    });
}

/**
 * Add a note to media at current timestamp
 * @param {string} mediaId - ID of the media element
 * @param {string} noteInputId - ID of the note input element
 */
function addMediaNote(mediaId, noteInputId) {
    const media = document.getElementById(mediaId);
    const noteInput = document.getElementById(noteInputId);
    
    if (!media || !noteInput) return;
    
    const currentTime = media.currentTime;
    const noteText = noteInput.value.trim();
    
    if (!noteText) {
        alert('Please enter a note before adding.');
        return;
    }
    
    // Format timestamp
    const minutes = Math.floor(currentTime / 60);
    const seconds = Math.floor(currentTime % 60);
    const timestamp = `${minutes}:${seconds.toString().padStart(2, '0')}`;
    
    // Create note element
    const noteElement = document.createElement('div');
    noteElement.className = 'media-note p-2 mb-2 border-start border-primary border-3';
    noteElement.innerHTML = `
        <div class="d-flex justify-content-between">
            <strong class="text-primary">${timestamp}</strong>
            <button class="btn btn-sm text-danger" onclick="this.parentElement.parentElement.remove()">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <p class="mb-0">${noteText}</p>
        <button class="btn btn-sm btn-link p-0" onclick="document.getElementById('${mediaId}').currentTime=${currentTime}">
            Jump to timestamp
        </button>
    `;
    
    // Add note to notes container
    const notesContainer = document.querySelector('.media-notes-container');
    notesContainer.appendChild(noteElement);
    
    // Clear input
    noteInput.value = '';
}
