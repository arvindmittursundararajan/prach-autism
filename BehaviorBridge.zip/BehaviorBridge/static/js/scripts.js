/**
 * BCBA Clinical Assistant Platform
 * Main JavaScript file for UI interactions
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Initialize popovers
    const popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    popoverTriggerList.map(function(popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });

    // Toggle sidebar on mobile
    const toggleSidebar = document.getElementById('toggleSidebar');
    if (toggleSidebar) {
        toggleSidebar.addEventListener('click', function() {
            document.querySelector('.sidebar').classList.toggle('active');
        });
    }

    // Handle data upload form
    const dataUploadForm = document.getElementById('dataUploadForm');
    if (dataUploadForm) {
        const entryTypeSelect = document.getElementById('entryType');
        const textContentDiv = document.getElementById('textContentDiv');
        const mediaFileDiv = document.getElementById('mediaFileDiv');
        
        // Show/hide form fields based on entry type
        entryTypeSelect.addEventListener('change', function() {
            if (this.value === 'text') {
                textContentDiv.classList.remove('d-none');
                mediaFileDiv.classList.add('d-none');
            } else {
                textContentDiv.classList.add('d-none');
                mediaFileDiv.classList.remove('d-none');
            }
        });
    }

    // Handle treatment plan form
    const treatmentPlanForm = document.getElementById('treatmentPlanForm');
    if (treatmentPlanForm) {
        const startDateInput = document.getElementById('startDate');
        const endDateInput = document.getElementById('endDate');
        
        // Ensure end date is after start date
        startDateInput.addEventListener('change', function() {
            endDateInput.min = this.value;
        });
    }

    // Patient search functionality
    const patientSearchInput = document.getElementById('patientSearch');
    if (patientSearchInput) {
        patientSearchInput.addEventListener('input', function() {
            const searchValue = this.value.toLowerCase();
            const patientItems = document.querySelectorAll('.patient-item');
            
            patientItems.forEach(item => {
                const patientName = item.querySelector('.patient-name').textContent.toLowerCase();
                const patientInfo = item.querySelector('.patient-info').textContent.toLowerCase();
                
                if (patientName.includes(searchValue) || patientInfo.includes(searchValue)) {
                    item.style.display = '';
                } else {
                    item.style.display = 'none';
                }
            });
        });
    }

    // Handle file inputs with custom file names display
    const fileInputs = document.querySelectorAll('.custom-file-input');
    fileInputs.forEach(input => {
        input.addEventListener('change', function(e) {
            const fileName = this.files[0].name;
            const label = this.nextElementSibling;
            label.textContent = fileName;
        });
    });

    // Confirmation dialogs
    const confirmActions = document.querySelectorAll('[data-confirm]');
    confirmActions.forEach(button => {
        button.addEventListener('click', function(e) {
            const message = this.getAttribute('data-confirm');
            if (!confirm(message)) {
                e.preventDefault();
            }
        });
    });

    // Dynamic tab storage in URL
    const tabElements = document.querySelectorAll('a[data-bs-toggle="tab"]');
    tabElements.forEach(tabEl => {
        tabEl.addEventListener('shown.bs.tab', function(e) {
            const hash = new URL(e.target.href).hash;
            if (history.pushState) {
                history.pushState(null, null, hash);
            } else {
                location.hash = hash;
            }
        });
    });

    // If URL has a hash (tab ID), activate that tab
    const hash = window.location.hash;
    if (hash) {
        const tabTrigger = document.querySelector(`a[data-bs-toggle="tab"][href="${hash}"]`);
        if (tabTrigger) {
            new bootstrap.Tab(tabTrigger).show();
        }
    }
});

/**
 * Format date for display
 * @param {string} dateString - Date string to format
 * @returns {string} Formatted date string
 */
function formatDate(dateString) {
    const options = { year: 'numeric', month: 'short', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
}

/**
 * Format time for display
 * @param {string} dateTimeString - DateTime string to format
 * @returns {string} Formatted time string
 */
function formatTime(dateTimeString) {
    const options = { hour: '2-digit', minute: '2-digit' };
    return new Date(dateTimeString).toLocaleTimeString(undefined, options);
}

/**
 * Show notification to user
 * @param {string} message - Message to show
 * @param {string} type - Type of notification (success, danger, warning, info)
 */
function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `alert alert-${type} alert-dismissible fade show position-fixed top-0 end-0 m-3`;
    notification.setAttribute('role', 'alert');
    notification.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    `;
    
    document.body.appendChild(notification);
    
    // Auto-dismiss after 5 seconds
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 150);
    }, 5000);
}
