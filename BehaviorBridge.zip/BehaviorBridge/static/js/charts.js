/**
 * BCBA Clinical Assistant Platform
 * Charts and data visualization components
 */

/**
 * Create patient progress chart
 * @param {string} canvasId - ID of canvas element
 * @param {array} labels - Array of labels for x-axis
 * @param {array} data - Array of data points
 */
function createPatientProgressChart(canvasId, labels, data) {
    const ctx = document.getElementById(canvasId).getContext('2d');
    
    // Define chart
    const progressChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'Progress Score',
                data: data,
                backgroundColor: 'rgba(33, 150, 243, 0.2)',
                borderColor: '#2196F3',
                borderWidth: 2,
                tension: 0.3,
                pointBackgroundColor: '#2196F3',
                pointBorderColor: '#fff',
                pointRadius: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            layout: {
                padding: {
                    top: 10,
                    right: 25,
                    bottom: 10,
                    left: 10
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    grid: {
                        color: 'rgba(0, 0, 0, 0.05)'
                    }
                },
                x: {
                    grid: {
                        display: false
                    }
                }
            },
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    backgroundColor: '#333',
                    titleColor: '#fff',
                    bodyColor: '#fff',
                    borderColor: '#2196F3',
                    borderWidth: 1,
                    displayColors: false,
                    callbacks: {
                        label: function(context) {
                            return `Score: ${context.raw}%`;
                        }
                    }
                }
            }
        }
    });
    
    return progressChart;
}

/**
 * Create data entry distribution chart
 * @param {string} canvasId - ID of canvas element
 */
function createDataDistributionChart(canvasId) {
    const ctx = document.getElementById(canvasId).getContext('2d');
    
    // Define chart
    const distributionChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Text Entries', 'Audio Recordings', 'Video Recordings'],
            datasets: [{
                data: [65, 20, 15],
                backgroundColor: [
                    '#2196F3', // Primary blue
                    '#4CAF50', // Secondary green
                    '#FF9800'  // Accent orange
                ],
                borderColor: '#fff',
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            layout: {
                padding: 5
            },
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        padding: 15,
                        boxWidth: 12
                    }
                },
                tooltip: {
                    backgroundColor: '#333',
                    titleColor: '#fff',
                    bodyColor: '#fff',
                    displayColors: true,
                    callbacks: {
                        label: function(context) {
                            return `${context.label}: ${context.raw}%`;
                        }
                    }
                }
            },
            cutout: '65%'
        }
    });
    
    return distributionChart;
}

/**
 * Create patient data count chart
 * @param {string} canvasId - ID of canvas element
 * @param {array} patientNames - Array of patient names
 * @param {array} dataCounts - Array of data entry counts
 */
function createPatientDataCountChart(canvasId, patientNames, dataCounts) {
    const ctx = document.getElementById(canvasId).getContext('2d');
    
    // Define chart
    const dataCountChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: patientNames,
            datasets: [{
                label: 'Data Entries',
                data: dataCounts,
                backgroundColor: 'rgba(33, 150, 243, 0.7)',
                borderColor: '#2196F3',
                borderWidth: 1,
                borderRadius: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            layout: {
                padding: {
                    top: 10,
                    right: 15,
                    bottom: 10,
                    left: 10
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        color: 'rgba(0, 0, 0, 0.05)'
                    },
                    ticks: {
                        precision: 0
                    }
                },
                x: {
                    grid: {
                        display: false
                    }
                }
            },
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    backgroundColor: '#333',
                    titleColor: '#fff',
                    bodyColor: '#fff',
                    callbacks: {
                        label: function(context) {
                            const count = context.raw;
                            return `${count} ${count === 1 ? 'entry' : 'entries'}`;
                        }
                    }
                }
            }
        }
    });
    
    return dataCountChart;
}

/**
 * Create treatment progress comparison chart
 * @param {string} canvasId - ID of canvas element
 */
function createTreatmentComparisonChart(canvasId) {
    const ctx = document.getElementById(canvasId).getContext('2d');
    
    // Define chart
    const comparisonChart = new Chart(ctx, {
        type: 'radar',
        data: {
            labels: ['Communication', 'Social Skills', 'Self-Regulation', 'Academic', 'Motor Skills', 'Self-Care'],
            datasets: [
                {
                    label: 'Current Progress',
                    data: [65, 70, 45, 80, 60, 75],
                    backgroundColor: 'rgba(33, 150, 243, 0.2)',
                    borderColor: '#2196F3',
                    borderWidth: 2,
                    pointBackgroundColor: '#2196F3',
                    pointBorderColor: '#fff'
                },
                {
                    label: 'Initial Assessment',
                    data: [30, 40, 20, 50, 40, 45],
                    backgroundColor: 'rgba(255, 152, 0, 0.2)',
                    borderColor: '#FF9800',
                    borderWidth: 2,
                    pointBackgroundColor: '#FF9800',
                    pointBorderColor: '#fff'
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            layout: {
                padding: {
                    top: 5,
                    right: 15,
                    bottom: 15,
                    left: 5
                }
            },
            scales: {
                r: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        display: false
                    },
                    grid: {
                        color: 'rgba(0, 0, 0, 0.1)'
                    },
                    angleLines: {
                        color: 'rgba(0, 0, 0, 0.1)'
                    },
                    pointLabels: {
                        font: {
                            size: 11
                        }
                    }
                }
            },
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        padding: 15,
                        boxWidth: 12,
                        font: {
                            size: 11
                        }
                    }
                },
                tooltip: {
                    backgroundColor: '#333',
                    titleColor: '#fff',
                    bodyColor: '#fff',
                    callbacks: {
                        label: function(context) {
                            return `${context.dataset.label}: ${context.raw}%`;
                        }
                    }
                }
            }
        }
    });
    
    return comparisonChart;
}

// Initialize charts when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Patient Progress Chart
    const progressChartElement = document.getElementById('patientProgressChart');
    if (progressChartElement) {
        const labels = ['Week 1', 'Week 2', 'Week 3', 'Week 4', 'Week 5', 'Week 6', 'Week 7', 'Week 8'];
        const data = [25, 40, 35, 50, 55, 70, 65, 80];
        createPatientProgressChart('patientProgressChart', labels, data);
    }
    
    // Data Distribution Chart
    const dataDistributionElement = document.getElementById('dataDistributionChart');
    if (dataDistributionElement) {
        createDataDistributionChart('dataDistributionChart');
    }
    
    // Patient Data Count Chart
    const dataCountElement = document.getElementById('patientDataCountChart');
    if (dataCountElement) {
        // Get data from the data attributes (populated from Flask)
        const patientNames = JSON.parse(dataCountElement.getAttribute('data-patient-names') || '[]');
        const dataCounts = JSON.parse(dataCountElement.getAttribute('data-counts') || '[]');
        
        if (patientNames.length > 0 && dataCounts.length > 0) {
            createPatientDataCountChart('patientDataCountChart', patientNames, dataCounts);
        }
    }
    
    // Treatment Comparison Chart
    const treatmentComparisonElement = document.getElementById('treatmentComparisonChart');
    if (treatmentComparisonElement) {
        createTreatmentComparisonChart('treatmentComparisonChart');
    }
});
