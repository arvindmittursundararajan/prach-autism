from datetime import datetime
import json
from app import db, login_manager
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

class User(UserMixin, db.Model):
    """User model for BCBAs and staff"""
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256))
    first_name = db.Column(db.String(64), nullable=False)
    last_name = db.Column(db.String(64), nullable=False)
    role = db.Column(db.String(20), nullable=False)  # BCBA, RBT, Admin
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    patients = db.relationship('Patient', backref='therapist', lazy='dynamic')
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
        
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def __repr__(self):
        return f'<User {self.username}>'

class Patient(db.Model):
    """Patient model"""
    id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String(64), nullable=False)
    last_name = db.Column(db.String(64), nullable=False)
    date_of_birth = db.Column(db.Date, nullable=False)
    gender = db.Column(db.String(10))
    guardian_name = db.Column(db.String(128))
    guardian_contact = db.Column(db.String(20))
    diagnosis = db.Column(db.String(255))
    notes = db.Column(db.Text)
    therapist_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    data_entries = db.relationship('DataEntry', backref='patient', lazy='dynamic')
    treatment_plans = db.relationship('TreatmentPlan', backref='patient', lazy='dynamic')
    
    def __repr__(self):
        return f'<Patient {self.first_name} {self.last_name}>'

class DataEntry(db.Model):
    """Model for patient data entries (text, audio, video)"""
    id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.Integer, db.ForeignKey('patient.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    entry_type = db.Column(db.String(20), nullable=False)  # text, audio, video
    title = db.Column(db.String(128), nullable=False)
    description = db.Column(db.Text)
    file_path = db.Column(db.String(255))  # For audio/video files
    text_content = db.Column(db.Text)  # For text entries
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Analysis fields
    is_analyzed = db.Column(db.Boolean, default=False)
    analysis_timestamp = db.Column(db.DateTime)
    sentiment_score = db.Column(db.Float)  # Sentiment analysis (-1 to 1)
    key_terms = db.Column(db.Text)  # JSON list of extracted keywords/terms
    behavioral_markers = db.Column(db.Text)  # JSON list of identified behavioral markers
    clinical_insights = db.Column(db.Text)  # AI-generated clinical insights
    
    user = db.relationship('User', backref='data_entries')
    
    def __repr__(self):
        return f'<DataEntry {self.title} - {self.entry_type}>'
        
    def get_key_terms(self):
        """Returns key terms as a list"""
        if self.key_terms:
            return json.loads(self.key_terms)
        return []
        
    def get_behavioral_markers(self):
        """Returns behavioral markers as a list of dictionaries"""
        if self.behavioral_markers:
            return json.loads(self.behavioral_markers)
        return []

class TreatmentPlan(db.Model):
    """Treatment plan model"""
    id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.Integer, db.ForeignKey('patient.id'), nullable=False)
    created_by = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    title = db.Column(db.String(128), nullable=False)
    description = db.Column(db.Text)
    goals = db.Column(db.Text)
    strategies = db.Column(db.Text)
    status = db.Column(db.String(20), default='active')
    start_date = db.Column(db.Date, nullable=False)
    end_date = db.Column(db.Date)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    creator = db.relationship('User', backref='treatment_plans')
    
    def __repr__(self):
        return f'<TreatmentPlan {self.title}>'

class Report(db.Model):
    """Report model for progress reports"""
    id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.Integer, db.ForeignKey('patient.id'), nullable=False)
    created_by = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    report_type = db.Column(db.String(50), nullable=False)
    title = db.Column(db.String(128), nullable=False)
    content = db.Column(db.Text)
    period_start = db.Column(db.Date)
    period_end = db.Column(db.Date)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    patient = db.relationship('Patient', backref='reports')
    creator = db.relationship('User', backref='reports')
    
    def __repr__(self):
        return f'<Report {self.title}>'
