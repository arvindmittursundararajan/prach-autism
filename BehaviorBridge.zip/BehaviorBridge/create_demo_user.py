from app import app, db
from models import User, Patient, DataEntry
from datetime import datetime, date
import json

# Create demo user and data within app context
with app.app_context():
    # Check if demo user already exists
    existing_user = User.query.filter_by(username='demo').first()
    
    if not existing_user:
        # Create demo user
        demo_user = User(
            username='demo',
            email='demo@bcba-assistant.com',
            first_name='Demo',
            last_name='User',
            role='BCBA'
        )
        demo_user.set_password('demo')
        
        db.session.add(demo_user)
        db.session.commit()
        
        print("Demo user created successfully.")
        
        # Create a demo patient
        demo_patient = Patient(
            first_name='Alex',
            last_name='Johnson',
            date_of_birth=date(2015, 5, 15),
            gender='Male',
            guardian_name='Sarah Johnson',
            guardian_contact='555-123-4567',
            diagnosis='Autism Spectrum Disorder, Level 2',
            notes='Alex responds well to visual schedules and positive reinforcement. He has difficulty with transitions and loud environments.',
            therapist_id=demo_user.id
        )
        
        db.session.add(demo_patient)
        db.session.commit()
        
        print("Demo patient created successfully.")
        
        # Create sample data entries
        sample_entries = [
            {
                'entry_type': 'text',
                'title': 'Initial Assessment Notes',
                'description': 'Notes from initial behavioral assessment',
                'text_content': 'Alex displayed multiple instances of attention-seeking behavior during the session. He frequently interrupted activities to request attention from the therapist. He demonstrated some aggressive behaviors when denied immediate attention, including pushing materials off the table. These behaviors appear to be maintained by adult attention. Alex also showed repetitive hand-flapping behaviors when excited or overstimulated. Communication skills are below age-level expectations, with limited use of complete sentences. Social interaction with peers was minimal during the group activity portion of the assessment.'
            },
            {
                'entry_type': 'text',
                'title': 'Session Progress Notes',
                'description': 'Weekly therapy session notes',
                'text_content': 'Alex made good progress today with his compliance training. He followed 7 out of 10 two-step instructions with minimal prompting. Still showing some escape behaviors when presented with non-preferred tasks, particularly writing activities. Used visual timer successfully to help with transitions between activities. No instances of aggression today, which is an improvement from previous sessions. Alex did engage in stimming behaviors (hand flapping) during exciting portions of the activities, but was easily redirected.'
            },
            {
                'entry_type': 'text',
                'title': 'Parent Consultation Summary',
                'description': 'Notes from meeting with parent',
                'text_content': 'Met with Sarah (mother) to discuss implementing strategies at home. She reports that Alex has been having increased tantrums during homework time and bedtime routine. Discussed setting up a visual schedule for these routines and implementing a token economy system for compliance. Sarah mentioned that Alex has shown interest in communicating with his tablet and has been using it to request preferred items. Recommended expanding on this interest by introducing more communication opportunities with his AAC device.'
            }
        ]
        
        for entry_data in sample_entries:
            entry = DataEntry(
                patient_id=demo_patient.id,
                user_id=demo_user.id,
                entry_type=entry_data['entry_type'],
                title=entry_data['title'],
                description=entry_data['description'],
                text_content=entry_data['text_content'],
                created_at=datetime.utcnow()
            )
            
            db.session.add(entry)
        
        db.session.commit()
        print("Demo data entries created successfully.")
    else:
        print("Demo user already exists.")