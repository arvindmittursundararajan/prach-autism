import os
from datetime import datetime
from flask import render_template, redirect, url_for, flash, request, jsonify, send_from_directory
from werkzeug.utils import secure_filename
from flask_login import login_user, logout_user, login_required, current_user
from app import app, db
from models import User, Patient, DataEntry, TreatmentPlan, Report
import analysis

# Login route
@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        user = User.query.filter_by(username=username).first()
        if user and user.check_password(password):
            login_user(user)
            next_page = request.args.get('next')
            return redirect(next_page or url_for('dashboard'))
        else:
            flash('Invalid username or password', 'danger')
    
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

# Dashboard routes
@app.route('/')
@login_required
def index():
    return redirect(url_for('dashboard'))

@app.route('/dashboard')
@login_required
def dashboard():
    # Get counts for dashboard
    patient_count = Patient.query.count()
    active_treatment_plans = TreatmentPlan.query.filter_by(status='active').count()
    recent_data_entries = DataEntry.query.order_by(DataEntry.created_at.desc()).limit(5).all()
    
    # Get data for charts (last 7 patients and their data entry counts)
    recent_patients = Patient.query.order_by(Patient.created_at.desc()).limit(7).all()
    patient_names = [f"{p.first_name} {p.last_name[0]}." for p in recent_patients]
    patient_data_counts = [p.data_entries.count() for p in recent_patients]
    
    return render_template('dashboard.html', 
                          patient_count=patient_count,
                          active_treatment_plans=active_treatment_plans,
                          recent_data_entries=recent_data_entries,
                          patient_names=patient_names,
                          patient_data_counts=patient_data_counts)

# Patient routes
@app.route('/patients')
@login_required
def patients():
    patients_list = Patient.query.all()
    return render_template('patients.html', patients=patients_list)

@app.route('/patients/add', methods=['GET', 'POST'])
@login_required
def add_patient():
    if request.method == 'POST':
        try:
            # Create new patient from form data
            new_patient = Patient(
                first_name=request.form.get('first_name'),
                last_name=request.form.get('last_name'),
                date_of_birth=datetime.strptime(request.form.get('date_of_birth'), '%Y-%m-%d'),
                gender=request.form.get('gender'),
                guardian_name=request.form.get('guardian_name'),
                guardian_contact=request.form.get('guardian_contact'),
                diagnosis=request.form.get('diagnosis'),
                notes=request.form.get('notes'),
                therapist_id=current_user.id
            )
            
            db.session.add(new_patient)
            db.session.commit()
            flash('Patient added successfully!', 'success')
            return redirect(url_for('patients'))
        except Exception as e:
            db.session.rollback()
            flash(f'Error adding patient: {str(e)}', 'danger')
    
    return render_template('patients.html', add_mode=True)

@app.route('/patients/<int:patient_id>')
@login_required
def patient_detail(patient_id):
    patient = Patient.query.get_or_404(patient_id)
    data_entries = DataEntry.query.filter_by(patient_id=patient_id).order_by(DataEntry.created_at.desc()).all()
    treatment_plans = TreatmentPlan.query.filter_by(patient_id=patient_id).order_by(TreatmentPlan.created_at.desc()).all()
    reports = Report.query.filter_by(patient_id=patient_id).order_by(Report.created_at.desc()).all()
    
    return render_template('patient_detail.html', 
                          patient=patient, 
                          data_entries=data_entries,
                          treatment_plans=treatment_plans,
                          reports=reports)

# Data entry routes
@app.route('/data-upload', methods=['GET', 'POST'])
@login_required
def data_upload():
    patients_list = Patient.query.all()
    
    if request.method == 'POST':
        patient_id = request.form.get('patient_id')
        entry_type = request.form.get('entry_type')
        title = request.form.get('title')
        description = request.form.get('description')
        
        try:
            # Create data entry
            data_entry = DataEntry(
                patient_id=patient_id,
                user_id=current_user.id,
                entry_type=entry_type,
                title=title,
                description=description
            )
            
            # Handle file uploads or text content
            if entry_type == 'text':
                data_entry.text_content = request.form.get('text_content')
            else:  # audio or video
                # In a real app, handle file upload storage
                data_entry.file_path = f"/uploads/{entry_type}/{secure_filename(request.files['media_file'].filename)}"
            
            db.session.add(data_entry)
            db.session.commit()
            
            # Analyze the content immediately
            if entry_type == 'text' and data_entry.text_content:
                if analysis.analyze_data_entry(data_entry.id):
                    flash('Data entry added and analyzed successfully!', 'success')
                else:
                    flash('Data entry added but analysis failed. You can analyze it later.', 'warning')
            else:
                flash('Data entry added successfully! Add a description to enable analysis.', 'success')
                
            return redirect(url_for('data_upload'))
        except Exception as e:
            db.session.rollback()
            flash(f'Error adding data entry: {str(e)}', 'danger')
    
    return render_template('data_upload.html', patients=patients_list)

@app.route('/analyze-content/<int:data_entry_id>', methods=['POST'])
@login_required
def analyze_content(data_entry_id):
    """Analyze a specific data entry"""
    data_entry = DataEntry.query.get_or_404(data_entry_id)
    
    # Only allow analysis by the creator or for patients assigned to this user
    if data_entry.user_id != current_user.id and data_entry.patient.therapist_id != current_user.id:
        flash('You do not have permission to analyze this data entry.', 'danger')
        return redirect(url_for('patient_detail', patient_id=data_entry.patient_id))
    
    if analysis.analyze_data_entry(data_entry_id):
        flash('Content analyzed successfully!', 'success')
    else:
        flash('Content analysis failed. Please check logs for details.', 'danger')
    
    # Determine redirect based on request referrer
    referrer = request.referrer
    if referrer and 'content-analysis' in referrer:
        return redirect(url_for('content_analysis', data_entry_id=data_entry_id))
    else:
        return redirect(url_for('patient_detail', patient_id=data_entry.patient_id))

@app.route('/get-content-analysis/<int:data_entry_id>')
@login_required
def get_content_analysis(data_entry_id):
    """Get analysis details for a specific data entry"""
    data_entry = DataEntry.query.get_or_404(data_entry_id)
    
    # Only allow access by the creator or for patients assigned to this user
    if data_entry.user_id != current_user.id and data_entry.patient.therapist_id != current_user.id:
        return jsonify({'error': 'Permission denied'}), 403
    
    if not data_entry.is_analyzed:
        return jsonify({'error': 'Content has not been analyzed yet'}), 404
    
    analysis_data = {
        'sentiment_score': data_entry.sentiment_score,
        'key_terms': data_entry.get_key_terms(),
        'behavioral_markers': data_entry.get_behavioral_markers(),
        'clinical_insights': data_entry.clinical_insights,
        'analysis_timestamp': data_entry.analysis_timestamp.strftime('%Y-%m-%d %H:%M:%S')
    }
    
    return jsonify(analysis_data)

# Treatment plan routes
@app.route('/treatment-plans')
@login_required
def treatment_plans():
    treatment_plans_list = TreatmentPlan.query.join(Patient).all()
    patients_list = Patient.query.all()
    return render_template('treatment_plans.html', 
                          treatment_plans=treatment_plans_list,
                          patients=patients_list)
                          
@app.route('/get-treatment-recommendations/<int:patient_id>')
@login_required
def get_treatment_recommendations(patient_id):
    """Get AI-generated treatment recommendations based on analyzed data"""
    patient = Patient.query.get_or_404(patient_id)
    
    # Verify permission
    if patient.therapist_id != current_user.id and current_user.role != 'Admin':
        return jsonify({'error': 'Permission denied'}), 403
    
    # Check if there are analyzed data entries
    analyzed_entries = DataEntry.query.filter_by(
        patient_id=patient_id,
        is_analyzed=True
    ).count()
    
    if analyzed_entries == 0:
        return jsonify({
            'recommendations': ["No analyzed data available. Please analyze patient data entries first."],
            'analyzed_count': 0
        })
    
    # Get recommendations
    recommendations = analysis.generate_treatment_recommendations(patient_id)
    
    return jsonify({
        'recommendations': recommendations,
        'analyzed_count': analyzed_entries
    })

@app.route('/treatment-plans/add', methods=['POST'])
@login_required
def add_treatment_plan():
    if request.method == 'POST':
        try:
            # Create new treatment plan from form data
            new_plan = TreatmentPlan(
                patient_id=request.form.get('patient_id'),
                created_by=current_user.id,
                title=request.form.get('title'),
                description=request.form.get('description'),
                goals=request.form.get('goals'),
                strategies=request.form.get('strategies'),
                status='active',
                start_date=datetime.strptime(request.form.get('start_date'), '%Y-%m-%d'),
                end_date=datetime.strptime(request.form.get('end_date'), '%Y-%m-%d') if request.form.get('end_date') else None
            )
            
            db.session.add(new_plan)
            db.session.commit()
            flash('Treatment plan added successfully!', 'success')
        except Exception as e:
            db.session.rollback()
            flash(f'Error adding treatment plan: {str(e)}', 'danger')
    
    return redirect(url_for('treatment_plans'))

# Content Analysis routes
@app.route('/content-analysis')
@login_required
def content_analysis():
    patients_list = Patient.query.filter_by(therapist_id=current_user.id).all()
    
    # Get filter parameters
    patient_id = request.args.get('patient_id')
    entry_type = request.args.get('entry_type')
    analysis_status = request.args.get('analysis_status')
    data_entry_id = request.args.get('data_entry_id')
    
    # Build query
    query = DataEntry.query.join(Patient)
    
    if patient_id:
        query = query.filter(DataEntry.patient_id == patient_id)
    if entry_type:
        query = query.filter(DataEntry.entry_type == entry_type)
    if analysis_status == 'analyzed':
        query = query.filter(DataEntry.is_analyzed == True)
    elif analysis_status == 'not_analyzed':
        query = query.filter(DataEntry.is_analyzed == False)
    
    # Get selected entry if specified
    selected_entry = None
    if data_entry_id:
        selected_entry = DataEntry.query.get(data_entry_id)
    
    # Get entries based on filters
    entries = query.order_by(DataEntry.created_at.desc()).all()
    
    return render_template('content_analysis.html', 
                          patients=patients_list,
                          entries=entries,
                          selected_entry=selected_entry,
                          patient_id=patient_id,
                          entry_type=entry_type,
                          analysis_status=analysis_status)

# Report routes
@app.route('/reports')
@login_required
def reports():
    reports_list = Report.query.join(Patient).all()
    patients_list = Patient.query.all()
    return render_template('reports.html', 
                          reports=reports_list,
                          patients=patients_list)

@app.route('/reports/add', methods=['POST'])
@login_required
def add_report():
    if request.method == 'POST':
        try:
            # Create new report from form data
            new_report = Report(
                patient_id=request.form.get('patient_id'),
                created_by=current_user.id,
                report_type=request.form.get('report_type'),
                title=request.form.get('title'),
                content=request.form.get('content'),
                period_start=datetime.strptime(request.form.get('period_start'), '%Y-%m-%d') if request.form.get('period_start') else None,
                period_end=datetime.strptime(request.form.get('period_end'), '%Y-%m-%d') if request.form.get('period_end') else None
            )
            
            db.session.add(new_report)
            db.session.commit()
            flash('Report added successfully!', 'success')
        except Exception as e:
            db.session.rollback()
            flash(f'Error adding report: {str(e)}', 'danger')
    
    return redirect(url_for('reports'))
