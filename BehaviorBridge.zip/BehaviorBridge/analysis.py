"""
BCBA Clinical Assistant Content Analysis Module
This module provides functionality for analyzing text, audio, and video content
and extracting meaningful clinical insights for BCBAs.
"""

import json
import re
import logging
from datetime import datetime
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.probability import FreqDist
from nltk.sentiment import SentimentIntensityAnalyzer
from sklearn.feature_extraction.text import TfidfVectorizer
from models import DataEntry

# Initialize NLTK resources
try:
    nltk.download('punkt', quiet=True)
    nltk.download('stopwords', quiet=True)
    nltk.download('vader_lexicon', quiet=True)
except:
    logging.warning("NLTK resource download failed. Some features may not work properly.")

# Constants for behavioral markers
BEHAVIORAL_MARKERS = {
    'attention_seeking': ['attention', 'seeking', 'look at me', 'watch me'],
    'aggression': ['hit', 'kick', 'push', 'aggression', 'aggressive', 'violent'],
    'self_injury': ['self-injury', 'self-harm', 'hitting self', 'biting self'],
    'escape': ['avoid', 'escape', 'run away', 'eloping', 'hiding'],
    'stimming': ['stim', 'stimming', 'repetitive', 'flapping', 'rocking'],
    'compliance': ['follow', 'instruction', 'compliance', 'compliant', 'listening'],
    'communication': ['request', 'communicate', 'expressive', 'receptive', 'verbal'],
    'social': ['peer', 'social', 'interaction', 'engage', 'play', 'sharing']
}

# Clinical insight templates
INSIGHT_TEMPLATES = {
    'attention_seeking': "Exhibits attention-seeking behaviors that may indicate a need for more {type} reinforcement.",
    'aggression': "Displays aggressive behaviors possibly triggered by {type} factors.",
    'self_injury': "Self-injurious behaviors present, potentially maintained by {type} reinforcement.",
    'escape': "Demonstrates escape behaviors when presented with {type} demands.",
    'stimming': "Engages in stimming behaviors, which may serve a {type} function.",
    'compliance': "Shows {type} levels of compliance with instructions.",
    'communication': "Demonstrates {type} communication skills in expressing needs.",
    'social': "Exhibits {type} social interaction patterns with peers and adults."
}

def download_nltk_data():
    """Ensure NLTK data is downloaded"""
    try:
        nltk.download('punkt')
        nltk.download('stopwords')
        nltk.download('vader_lexicon')
        return True
    except Exception as e:
        logging.error(f"Error downloading NLTK data: {str(e)}")
        return False

def analyze_text_content(text_content):
    """
    Analyzes text content and extracts clinical insights
    
    Args:
        text_content (str): The text content to analyze
        
    Returns:
        dict: Analysis results including sentiment, key terms, and behavioral markers
    """
    if not text_content or text_content.strip() == '':
        return {
            'sentiment_score': 0,
            'key_terms': [],
            'behavioral_markers': [],
            'clinical_insights': "Insufficient content for analysis."
        }
    
    # Sentiment analysis
    sia = SentimentIntensityAnalyzer()
    sentiment = sia.polarity_scores(text_content)
    sentiment_score = sentiment['compound']
    
    # Key terms extraction
    stop_words = set(stopwords.words('english'))
    word_tokens = word_tokenize(text_content.lower())
    filtered_words = [word for word in word_tokens if word.isalpha() and word not in stop_words]
    
    # Get frequency distribution
    fdist = FreqDist(filtered_words)
    key_terms = [{'term': term, 'count': count} for term, count in fdist.most_common(10)]
    
    # Behavioral markers identification
    behavioral_markers = []
    for marker, keywords in BEHAVIORAL_MARKERS.items():
        score = 0
        matches = []
        for keyword in keywords:
            pattern = r'\b' + re.escape(keyword) + r'\b'
            found = re.findall(pattern, text_content.lower())
            if found:
                score += len(found)
                matches.extend(found)
        
        if score > 0:
            behavioral_markers.append({
                'marker': marker,
                'score': score,
                'matches': list(set(matches))
            })
    
    # Generate clinical insights
    insights = []
    for marker in behavioral_markers:
        marker_type = marker['marker']
        if marker_type in INSIGHT_TEMPLATES:
            # Determine intensity based on score
            intensity = "high" if marker['score'] > 5 else "moderate" if marker['score'] > 2 else "low"
            insight = INSIGHT_TEMPLATES[marker_type].format(type=intensity)
            insights.append(insight)
    
    if not insights:
        # Generate generic insight if no specific markers found
        insights.append("No significant behavioral markers identified in this content.")
    
    return {
        'sentiment_score': sentiment_score,
        'key_terms': key_terms,
        'behavioral_markers': behavioral_markers,
        'clinical_insights': "\n".join(insights)
    }

def analyze_audio_content(file_path, transcription=None):
    """
    Analyzes audio content and extracts clinical insights
    In a production system, this would use speech-to-text and
    audio analysis algorithms for tone, pace, etc.
    
    Args:
        file_path (str): Path to the audio file
        transcription (str, optional): Manual transcription if available
        
    Returns:
        dict: Analysis results
    """
    # For demonstration, if transcription is provided, analyze it as text
    if transcription:
        text_analysis = analyze_text_content(transcription)
        text_analysis['clinical_insights'] = "Audio analysis based on provided transcription: \n" + text_analysis['clinical_insights']
        return text_analysis
    
    # Placeholder for actual audio analysis
    return {
        'sentiment_score': 0,
        'key_terms': [],
        'behavioral_markers': [],
        'clinical_insights': "Audio analysis requires transcription. Please add a transcription to the description field."
    }

def analyze_video_content(file_path, transcription=None, description=None):
    """
    Analyzes video content and extracts clinical insights
    In a production system, this would use computer vision, speech-to-text,
    and behavioral pattern recognition
    
    Args:
        file_path (str): Path to the video file
        transcription (str, optional): Manual transcription if available
        description (str, optional): Manual description of video content
        
    Returns:
        dict: Analysis results
    """
    # For demonstration, if description or transcription is provided, analyze it as text
    analyzable_content = ""
    if transcription:
        analyzable_content += transcription + " "
    if description:
        analyzable_content += description
    
    if analyzable_content:
        text_analysis = analyze_text_content(analyzable_content)
        text_analysis['clinical_insights'] = "Video analysis based on provided description/transcription: \n" + text_analysis['clinical_insights']
        return text_analysis
    
    # Placeholder for actual video analysis
    return {
        'sentiment_score': 0,
        'key_terms': [],
        'behavioral_markers': [],
        'clinical_insights': "Video analysis requires description. Please add a description of the behaviors observed in the video."
    }

def analyze_data_entry(data_entry_id):
    """
    Main function to analyze a data entry based on its type
    
    Args:
        data_entry_id (int): ID of the data entry to analyze
        
    Returns:
        bool: Success status
    """
    from app import db
    
    data_entry = DataEntry.query.get(data_entry_id)
    if not data_entry:
        logging.error(f"Data entry with ID {data_entry_id} not found")
        return False
    
    try:
        if data_entry.entry_type == 'text':
            analysis_results = analyze_text_content(data_entry.text_content)
        elif data_entry.entry_type == 'audio':
            analysis_results = analyze_audio_content(data_entry.file_path, data_entry.description)
        elif data_entry.entry_type == 'video':
            analysis_results = analyze_video_content(data_entry.file_path, None, data_entry.description)
        else:
            logging.error(f"Unknown entry type: {data_entry.entry_type}")
            return False
        
        # Update data entry with analysis results
        data_entry.is_analyzed = True
        data_entry.analysis_timestamp = datetime.utcnow()
        data_entry.sentiment_score = analysis_results['sentiment_score']
        data_entry.key_terms = json.dumps(analysis_results['key_terms'])
        data_entry.behavioral_markers = json.dumps(analysis_results['behavioral_markers'])
        data_entry.clinical_insights = analysis_results['clinical_insights']
        
        db.session.commit()
        return True
    
    except Exception as e:
        logging.error(f"Error analyzing data entry {data_entry_id}: {str(e)}")
        db.session.rollback()
        return False

def generate_treatment_recommendations(patient_id):
    """
    Generates treatment recommendations based on analyzed data entries for a patient
    
    Args:
        patient_id (int): ID of the patient
        
    Returns:
        list: List of treatment recommendations
    """
    from app import db
    from models import Patient
    
    patient = Patient.query.get(patient_id)
    if not patient:
        return []
    
    # Get analyzed data entries for the patient
    data_entries = DataEntry.query.filter_by(
        patient_id=patient_id,
        is_analyzed=True
    ).order_by(DataEntry.created_at.desc()).all()
    
    if not data_entries:
        return ["Insufficient analyzed data to generate recommendations."]
    
    # Collect all behavioral markers
    all_markers = {}
    for entry in data_entries:
        markers = entry.get_behavioral_markers()
        for marker in markers:
            marker_type = marker['marker']
            if marker_type not in all_markers:
                all_markers[marker_type] = {
                    'count': 0,
                    'score_total': 0,
                    'entries': []
                }
            
            all_markers[marker_type]['count'] += 1
            all_markers[marker_type]['score_total'] += marker['score']
            all_markers[marker_type]['entries'].append(entry.id)
    
    # Generate recommendations based on marker frequency and intensity
    recommendations = []
    for marker_type, data in all_markers.items():
        if data['count'] >= 3:  # Require at least 3 occurrences for stronger recommendation
            avg_score = data['score_total'] / data['count']
            priority = "high" if avg_score > 4 else "medium" if avg_score > 2 else "low"
            
            if marker_type == 'attention_seeking':
                recommendations.append({
                    'priority': priority,
                    'area': 'Attention-Seeking Behavior',
                    'recommendation': f"Implement differential reinforcement of alternative behaviors (DRA) to address {priority} levels of attention-seeking behavior."
                })
            elif marker_type == 'aggression':
                recommendations.append({
                    'priority': priority,
                    'area': 'Aggressive Behavior',
                    'recommendation': f"Conduct functional behavior assessment (FBA) to identify triggers for {priority} frequency aggressive behaviors."
                })
            elif marker_type == 'self_injury':
                recommendations.append({
                    'priority': priority,
                    'area': 'Self-Injurious Behavior',
                    'recommendation': f"Implement protective measures and sensory integration therapy to address {priority} intensity self-injurious behaviors."
                })
            elif marker_type == 'escape':
                recommendations.append({
                    'priority': priority,
                    'area': 'Escape Behavior',
                    'recommendation': f"Use task analysis and visual schedules to reduce {priority} frequency escape behaviors."
                })
            elif marker_type == 'stimming':
                recommendations.append({
                    'priority': priority,
                    'area': 'Stimming Behavior',
                    'recommendation': f"Channel stimming behaviors into more appropriate self-regulation activities to address {priority} frequency stimming."
                })
            elif marker_type == 'compliance':
                if avg_score > 3:  # High compliance is positive
                    recommendations.append({
                        'priority': 'low',
                        'area': 'Compliance',
                        'recommendation': "Maintain current reinforcement schedule for compliance behaviors."
                    })
                else:
                    recommendations.append({
                        'priority': 'medium',
                        'area': 'Compliance',
                        'recommendation': "Implement token economy to increase compliance with instructions."
                    })
            elif marker_type == 'communication':
                recommendations.append({
                    'priority': priority,
                    'area': 'Communication',
                    'recommendation': f"Strengthen communication skills using {priority}-priority augmentative and alternative communication (AAC) strategies."
                })
            elif marker_type == 'social':
                recommendations.append({
                    'priority': priority,
                    'area': 'Social Interaction',
                    'recommendation': f"Implement social skills training with peer modeling to address {priority}-priority social interaction deficits."
                })
    
    # Sort recommendations by priority
    priority_order = {'high': 0, 'medium': 1, 'low': 2}
    recommendations.sort(key=lambda x: priority_order[x['priority']])
    
    # Format recommendations for display
    formatted_recommendations = []
    for rec in recommendations:
        formatted_recommendations.append(f"[{rec['priority'].upper()}] {rec['area']}: {rec['recommendation']}")
    
    if not formatted_recommendations:
        formatted_recommendations = ["Insufficient behavioral pattern data to generate specific recommendations. Continue data collection."]
    
    return formatted_recommendations