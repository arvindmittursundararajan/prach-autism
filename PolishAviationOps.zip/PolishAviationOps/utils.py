from datetime import datetime, timedelta
import logging
from sqlalchemy import or_, and_

from models import (
    db, Crew, Aircraft, Flight, Schedule, OperationalAlert,
    CREW_STATUS_AVAILABLE, CREW_STATUS_ON_DUTY, CREW_STATUS_REST,
    AIRCRAFT_STATUS_AVAILABLE, AIRCRAFT_STATUS_IN_FLIGHT,
    FLIGHT_STATUS_SCHEDULED, FLIGHT_STATUS_DELAYED, FLIGHT_STATUS_CANCELLED,
    ALERT_SEVERITY_LOW, ALERT_SEVERITY_MEDIUM, ALERT_SEVERITY_HIGH, ALERT_SEVERITY_CRITICAL
)

logger = logging.getLogger(__name__)

def get_crew_availability(date=None):
    """Calculate crew availability for a given date"""
    if date is None:
        date = datetime.utcnow().date()
    
    start_datetime = datetime.combine(date, datetime.min.time())
    end_datetime = datetime.combine(date, datetime.max.time())
    
    # Get all crew
    all_crew = Crew.query.all()
    
    # Get scheduled flights for the date
    day_flights = Flight.query.filter(
        or_(
            and_(
                Flight.scheduled_departure >= start_datetime,
                Flight.scheduled_departure <= end_datetime
            ),
            and_(
                Flight.scheduled_arrival >= start_datetime,
                Flight.scheduled_arrival <= end_datetime
            )
        )
    ).all()
    
    # Map crew to their flights
    crew_flights = {}
    for flight in day_flights:
        for crew_member in flight.assigned_crew:
            if crew_member.id not in crew_flights:
                crew_flights[crew_member.id] = []
            crew_flights[crew_member.id].append(flight)
    
    # Calculate availability for each crew
    availability = {
        'available': [],
        'on_duty': [],
        'rest': [],
        'other': []
    }
    
    for crew in all_crew:
        if crew.id in crew_flights:
            # Crew has flights today
            availability['on_duty'].append({
                'id': crew.id,
                'name': f"{crew.first_name} {crew.last_name}",
                'position': crew.position,
                'flight_count': len(crew_flights[crew.id]),
                'flights': [f.flight_number for f in crew_flights[crew.id]]
            })
        elif crew.status == CREW_STATUS_REST:
            # Crew is resting
            availability['rest'].append({
                'id': crew.id,
                'name': f"{crew.first_name} {crew.last_name}",
                'position': crew.position,
                'status': crew.status
            })
        elif crew.status == CREW_STATUS_AVAILABLE:
            # Crew is available
            availability['available'].append({
                'id': crew.id,
                'name': f"{crew.first_name} {crew.last_name}",
                'position': crew.position,
                'status': crew.status
            })
        else:
            # Crew is in another status (training, sick, etc.)
            availability['other'].append({
                'id': crew.id,
                'name': f"{crew.first_name} {crew.last_name}",
                'position': crew.position,
                'status': crew.status
            })
    
    # Calculate summary statistics
    availability['summary'] = {
        'total': len(all_crew),
        'available': len(availability['available']),
        'on_duty': len(availability['on_duty']),
        'rest': len(availability['rest']),
        'other': len(availability['other']),
        'availability_rate': round(len(availability['available']) / len(all_crew) * 100 if all_crew else 0, 1)
    }
    
    return availability

def get_aircraft_availability(date=None):
    """Calculate aircraft availability for a given date"""
    if date is None:
        date = datetime.utcnow().date()
    
    start_datetime = datetime.combine(date, datetime.min.time())
    end_datetime = datetime.combine(date, datetime.max.time())
    
    # Get all aircraft
    all_aircraft = Aircraft.query.all()
    
    # Get scheduled flights for the date
    day_flights = Flight.query.filter(
        or_(
            and_(
                Flight.scheduled_departure >= start_datetime,
                Flight.scheduled_departure <= end_datetime
            ),
            and_(
                Flight.scheduled_arrival >= start_datetime,
                Flight.scheduled_arrival <= end_datetime
            )
        )
    ).all()
    
    # Map aircraft to their flights
    aircraft_flights = {}
    for flight in day_flights:
        if flight.aircraft_id:
            if flight.aircraft_id not in aircraft_flights:
                aircraft_flights[flight.aircraft_id] = []
            aircraft_flights[flight.aircraft_id].append(flight)
    
    # Calculate availability for each aircraft
    availability = {
        'available': [],
        'in_flight': [],
        'maintenance': [],
        'other': []
    }
    
    for aircraft in all_aircraft:
        if aircraft.id in aircraft_flights:
            # Aircraft has flights today
            availability['in_flight'].append({
                'id': aircraft.id,
                'registration': aircraft.registration,
                'type': aircraft.aircraft_type,
                'flight_count': len(aircraft_flights[aircraft.id]),
                'flights': [f.flight_number for f in aircraft_flights[aircraft.id]]
            })
        elif aircraft.status == AIRCRAFT_STATUS_AVAILABLE:
            # Aircraft is available
            availability['available'].append({
                'id': aircraft.id,
                'registration': aircraft.registration,
                'type': aircraft.aircraft_type,
                'status': aircraft.status
            })
        elif aircraft.status == 'maintenance':
            # Aircraft is in maintenance
            availability['maintenance'].append({
                'id': aircraft.id,
                'registration': aircraft.registration,
                'type': aircraft.aircraft_type,
                'status': aircraft.status
            })
        else:
            # Aircraft has another status
            availability['other'].append({
                'id': aircraft.id,
                'registration': aircraft.registration,
                'type': aircraft.aircraft_type,
                'status': aircraft.status
            })
    
    # Calculate summary statistics
    availability['summary'] = {
        'total': len(all_aircraft),
        'available': len(availability['available']),
        'in_flight': len(availability['in_flight']),
        'maintenance': len(availability['maintenance']),
        'other': len(availability['other']),
        'availability_rate': round(len(availability['available']) / len(all_aircraft) * 100 if all_aircraft else 0, 1)
    }
    
    return availability

def calculate_risk_score(flight):
    """Calculate risk score for a given flight"""
    risk_score = 0
    risk_factors = []
    
    # Current time
    now = datetime.utcnow()
    
    # 1. Check if flight is in the next 24 hours
    if flight.scheduled_departure and (flight.scheduled_departure - now) < timedelta(hours=24):
        risk_score += 10
        risk_factors.append("Departure within 24 hours")
    
    # 2. Check crew assignment
    required_crew_positions = {
        'captain': 1,
        'first_officer': 1,
        'flight_attendant': 2
    }
    
    crew_positions = {}
    for crew_member in flight.assigned_crew:
        if crew_member.position not in crew_positions:
            crew_positions[crew_member.position] = 0
        crew_positions[crew_member.position] += 1
    
    for position, required_count in required_crew_positions.items():
        assigned_count = crew_positions.get(position, 0)
        if assigned_count < required_count:
            risk_score += 25
            risk_factors.append(f"Missing {position}: {assigned_count}/{required_count}")
    
    # 3. Check if aircraft is assigned
    if not flight.aircraft_id:
        risk_score += 30
        risk_factors.append("No aircraft assigned")
    
    # 4. Check for tight connections
    if flight.aircraft_id:
        # Look for previous flight using same aircraft with tight connection
        prev_flight = Flight.query.filter(
            Flight.aircraft_id == flight.aircraft_id,
            Flight.scheduled_arrival < flight.scheduled_departure,
            Flight.scheduled_arrival > flight.scheduled_departure - timedelta(hours=2)
        ).order_by(Flight.scheduled_arrival.desc()).first()
        
        if prev_flight:
            connection_time = (flight.scheduled_departure - prev_flight.scheduled_arrival).total_seconds() / 60
            if connection_time < 45:
                risk_score += 20
                risk_factors.append(f"Tight connection: {int(connection_time)} minutes after {prev_flight.flight_number}")
            elif connection_time < 60:
                risk_score += 10
                risk_factors.append(f"Close connection: {int(connection_time)} minutes after {prev_flight.flight_number}")
    
    # 5. Simplified crew rest check - removed Schedule dependency
    for crew_member in flight.assigned_crew:
        if crew_member.status == 'rest':
            risk_score += 15
            risk_factors.append(f"Crew member {crew_member.first_name} {crew_member.last_name} is currently resting")
    
    # 6. Check for maintenance issues
    if flight.aircraft_id:
        aircraft = Aircraft.query.get(flight.aircraft_id)
        if aircraft.maintenance_due_hours - aircraft.total_flight_hours < 50:
            risk_score += 15
            remaining_hours = aircraft.maintenance_due_hours - aircraft.total_flight_hours
            risk_factors.append(f"Maintenance due soon: {remaining_hours} flight hours remaining")
    
    # Normalize risk score to 0-100 range
    risk_score = min(100, risk_score)
    
    # Determine risk category
    risk_category = "Low"
    if risk_score > 70:
        risk_category = "Critical"
    elif risk_score > 50:
        risk_category = "High"
    elif risk_score > 30:
        risk_category = "Medium"
    
    return {
        'score': risk_score,
        'category': risk_category,
        'factors': risk_factors
    }

def analyze_schedule_vulnerabilities(start_date=None, days=1):
    """Analyze schedule for vulnerabilities in the given date range"""
    if start_date is None:
        start_date = datetime.utcnow().date()
    
    end_date = start_date + timedelta(days=days)
    
    start_datetime = datetime.combine(start_date, datetime.min.time())
    end_datetime = datetime.combine(end_date, datetime.min.time())
    
    # Get all flights in the date range
    flights = Flight.query.filter(
        Flight.scheduled_departure >= start_datetime,
        Flight.scheduled_departure < end_datetime
    ).order_by(Flight.scheduled_departure).all()
    
    # If no flights, return empty result
    if not flights:
        return {
            'vulnerabilities': [],
            'summary': {
                'total_flights': 0,
                'vulnerable_flights': 0,
                'vulnerable_percentage': 0,
                'critical_count': 0,
                'high_count': 0,
                'medium_count': 0
            }
        }
    
    vulnerabilities = []
    
    # Analyze each flight for basic risks without using Schedule table
    for flight in flights:
        # Initialize risk score based on simple factors
        risk_score = 0
        risk_factors = []
        
        # Current time
        now = datetime.utcnow()
        
        # 1. Check if flight is in the next 24 hours
        if flight.scheduled_departure and (flight.scheduled_departure - now) < timedelta(hours=24):
            risk_score += 10
            risk_factors.append("Departure within 24 hours")
        
        # 2. Check crew assignment (simplifying)
        if len(flight.assigned_crew) < 3:  # Simplified check
            risk_score += 25
            risk_factors.append(f"Insufficient crew: {len(flight.assigned_crew)}/3 minimum")
        
        # 3. Check if aircraft is assigned
        if not flight.aircraft_id:
            risk_score += 30
            risk_factors.append("No aircraft assigned")
        
        # 4. Check for tight connections
        if flight.aircraft_id:
            # Look for previous flight using same aircraft with tight connection
            prev_flight = Flight.query.filter(
                Flight.aircraft_id == flight.aircraft_id,
                Flight.scheduled_arrival < flight.scheduled_departure,
                Flight.scheduled_arrival > flight.scheduled_departure - timedelta(hours=2)
            ).order_by(Flight.scheduled_arrival.desc()).first()
            
            if prev_flight:
                connection_time = (flight.scheduled_departure - prev_flight.scheduled_arrival).total_seconds() / 60
                if connection_time < 45:
                    risk_score += 20
                    risk_factors.append(f"Tight connection: {int(connection_time)} minutes after {prev_flight.flight_number}")
                elif connection_time < 60:
                    risk_score += 10
                    risk_factors.append(f"Close connection: {int(connection_time)} minutes after {prev_flight.flight_number}")
        
        # 5. Check for maintenance issues
        if flight.aircraft_id:
            aircraft = Aircraft.query.get(flight.aircraft_id)
            if aircraft.maintenance_due_hours - aircraft.total_flight_hours < 50:
                risk_score += 15
                remaining_hours = aircraft.maintenance_due_hours - aircraft.total_flight_hours
                risk_factors.append(f"Maintenance due soon: {remaining_hours} flight hours remaining")
        
        # Normalize risk score to 0-100 range
        risk_score = min(100, risk_score)
        
        # Determine risk category
        risk_category = "Low"
        if risk_score > 70:
            risk_category = "Critical"
        elif risk_score > 50:
            risk_category = "High"
        elif risk_score > 30:
            risk_category = "Medium"
        
        if risk_score > 30:  # Only include medium or higher risks
            vulnerabilities.append({
                'flight': flight,
                'risk_score': risk_score,
                'risk_category': risk_category,
                'risk_factors': risk_factors
            })
    
    # Sort vulnerabilities by risk score (highest first)
    vulnerabilities.sort(key=lambda x: x['risk_score'], reverse=True)
    
    # Calculate summary statistics
    total_flights = len(flights)
    vulnerable_flights = len(vulnerabilities)
    
    critical_count = sum(1 for v in vulnerabilities if v['risk_category'] == 'Critical')
    high_count = sum(1 for v in vulnerabilities if v['risk_category'] == 'High')
    medium_count = sum(1 for v in vulnerabilities if v['risk_category'] == 'Medium')
    
    return {
        'vulnerabilities': vulnerabilities,
        'summary': {
            'total_flights': total_flights,
            'vulnerable_flights': vulnerable_flights,
            'vulnerable_percentage': round(vulnerable_flights / total_flights * 100 if total_flights else 0, 1),
            'critical_count': critical_count,
            'high_count': high_count,
            'medium_count': medium_count
        }
    }

def create_operational_alert(alert_type, description, severity, flight=None, crew=None, aircraft=None):
    """Create a new operational alert"""
    alert = OperationalAlert(
        alert_type=alert_type,
        description=description,
        severity=severity,
        flight_id=flight.id if flight else None,
        crew_id=crew.id if crew else None,
        aircraft_id=aircraft.id if aircraft else None
    )
    
    db.session.add(alert)
    db.session.commit()
    
    logger.info(f"Created {severity} alert: {alert_type} - {description}")
    
    return alert
