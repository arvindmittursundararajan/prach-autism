"""
Simple initialization script to populate the database with sample data
"""

from datetime import datetime, timedelta
import random
from app import app, db
from models import (
    Crew, Aircraft, Flight, Airport, OperationalAlert, OperationalDecision,
    CREW_STATUS_AVAILABLE, CREW_STATUS_ON_DUTY, CREW_STATUS_REST,
    AIRCRAFT_STATUS_AVAILABLE, AIRCRAFT_STATUS_IN_FLIGHT, AIRCRAFT_STATUS_MAINTENANCE,
    FLIGHT_STATUS_SCHEDULED, FLIGHT_STATUS_DELAYED, FLIGHT_STATUS_CANCELLED, FLIGHT_STATUS_COMPLETED,
    ALERT_SEVERITY_LOW, ALERT_SEVERITY_MEDIUM, ALERT_SEVERITY_HIGH, ALERT_SEVERITY_CRITICAL
)

def create_sample_data():
    """Create basic sample data for the application"""
    print("Creating sample data...")
    
    # Create airports
    airports = [
        Airport(code='WAW', name='Warsaw Chopin Airport', city='Warsaw', country='Poland', timezone='Europe/Warsaw', gate_capacity=50, staff_count=300),
        Airport(code='KRK', name='Kraków John Paul II International Airport', city='Kraków', country='Poland', timezone='Europe/Warsaw', gate_capacity=30, staff_count=200),
        Airport(code='GDN', name='Gdańsk Lech Wałęsa Airport', city='Gdańsk', country='Poland', timezone='Europe/Warsaw', gate_capacity=25, staff_count=150),
        Airport(code='LHR', name='London Heathrow Airport', city='London', country='United Kingdom', timezone='Europe/London', gate_capacity=100, staff_count=500),
        Airport(code='CDG', name='Charles de Gaulle Airport', city='Paris', country='France', timezone='Europe/Paris', gate_capacity=80, staff_count=450)
    ]
    db.session.add_all(airports)
    db.session.commit()
    print(f"Created {len(airports)} airports")
    
    # Create aircraft
    aircraft_types = [
        {'type': 'Boeing 737-800', 'seats': 189, 'fuel': 26020, 'maintenance': 4000},
        {'type': 'Boeing 787-9', 'seats': 294, 'fuel': 126372, 'maintenance': 6000},
        {'type': 'Embraer E195', 'seats': 120, 'fuel': 16153, 'maintenance': 3500}
    ]
    
    aircraft = []
    for i in range(1, 11):
        aircraft_type = random.choice(aircraft_types)
        status_weights = [70, 20, 10]  # More likely to be available
        status = random.choices([AIRCRAFT_STATUS_AVAILABLE, AIRCRAFT_STATUS_IN_FLIGHT, AIRCRAFT_STATUS_MAINTENANCE], weights=status_weights)[0]
        
        current_airport = random.choice(airports)
        manufactured_date = datetime.now() - timedelta(days=random.randint(365*2, 365*8))
        total_hours = random.randint(5000, 25000)
        maintenance_due = aircraft_type['maintenance'] - random.randint(0, 2000)
        
        aircraft.append(Aircraft(
            registration=f'SP-L{chr(65 + i // 10)}{i % 10}{random.randint(0, 9)}',
            aircraft_type=aircraft_type['type'],
            status=status,
            seat_capacity=aircraft_type['seats'],
            current_airport_id=current_airport.id,
            maintenance_due_hours=maintenance_due,
            total_flight_hours=total_hours,
            fuel_capacity=aircraft_type['fuel'],
            current_fuel=random.randint(aircraft_type['fuel'] // 4, aircraft_type['fuel']),
            manufacturing_date=manufactured_date
        ))
    
    db.session.add_all(aircraft)
    db.session.commit()
    print(f"Created {len(aircraft)} aircraft")
    
    # Create crew
    positions = ['captain', 'first_officer', 'flight_attendant', 'purser']
    position_weights = [10, 10, 25, 5]  # Distribution of positions
    
    qualifications = {
        'captain': ['Boeing 737-800', 'Boeing 787-9', 'Embraer E195'],
        'first_officer': ['Boeing 737-800', 'Boeing 787-9', 'Embraer E195'],
        'flight_attendant': ['All Types'],
        'purser': ['All Types']
    }
    
    first_names = ["Adam", "Anna", "Piotr", "Maria", "Jan", "Katarzyna", "Tomasz", "Małgorzata", 
                  "Andrzej", "Barbara", "Paweł", "Krystyna", "Marek", "Ewa", "Michał"]
    
    last_names = ["Nowak", "Kowalski", "Wiśniewski", "Wójcik", "Kowalczyk", "Kamiński", "Lewandowski", 
                 "Zieliński", "Szymański", "Woźniak", "Dąbrowski", "Kozłowski", "Jankowski", "Mazur"]
    
    crew = []
    for i in range(1, 31):
        position = random.choices(positions, weights=position_weights)[0]
        qualification = random.choice(qualifications[position])
        base_airport = random.choice(airports)
        
        status_weights = [60, 30, 10]  # More likely to be available
        status = random.choices([CREW_STATUS_AVAILABLE, CREW_STATUS_ON_DUTY, CREW_STATUS_REST], weights=status_weights)[0]
        
        first_name = random.choice(first_names)
        last_name = random.choice(last_names)
        
        crew.append(Crew(
            employee_id=f'C{i:05d}',
            first_name=first_name,
            last_name=last_name,
            position=position,
            status=status,
            base_airport_id=base_airport.id,
            qualification=qualification,
            hours_flown=random.randint(1000, 15000),
            rest_hours_required=random.randint(8, 24),
            flight_duty_period=random.randint(0, 10) if status == CREW_STATUS_ON_DUTY else 0,
            contact_number=f'+48 5{random.randint(10, 99)} {random.randint(100, 999)} {random.randint(100, 999)}',
            email=f'{first_name.lower()}.{last_name.lower()}@polishairlines.pl'
        ))
    
    db.session.add_all(crew)
    db.session.commit()
    print(f"Created {len(crew)} crew members")
    
    # Create flights (without assigning crew)
    now = datetime.utcnow()
    today = now.date()
    yesterday = today - timedelta(days=1)
    tomorrow = today + timedelta(days=1)
    
    flight_numbers = [f'LO{random.randint(1, 9)}{random.randint(0, 9)}{random.randint(0, 9)}' for _ in range(20)]
    
    flights = []
    
    # Past flights (mostly completed)
    for i in range(10):
        departure_time = datetime.combine(yesterday, datetime.min.time()) + timedelta(hours=random.randint(6, 22))
        flight_duration = timedelta(hours=random.randint(1, 8))
        arrival_time = departure_time + flight_duration
        
        departure_airport = random.choice(airports)
        arrival_airport = random.choice([a for a in airports if a.id != departure_airport.id])
        
        # Randomly assign status with high probability of completion
        status_weights = [5, 5, 5, 85]  # Higher chance of completed
        status = random.choices([FLIGHT_STATUS_SCHEDULED, FLIGHT_STATUS_DELAYED, FLIGHT_STATUS_CANCELLED, FLIGHT_STATUS_COMPLETED], weights=status_weights)[0]
        
        # Set actual times based on status
        if status == FLIGHT_STATUS_COMPLETED:
            delay = timedelta(minutes=random.randint(-10, 30))  # Some flights are early, some are delayed
            actual_departure = departure_time + delay
            actual_arrival = arrival_time + delay
        elif status == FLIGHT_STATUS_DELAYED:
            delay = timedelta(minutes=random.randint(15, 120))
            actual_departure = departure_time + delay
            actual_arrival = arrival_time + delay
        else:
            actual_departure = None
            actual_arrival = None
        
        # Assign an aircraft
        aircraft_for_flight = random.choice(aircraft)
        
        flights.append(Flight(
            flight_number=random.choice(flight_numbers),
            departure_airport_id=departure_airport.id,
            arrival_airport_id=arrival_airport.id,
            scheduled_departure=departure_time,
            scheduled_arrival=arrival_time,
            actual_departure=actual_departure,
            actual_arrival=actual_arrival,
            status=status,
            aircraft_id=aircraft_for_flight.id,
            estimated_fuel=aircraft_for_flight.fuel_capacity * 0.8,
            passenger_count=random.randint(aircraft_for_flight.seat_capacity // 2, aircraft_for_flight.seat_capacity),
            distance=random.randint(300, 3000)
        ))
    
    # Today's flights (mix of statuses)
    for i in range(15):
        departure_time = datetime.combine(today, datetime.min.time()) + timedelta(hours=random.randint(6, 22))
        flight_duration = timedelta(hours=random.randint(1, 8))
        arrival_time = departure_time + flight_duration
        
        departure_airport = random.choice(airports)
        arrival_airport = random.choice([a for a in airports if a.id != departure_airport.id])
        
        # Status depends on current time
        if departure_time < now:
            status_weights = [10, 20, 5, 65]  # More completed flights as the day progresses
            status = random.choices([FLIGHT_STATUS_SCHEDULED, FLIGHT_STATUS_DELAYED, FLIGHT_STATUS_CANCELLED, FLIGHT_STATUS_COMPLETED], weights=status_weights)[0]
        else:
            status_weights = [80, 15, 5, 0]  # Future flights are mostly scheduled
            status = random.choices([FLIGHT_STATUS_SCHEDULED, FLIGHT_STATUS_DELAYED, FLIGHT_STATUS_CANCELLED, FLIGHT_STATUS_COMPLETED], weights=status_weights)[0]
        
        # Set actual times based on status
        if status == FLIGHT_STATUS_COMPLETED:
            delay = timedelta(minutes=random.randint(-10, 30))
            actual_departure = departure_time + delay
            actual_arrival = arrival_time + delay
        elif status == FLIGHT_STATUS_DELAYED:
            delay = timedelta(minutes=random.randint(15, 120))
            actual_departure = departure_time + delay if departure_time + delay < now else None
            actual_arrival = arrival_time + delay if departure_time + delay < now else None
        else:
            actual_departure = None
            actual_arrival = None
        
        # Assign an aircraft
        aircraft_for_flight = random.choice(aircraft)
        
        flights.append(Flight(
            flight_number=random.choice(flight_numbers),
            departure_airport_id=departure_airport.id,
            arrival_airport_id=arrival_airport.id,
            scheduled_departure=departure_time,
            scheduled_arrival=arrival_time,
            actual_departure=actual_departure,
            actual_arrival=actual_arrival,
            status=status,
            aircraft_id=aircraft_for_flight.id,
            estimated_fuel=aircraft_for_flight.fuel_capacity * 0.8,
            passenger_count=random.randint(aircraft_for_flight.seat_capacity // 2, aircraft_for_flight.seat_capacity),
            distance=random.randint(300, 3000)
        ))
    
    # Tomorrow's flights (mostly scheduled)
    for i in range(10):
        departure_time = datetime.combine(tomorrow, datetime.min.time()) + timedelta(hours=random.randint(6, 22))
        flight_duration = timedelta(hours=random.randint(1, 8))
        arrival_time = departure_time + flight_duration
        
        departure_airport = random.choice(airports)
        arrival_airport = random.choice([a for a in airports if a.id != departure_airport.id])
        
        # Future flights are almost all scheduled, with a few delayed/cancelled
        status_weights = [90, 7, 3, 0]  # High chance of scheduled
        status = random.choices([FLIGHT_STATUS_SCHEDULED, FLIGHT_STATUS_DELAYED, FLIGHT_STATUS_CANCELLED, FLIGHT_STATUS_COMPLETED], weights=status_weights)[0]
        
        actual_departure = None
        actual_arrival = None
        
        # Assign an aircraft
        aircraft_for_flight = random.choice(aircraft)
        
        flights.append(Flight(
            flight_number=random.choice(flight_numbers),
            departure_airport_id=departure_airport.id,
            arrival_airport_id=arrival_airport.id,
            scheduled_departure=departure_time,
            scheduled_arrival=arrival_time,
            actual_departure=actual_departure,
            actual_arrival=actual_arrival,
            status=status,
            aircraft_id=aircraft_for_flight.id,
            estimated_fuel=aircraft_for_flight.fuel_capacity * 0.8,
            passenger_count=random.randint(aircraft_for_flight.seat_capacity // 2, aircraft_for_flight.seat_capacity),
            distance=random.randint(300, 3000)
        ))
    
    db.session.add_all(flights)
    db.session.commit()
    print(f"Created {len(flights)} flights")
    
    # Create operational alerts
    alert_types = [
        'Weather Delay', 'Crew Unavailable', 'Aircraft Maintenance', 
        'ATC Restriction', 'Security Concern', 'Passenger Issue'
    ]
    
    alerts = []
    for i in range(12):
        alert_type = random.choice(alert_types)
        severity_weights = [40, 30, 20, 10]  # Most alerts are low severity
        severity = random.choices([ALERT_SEVERITY_LOW, ALERT_SEVERITY_MEDIUM, ALERT_SEVERITY_HIGH, ALERT_SEVERITY_CRITICAL], weights=severity_weights)[0]
        
        # Choose a flight, crew, or aircraft to attach to
        flight_for_alert = random.choice(flights) if random.random() < 0.7 else None
        crew_for_alert = random.choice(crew) if random.random() < 0.3 else None
        aircraft_for_alert = random.choice(aircraft) if random.random() < 0.3 else None
        
        # Create description based on type
        description = f"{alert_type} "
        if flight_for_alert:
            description += f"affecting flight {flight_for_alert.flight_number} "
        if crew_for_alert:
            description += f"involving crew member {crew_for_alert.first_name} {crew_for_alert.last_name} "
        if aircraft_for_alert:
            description += f"for aircraft {aircraft_for_alert.registration} "
        
        description += "requires attention."
        
        # Determine if alert is resolved
        is_resolved = random.random() < 0.4
        resolved_at = now - timedelta(hours=random.randint(1, 12)) if is_resolved else None
        resolution_notes = "Issue has been addressed." if is_resolved else None
        
        alerts.append(OperationalAlert(
            alert_type=alert_type,
            description=description,
            severity=severity,
            flight_id=flight_for_alert.id if flight_for_alert else None,
            crew_id=crew_for_alert.id if crew_for_alert else None,
            aircraft_id=aircraft_for_alert.id if aircraft_for_alert else None,
            created_at=now - timedelta(hours=random.randint(1, 24)),
            resolved_at=resolved_at,
            resolution_notes=resolution_notes
        ))
    
    db.session.add_all(alerts)
    db.session.commit()
    print(f"Created {len(alerts)} operational alerts")
    
    # Create operational decisions
    decision_types = [
        'Flight Delay', 'Flight Cancellation', 'Aircraft Substitution', 
        'Crew Reassignment', 'Schedule Change', 'Maintenance Deferral'
    ]
    
    decisions = []
    for i in range(8):
        decision_type = random.choice(decision_types)
        flight_for_decision = random.choice(flights)
        crew_for_decision = random.choice(crew) if random.random() < 0.5 else None
        aircraft_for_decision = random.choice(aircraft) if random.random() < 0.5 else None
        
        # Create description based on type
        description = f"{decision_type} "
        if flight_for_decision:
            description += f"for flight {flight_for_decision.flight_number} "
        if crew_for_decision:
            description += f"involving crew member {crew_for_decision.first_name} {crew_for_decision.last_name} "
        if aircraft_for_decision:
            description += f"using aircraft {aircraft_for_decision.registration} "
        
        description += "was implemented."
        
        # Determine if decision was implemented
        was_implemented = random.random() < 0.8
        implemented_at = now - timedelta(hours=random.randint(1, 24)) if was_implemented else None
        
        decisions.append(OperationalDecision(
            decision_type=decision_type,
            description=description,
            flight_id=flight_for_decision.id,
            crew_id=crew_for_decision.id if crew_for_decision else None,
            aircraft_id=aircraft_for_decision.id if aircraft_for_decision else None,
            created_at=now - timedelta(hours=random.randint(24, 72)),
            implemented_at=implemented_at,
            impact_score=random.randint(50, 95),
            cost_impact=random.randint(-5000, 5000),
            performance_impact="Improved schedule reliability and minimized passenger disruption.",
            made_by=random.choice(["Operations Control Center", "Duty Manager", "Chief Pilot", "System"])
        ))
    
    db.session.add_all(decisions)
    db.session.commit()
    print(f"Created {len(decisions)} operational decisions")
    
    print("Sample data creation complete!")

if __name__ == "__main__":
    with app.app_context():
        # Drop all existing tables and recreate them
        db.drop_all()
        db.create_all()
        create_sample_data()