import logging
from datetime import datetime, timedelta
import random  # For simulation purposes only

from models import (
    db, Crew, Aircraft, Flight, OperationalDecision,
    CREW_STATUS_AVAILABLE, AIRCRAFT_STATUS_AVAILABLE,
    FLIGHT_STATUS_SCHEDULED, FLIGHT_STATUS_DELAYED, FLIGHT_STATUS_CANCELLED
)

logger = logging.getLogger(__name__)

def generate_decision_options(simulation_type, flight, delay_minutes=0, cancellation_reason=None, crew_id=None, aircraft_id=None):
    """
    Generate decision options based on simulation parameters
    
    Parameters:
    - simulation_type: Type of disruption (delay, cancellation, crew_unavailable, aircraft_unavailable, 
      weather_disruption, air_traffic_restriction, airport_capacity, security_issue, passenger_medical,
      fuel_shortage, connection_management, airport_closure, mechanical_issue, ground_handling_delay,
      air_traffic_flow, slot_restriction, volcanic_ash, customs_immigration, runway_closure)
    - flight: Flight object being affected
    - delay_minutes: Minutes of delay (for delay simulation)
    - cancellation_reason: Reason for cancellation (for cancellation simulation)
    - crew_id: ID of unavailable crew (for crew_unavailable simulation)
    - aircraft_id: ID of unavailable aircraft (for aircraft_unavailable simulation)
    
    Returns:
    - List of decision options with impacts
    """
    options = []
    
    if simulation_type == 'delay':
        # Generate options for delay
        options.extend(generate_delay_options(flight, delay_minutes))
    
    elif simulation_type == 'cancellation':
        # Generate options for cancellation
        options.extend(generate_cancellation_options(flight, cancellation_reason))
    
    elif simulation_type == 'crew_unavailable':
        # Generate options for crew unavailability
        if crew_id:
            crew = Crew.query.get(crew_id)
            options.extend(generate_crew_unavailable_options(flight, crew))
    
    elif simulation_type == 'aircraft_unavailable':
        # Generate options for aircraft unavailability
        if aircraft_id:
            aircraft = Aircraft.query.get(aircraft_id)
            options.extend(generate_aircraft_unavailable_options(flight, aircraft))
            
    elif simulation_type == 'weather_disruption':
        # Generate options for severe weather disruption
        options.extend(generate_weather_disruption_options(flight))
        
    elif simulation_type == 'air_traffic_restriction':
        # Generate options for air traffic control restrictions
        options.extend(generate_air_traffic_restriction_options(flight))
        
    elif simulation_type == 'airport_capacity':
        # Generate options for airport capacity constraints
        options.extend(generate_airport_capacity_options(flight))
        
    elif simulation_type == 'security_issue':
        # Generate options for security-related disruptions
        options.extend(generate_security_issue_options(flight))
        
    elif simulation_type == 'passenger_medical':
        # Generate options for passenger medical emergencies
        options.extend(generate_passenger_medical_options(flight))
        
    elif simulation_type == 'fuel_shortage':
        # Generate options for fuel shortage at departure airport
        options.extend(generate_fuel_shortage_options(flight))
        
    elif simulation_type == 'connection_management':
        # Generate options for managing connecting passengers
        options.extend(generate_connection_management_options(flight))
        
    elif simulation_type == 'airport_closure':
        # Generate options for airport closure
        options.extend(generate_airport_closure_options(flight))
        
    elif simulation_type == 'mechanical_issue':
        # Generate options for mechanical issues
        options.extend(generate_mechanical_issue_options(flight))
        
    elif simulation_type == 'ground_handling_delay':
        # Generate options for ground handling delays
        options.extend(generate_ground_handling_delay_options(flight))
        
    elif simulation_type == 'air_traffic_flow':
        # Generate options for air traffic flow management
        options.extend(generate_air_traffic_flow_options(flight))
        
    elif simulation_type == 'slot_restriction':
        # Generate options for slot restriction issues
        options.extend(generate_slot_restriction_options(flight))
        
    elif simulation_type == 'volcanic_ash':
        # Generate options for volcanic ash cloud disruptions
        options.extend(generate_volcanic_ash_options(flight))
        
    elif simulation_type == 'customs_immigration':
        # Generate options for customs and immigration issues
        options.extend(generate_customs_immigration_options(flight))
        
    elif simulation_type == 'runway_closure':
        # Generate options for runway closure
        options.extend(generate_runway_closure_options(flight))
    
    # Add a "do nothing" option for comparison
    options.append({
        'type': 'no_action',
        'description': 'Take no action',
        'impact_score': 0,
        'cost_impact': 0,
        'performance_impact': 'No change to current metrics'
    })
    
    return options

def generate_delay_options(flight, delay_minutes):
    """Generate options for handling a flight delay"""
    options = []
    
    # Option 1: Accept the delay
    options.append({
        'type': 'accept_delay',
        'description': f'Accept {delay_minutes} minute delay for flight {flight.flight_number}',
        'impact_score': calculate_delay_impact_score(delay_minutes),
        'cost_impact': calculate_delay_cost(delay_minutes, flight.passenger_count),
        'performance_impact': f'Reduced OTP, potential passenger connections missed'
    })
    
    # Option 2: Speed up turnaround
    if delay_minutes <= 30:
        options.append({
            'type': 'expedite_turnaround',
            'description': f'Expedite turnaround to reduce delay to {max(0, delay_minutes - 15)} minutes',
            'impact_score': calculate_delay_impact_score(max(0, delay_minutes - 15)),
            'cost_impact': 500,  # Cost of expedited handling
            'performance_impact': 'Improved OTP, increased ground handling workload'
        })
    
    # Option 3: Cancel flight if delay is very long
    if delay_minutes >= 120:
        options.append({
            'type': 'cancel_flight',
            'description': f'Cancel flight {flight.flight_number} due to excessive delay',
            'impact_score': 80,  # Significant impact
            'cost_impact': calculate_cancellation_cost(flight.passenger_count),
            'performance_impact': 'Reduced completion factor, major passenger disruption, aircraft/crew repositioning needed'
        })
    
    # Option 4: Swap aircraft if available
    available_aircraft = Aircraft.query.filter(
        Aircraft.status == AIRCRAFT_STATUS_AVAILABLE,
        Aircraft.aircraft_type == flight.aircraft.aircraft_type,
        Aircraft.current_airport_id == flight.departure_airport_id
    ).first()
    
    if available_aircraft:
        options.append({
            'type': 'swap_aircraft',
            'description': f'Swap to aircraft {available_aircraft.registration} to minimize delay',
            'impact_score': calculate_delay_impact_score(10),  # Assume small delay for swap
            'cost_impact': 1000,  # Cost of swap operation
            'performance_impact': 'Improved OTP, minimal passenger disruption, aircraft repositioning needed'
        })
    
    return options

def generate_cancellation_options(flight, reason):
    """Generate options for handling a flight cancellation"""
    options = []
    
    # Option 1: Accept cancellation and rebook passengers
    options.append({
        'type': 'accept_cancellation',
        'description': f'Cancel flight {flight.flight_number} and rebook passengers',
        'impact_score': 80,
        'cost_impact': calculate_cancellation_cost(flight.passenger_count),
        'performance_impact': 'Reduced completion factor, major passenger disruption'
    })
    
    # Option 2: Delay flight substantially instead of cancelling
    options.append({
        'type': 'delay_instead_cancel',
        'description': f'Delay flight {flight.flight_number} by 4 hours instead of cancelling',
        'impact_score': 50,
        'cost_impact': calculate_delay_cost(240, flight.passenger_count),
        'performance_impact': 'Reduced OTP, moderate passenger disruption, maintain completion factor'
    })
    
    # Option 3: Charter replacement aircraft
    options.append({
        'type': 'charter_aircraft',
        'description': f'Charter replacement aircraft for flight {flight.flight_number}',
        'impact_score': 30,
        'cost_impact': 25000,  # Significant cost for charter
        'performance_impact': 'Maintain completion factor, moderate delay, high operational cost'
    })
    
    return options

def generate_crew_unavailable_options(flight, unavailable_crew):
    """Generate options for handling crew unavailability"""
    options = []
    
    # Get position of unavailable crew
    position = unavailable_crew.position
    
    # Option 1: Find replacement crew
    available_crew = Crew.query.filter(
        Crew.status == CREW_STATUS_AVAILABLE,
        Crew.position == position,
        Crew.base_airport_id == flight.departure_airport_id
    ).first()
    
    if available_crew:
        options.append({
            'type': 'replace_crew',
            'description': f'Replace with available crew member: {available_crew.first_name} {available_crew.last_name}',
            'impact_score': 10,
            'cost_impact': 0,
            'performance_impact': 'Minimal disruption, normal operations maintained'
        })
    
    # Option 2: Deadhead crew from another location
    options.append({
        'type': 'deadhead_crew',
        'description': f'Deadhead crew from nearest base to cover position',
        'impact_score': 30,
        'cost_impact': 1500,  # Cost of deadheading
        'performance_impact': 'Moderate delay, increased operational cost'
    })
    
    # Option 3: Delay flight waiting for crew
    options.append({
        'type': 'delay_for_crew',
        'description': f'Delay flight by 2 hours to wait for next available crew',
        'impact_score': 40,
        'cost_impact': calculate_delay_cost(120, flight.passenger_count),
        'performance_impact': 'Reduced OTP, passenger disruption'
    })
    
    # Option 4: Operate with minimum crew if possible
    if position == 'flight_attendant':
        options.append({
            'type': 'minimum_crew',
            'description': 'Operate with minimum required cabin crew',
            'impact_score': 20,
            'cost_impact': 0,
            'performance_impact': 'Minimal delay, reduced onboard service'
        })
    
    return options

def generate_aircraft_unavailable_options(flight, unavailable_aircraft):
    """Generate options for handling aircraft unavailability"""
    options = []
    
    # Option 1: Find replacement aircraft of same type
    replacement_aircraft = Aircraft.query.filter(
        Aircraft.status == AIRCRAFT_STATUS_AVAILABLE,
        Aircraft.aircraft_type == unavailable_aircraft.aircraft_type,
        Aircraft.current_airport_id == flight.departure_airport_id
    ).first()
    
    if replacement_aircraft:
        options.append({
            'type': 'replace_aircraft_same_type',
            'description': f'Replace with available aircraft: {replacement_aircraft.registration} (same type)',
            'impact_score': 10,
            'cost_impact': 500,  # Minor cost for swap
            'performance_impact': 'Minimal disruption, normal operations maintained'
        })
    
    # Option 2: Find replacement aircraft of different type
    diff_replacement_aircraft = Aircraft.query.filter(
        Aircraft.status == AIRCRAFT_STATUS_AVAILABLE,
        Aircraft.aircraft_type != unavailable_aircraft.aircraft_type,
        Aircraft.current_airport_id == flight.departure_airport_id
    ).first()
    
    if diff_replacement_aircraft:
        capacity_diff = diff_replacement_aircraft.seat_capacity - unavailable_aircraft.seat_capacity
        if capacity_diff < 0:
            impact_desc = f'Downsize with smaller aircraft ({abs(capacity_diff)} fewer seats)'
            impact_score = 40
            cost = calculate_downgauge_cost(abs(capacity_diff), flight.passenger_count)
        else:
            impact_desc = f'Upgrade with larger aircraft ({capacity_diff} extra seats)'
            impact_score = 20
            cost = 1000  # Cost of operating larger aircraft
        
        options.append({
            'type': 'replace_aircraft_diff_type',
            'description': f'Replace with {diff_replacement_aircraft.registration}: {impact_desc}',
            'impact_score': impact_score,
            'cost_impact': cost,
            'performance_impact': 'Flight maintained with different capacity, potential rebooking needed'
        })
    
    # Option 3: Ferry aircraft from another station
    options.append({
        'type': 'ferry_aircraft',
        'description': 'Ferry replacement aircraft from nearest station',
        'impact_score': 50,
        'cost_impact': 5000,  # High cost for ferry
        'performance_impact': 'Significant delay, high operational cost, impacts multiple flights'
    })
    
    # Option 4: Delay flight waiting for maintenance
    if unavailable_aircraft.status == 'maintenance':
        est_repair_time = random.randint(1, 6)  # Simulated repair time in hours
        options.append({
            'type': 'wait_for_maintenance',
            'description': f'Delay flight {est_repair_time} hours until aircraft maintenance complete',
            'impact_score': calculate_delay_impact_score(est_repair_time * 60),
            'cost_impact': calculate_delay_cost(est_repair_time * 60, flight.passenger_count),
            'performance_impact': f'Reduced OTP, passenger disruption, aircraft utilization maintained'
        })
    
    return options

def calculate_delay_impact_score(delay_minutes):
    """Calculate impact score based on delay duration"""
    if delay_minutes <= 15:
        return 10  # Minor impact
    elif delay_minutes <= 60:
        return 30  # Moderate impact
    elif delay_minutes <= 180:
        return 60  # Significant impact
    else:
        return 80  # Major impact

def calculate_delay_cost(delay_minutes, passenger_count):
    """Calculate approximate cost of delay"""
    # Base cost per minute
    cost_per_minute = 20
    
    # Additional cost per passenger per minute
    pax_cost_per_minute = 0.5
    
    # Calculate total cost
    base_cost = cost_per_minute * delay_minutes
    passenger_cost = pax_cost_per_minute * delay_minutes * passenger_count
    
    # Additional costs for long delays (EU261 compensation, etc.)
    if delay_minutes > 180:
        eu261_compensation = passenger_count * 250  # Simplified EU261 compensation
    else:
        eu261_compensation = 0
    
    return base_cost + passenger_cost + eu261_compensation

def calculate_cancellation_cost(passenger_count):
    """Calculate approximate cost of cancellation"""
    # Base cancellation cost
    base_cost = 10000
    
    # Passenger rebooking and compensation cost
    passenger_cost = passenger_count * 400
    
    # EU261 compensation
    eu261_compensation = passenger_count * 400  # Simplified EU261 compensation
    
    return base_cost + passenger_cost + eu261_compensation

def calculate_downgauge_cost(seat_reduction, passenger_count):
    """Calculate cost of downsizing aircraft"""
    # If we need to rebook passengers due to smaller aircraft
    if passenger_count > seat_reduction:
        passengers_to_rebook = passenger_count - seat_reduction
        rebooking_cost = passengers_to_rebook * 300
        return rebooking_cost
    else:
        return 0
        
def generate_weather_disruption_options(flight):
    """Generate options for severe weather disruption"""
    options = []
    
    # Option 1: Delay the flight until weather improves
    est_weather_delay = random.randint(60, 240)  # Estimated delay in minutes
    options.append({
        'type': 'weather_delay',
        'description': f'Delay flight {flight.flight_number} by {est_weather_delay} minutes until weather improves',
        'impact_score': calculate_delay_impact_score(est_weather_delay),
        'cost_impact': calculate_delay_cost(est_weather_delay, flight.passenger_count),
        'performance_impact': 'Reduced OTP, potential passenger connections missed, but maintained safety'
    })
    
    # Option 2: Divert to alternate airport
    options.append({
        'type': 'weather_diversion',
        'description': f'Divert flight {flight.flight_number} to nearest alternate airport',
        'impact_score': 70,
        'cost_impact': 15000,  # High cost due to ground transport, handling at alternate airport
        'performance_impact': 'Significant disruption, high passenger inconvenience, additional ground logistics required'
    })
    
    # Option 3: Cancel flight due to severe weather
    options.append({
        'type': 'weather_cancellation',
        'description': f'Cancel flight {flight.flight_number} due to severe weather conditions',
        'impact_score': 80,
        'cost_impact': calculate_cancellation_cost(flight.passenger_count) * 0.7,  # Reduced compensation due to weather (force majeure)
        'performance_impact': 'Major disruption, but may be unavoidable for safety reasons'
    })
    
    # Option 4: Operate via alternative routing 
    options.append({
        'type': 'alternative_routing',
        'description': f'Fly longer route to avoid severe weather, adding 40 minutes to flight time',
        'impact_score': 30,
        'cost_impact': 3000 + calculate_delay_cost(40, flight.passenger_count),  # Extra fuel + delay costs
        'performance_impact': 'Moderate delay, increased fuel consumption, but maintained schedule integrity'
    })
    
    return options

def generate_air_traffic_restriction_options(flight):
    """Generate options for air traffic control restrictions"""
    options = []
    
    # Option 1: Accept ATC slot delay
    slot_delay = random.randint(30, 180)  # Air traffic slot delay in minutes
    options.append({
        'type': 'accept_atc_delay',
        'description': f'Accept {slot_delay} minute ATC slot delay for flight {flight.flight_number}',
        'impact_score': calculate_delay_impact_score(slot_delay),
        'cost_impact': calculate_delay_cost(slot_delay, flight.passenger_count),
        'performance_impact': 'Reduced OTP, potential passenger connections missed'
    })
    
    # Option 2: Request priority handling (if available)
    options.append({
        'type': 'request_priority',
        'description': 'Request priority handling from ATC due to operational constraints',
        'impact_score': 15,
        'cost_impact': 1000,  # Administrative/relationship cost
        'performance_impact': 'Potential improvement in delay, but not guaranteed and may affect future cooperation'
    })
    
    # Option 3: Change flight level to avoid congested airspace
    options.append({
        'type': 'change_flight_level',
        'description': 'Change flight level to avoid congested airspace, adding 15 minutes to flight time',
        'impact_score': 20,
        'cost_impact': 1200,  # Extra fuel costs + minor delay costs
        'performance_impact': 'Minor delay, slight increase in fuel consumption'
    })
    
    # Option 4: Reroute flight plan
    options.append({
        'type': 'reroute_flight_plan',
        'description': 'File new flight plan with alternative routing to avoid congested airspace',
        'impact_score': 30,
        'cost_impact': 2000,  # Extra fuel and operational costs
        'performance_impact': 'Moderate increase in flight time and fuel consumption'
    })
    
    return options

def generate_airport_capacity_options(flight):
    """Generate options for airport capacity constraints"""
    options = []
    
    # Option 1: Accept delay due to airport congestion
    capacity_delay = random.randint(45, 150)  # Capacity-related delay in minutes
    options.append({
        'type': 'accept_capacity_delay',
        'description': f'Accept {capacity_delay} minute delay due to airport capacity constraints',
        'impact_score': calculate_delay_impact_score(capacity_delay),
        'cost_impact': calculate_delay_cost(capacity_delay, flight.passenger_count),
        'performance_impact': 'Reduced OTP, potential passenger connections missed'
    })
    
    # Option 2: Divert to alternative airport
    options.append({
        'type': 'capacity_diversion',
        'description': f'Divert to alternate airport with better capacity',
        'impact_score': 70,
        'cost_impact': 12000,  # Diversion costs
        'performance_impact': 'Major disruption, additional ground transport required'
    })
    
    # Option 3: Request special handling
    options.append({
        'type': 'request_special_handling',
        'description': 'Request special handling at congested airport (remote stand, bus boarding)',
        'impact_score': 25,
        'cost_impact': 1500,  # Extra handling costs
        'performance_impact': 'Improved punctuality but reduced passenger experience'
    })
    
    # Option 4: Adjust schedule for next rotation
    options.append({
        'type': 'adjust_next_rotation',
        'description': 'Accept current delay but adjust next flight in rotation to recover schedule',
        'impact_score': 40,
        'cost_impact': 3000,  # Recovery costs
        'performance_impact': 'Current flight delayed but minimizes network impact'
    })
    
    return options

def generate_security_issue_options(flight):
    """Generate options for security-related disruptions"""
    options = []
    
    # Option 1: Additional security screening 
    options.append({
        'type': 'additional_screening',
        'description': 'Conduct additional security screening for all passengers and baggage',
        'impact_score': 40,
        'cost_impact': 2000 + calculate_delay_cost(45, flight.passenger_count),  # Security costs + delay
        'performance_impact': 'Delay of approximately 45 minutes, but ensures security compliance'
    })
    
    # Option 2: Deplane and security re-screening
    options.append({
        'type': 'security_rescreening',
        'description': 'Deplane all passengers for complete security re-screening',
        'impact_score': 70,
        'cost_impact': 5000 + calculate_delay_cost(120, flight.passenger_count),  # Operational costs + delay
        'performance_impact': 'Major delay but ensures thorough security check'
    })
    
    # Option 3: Security-related cancellation
    options.append({
        'type': 'security_cancellation',
        'description': 'Cancel flight for comprehensive security investigation',
        'impact_score': 90,
        'cost_impact': calculate_cancellation_cost(flight.passenger_count),
        'performance_impact': 'Maximum disruption but addresses security concerns completely'
    })
    
    # Option 4: Targeted security measures
    options.append({
        'type': 'targeted_security',
        'description': 'Implement targeted security measures on specific risk areas',
        'impact_score': 20,
        'cost_impact': 1000 + calculate_delay_cost(20, flight.passenger_count),  # Security costs + minor delay
        'performance_impact': 'Minor delay with focused security response'
    })
    
    return options

def generate_passenger_medical_options(flight):
    """Generate options for passenger medical emergencies"""
    options = []
    
    # Option 1: Wait for medical assistance at gate
    options.append({
        'type': 'gate_medical_assistance',
        'description': 'Delay departure to provide medical assistance at gate',
        'impact_score': 30,
        'cost_impact': 1000 + calculate_delay_cost(30, flight.passenger_count),  # Medical costs + delay
        'performance_impact': 'Minor delay, but ensures passenger wellbeing'
    })
    
    # Option 2: Divert in-flight for medical emergency
    options.append({
        'type': 'medical_diversion',
        'description': 'Simulate in-flight diversion to nearest suitable airport',
        'impact_score': 80,
        'cost_impact': 20000,  # High cost of diversion
        'performance_impact': 'Major disruption but necessary for passenger safety'
    })
    
    # Option 3: Request medical professional onboard
    options.append({
        'type': 'onboard_medical_professional',
        'description': 'Request if any medical professionals are among passengers',
        'impact_score': 10,
        'cost_impact': 500,  # Nominal compensation/gratitude 
        'performance_impact': 'Minimal disruption, leverages onboard resources'
    })
    
    # Option 4: Contact medical advisory service
    options.append({
        'type': 'medical_advisory',
        'description': 'Contact airline medical advisory service for guidance',
        'impact_score': 15,
        'cost_impact': 800,  # Service fee
        'performance_impact': 'Minimal disruption, expert medical decision support'
    })
    
    return options

def generate_fuel_shortage_options(flight):
    """Generate options for fuel shortage at departure airport"""
    options = []
    
    # Option 1: Wait for fuel delivery
    fuel_delay = random.randint(30, 120)  # Delay in minutes
    options.append({
        'type': 'wait_for_fuel',
        'description': f'Wait {fuel_delay} minutes for fuel delivery to airport',
        'impact_score': calculate_delay_impact_score(fuel_delay),
        'cost_impact': calculate_delay_cost(fuel_delay, flight.passenger_count),
        'performance_impact': 'Operational delay but ensures sufficient fuel'
    })
    
    # Option 2: Tanker fuel (carry extra)
    options.append({
        'type': 'tanker_fuel',
        'description': 'Carry extra fuel from previous airport (tankering)',
        'impact_score': 15,
        'cost_impact': 3000,  # Extra fuel weight cost
        'performance_impact': 'Minimal delay, higher fuel consumption due to extra weight'
    })
    
    # Option 3: Reduce fuel load
    options.append({
        'type': 'reduce_fuel',
        'description': 'Reduce fuel load to minimum required + reserves',
        'impact_score': 30,
        'cost_impact': 1000,  # Operational cost + potential diversion risk
        'performance_impact': 'Reduced flexibility, may require en-route stop'
    })
    
    # Option 4: Fly to nearby airport for fuel
    options.append({
        'type': 'fuel_stop',
        'description': 'Add technical stop at nearby airport for refueling',
        'impact_score': 60,
        'cost_impact': 8000,  # High operational cost
        'performance_impact': 'Significant delay, additional landing/takeoff cycle'
    })
    
    return options

def generate_connection_management_options(flight):
    """Generate options for managing connecting passengers"""
    options = []
    
    # Option 1: Hold connecting flights
    options.append({
        'type': 'hold_connections',
        'description': 'Hold connecting flights for passengers from this flight',
        'impact_score': 45,
        'cost_impact': 5000,  # Network impact cost
        'performance_impact': 'Cascading delays in network but improved connectivity'
    })
    
    # Option 2: Rebook connecting passengers
    options.append({
        'type': 'rebook_connections',
        'description': 'Rebook connecting passengers on later flights',
        'impact_score': 30,
        'cost_impact': 8000,  # Rebooking costs
        'performance_impact': 'Passenger inconvenience but minimized network impact'
    })
    
    # Option 3: Expedite current flight
    options.append({
        'type': 'expedite_flight',
        'description': 'Request expedited handling and direct routing to minimize delay',
        'impact_score': 20,
        'cost_impact': 3000,  # Operational cost
        'performance_impact': 'Potential recovery of some connection time'
    })
    
    # Option 4: Arrange ground transportation
    options.append({
        'type': 'ground_transport',
        'description': 'Arrange ground transportation for short-haul connecting destinations',
        'impact_score': 35,
        'cost_impact': 10000,  # Transportation costs
        'performance_impact': 'Alternative transport solution for affected passengers'
    })
    
    return options

def evaluate_decision(decision):
    """
    Evaluate actual impact of an implemented decision
    This would typically compare predicted vs actual metrics
    """
    # This is simplified - in a real system, we would pull actual operational data
    # and calculate the difference between predicted and actual impact
    
    # For demo purposes, we'll just simulate some variation around the predicted impact
    variation = random.uniform(0.8, 1.2)  # 20% variation up or down
    
    actual_impact = {
        'predicted_impact_score': decision.impact_score,
        'actual_impact_score': int(decision.impact_score * variation),
        'predicted_cost': decision.cost_impact,
        'actual_cost': round(decision.cost_impact * variation, 2),
        'effectiveness': 'Good' if variation <= 1.1 else 'Poor',
        'notes': 'Decision impact was as expected' if variation <= 1.1 else 'Decision had higher than expected impact'
    }
    
    return actual_impact

def implement_decision(decision_id, flight):
    """
    Implement a selected decision
    
    Parameters:
    - decision_id: ID of the selected decision
    - flight: Flight object to apply the decision to
    
    Returns:
    - (success, message) tuple
    """
    # This is a simplified implementation
    try:
        # Create record of the decision
        decision = OperationalDecision(
            decision_type=f"simulation_{decision_id}",
            description=f"Implemented simulation decision {decision_id} for flight {flight.flight_number}",
            flight_id=flight.id,
            aircraft_id=flight.aircraft_id,
            implemented_at=datetime.utcnow(),
            impact_score=50,  # Placeholder
            cost_impact=1000,  # Placeholder
            performance_impact="Simulation decision implemented",
            made_by="Operator"
        )
        
        db.session.add(decision)
        
        # Apply changes to flight status based on decision type
        if decision_id == 1:  # Example: Accept delay
            flight.status = FLIGHT_STATUS_DELAYED
            flight.actual_departure = flight.scheduled_departure + timedelta(minutes=30)
        elif decision_id == 2:  # Example: Cancel flight
            flight.status = FLIGHT_STATUS_CANCELLED
        # Add more decision implementations as needed
        
        db.session.commit()
        return True, "Decision implemented successfully"
    
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error implementing decision: {str(e)}")
        return False, f"Error: {str(e)}"
