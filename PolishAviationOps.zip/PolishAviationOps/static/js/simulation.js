/**
 * Polish Airlines Operations Management System
 * Simulation JavaScript
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize simulation form handlers
    initializeSimulationForm();
    
    // Initialize decision options handlers if on results page
    initializeDecisionOptions();
});

/**
 * Initialize the simulation form controls and dynamic behavior
 */
function initializeSimulationForm() {
    const simulationForm = document.getElementById('simulationForm');
    if (!simulationForm) return;
    
    const simulationType = document.getElementById('simulationType');
    const flightSelect = document.getElementById('flightSelect');
    
    // Additional form sections that appear based on simulation type
    const delayOptions = document.getElementById('delayOptions');
    const cancellationOptions = document.getElementById('cancellationOptions');
    const crewOptions = document.getElementById('crewOptions');
    const aircraftOptions = document.getElementById('aircraftOptions');
    
    // When simulation type changes, show/hide relevant form sections
    if (simulationType) {
        simulationType.addEventListener('change', function() {
            // Hide all options first
            if (delayOptions) delayOptions.classList.add('d-none');
            if (cancellationOptions) cancellationOptions.classList.add('d-none');
            if (crewOptions) crewOptions.classList.add('d-none');
            if (aircraftOptions) aircraftOptions.classList.add('d-none');
            
            // Show relevant options based on selected type
            switch (this.value) {
                case 'delay':
                    if (delayOptions) delayOptions.classList.remove('d-none');
                    break;
                case 'cancellation':
                    if (cancellationOptions) cancellationOptions.classList.remove('d-none');
                    break;
                case 'crew_unavailable':
                    if (crewOptions) crewOptions.classList.remove('d-none');
                    break;
                case 'aircraft_unavailable':
                    if (aircraftOptions) aircraftOptions.classList.remove('d-none');
                    break;
            }
        });
    }
    
    // When flight is selected, load flight details
    if (flightSelect) {
        flightSelect.addEventListener('change', function() {
            const flightId = this.value;
            if (flightId) {
                loadFlightDetails(flightId);
            }
        });
    }
    
    // Initialize any required select2 dropdowns for better UX
    initializeSelect2();
    
    // Form validation before submission
    if (simulationForm) {
        simulationForm.addEventListener('submit', function(e) {
            if (!validateSimulationForm()) {
                e.preventDefault();
            }
        });
    }
}

/**
 * Load flight details for the selected flight
 */
function loadFlightDetails(flightId) {
    const flightDetails = document.getElementById('flightDetails');
    if (!flightDetails) return;
    
    // Show loading indicator
    flightDetails.innerHTML = '<div class="text-center"><div class="spinner-border text-primary" role="status"><span class="sr-only">Loading...</span></div></div>';
    flightDetails.classList.remove('d-none');
    
    // Fetch flight details
    fetch(`/api/flight/${flightId}`)
        .then(response => response.json())
        .then(data => {
            if (data.flight) {
                const flight = data.flight;
                
                let html = `
                    <div class="card">
                        <div class="card-header">
                            <strong>Flight ${flight.flight_number}</strong>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <p><strong>Route:</strong> ${flight.departure_airport} to ${flight.arrival_airport}</p>
                                    <p><strong>Scheduled Departure:</strong> ${flight.scheduled_departure}</p>
                                    <p><strong>Scheduled Arrival:</strong> ${flight.scheduled_arrival}</p>
                                </div>
                                <div class="col-md-6">
                                    <p><strong>Aircraft:</strong> ${flight.aircraft}</p>
                                    <p><strong>Status:</strong> <span class="status-badge ${flight.status.toLowerCase()}">${flight.status}</span></p>
                                    <p><strong>Passengers:</strong> ${flight.passenger_count}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                `;
                
                flightDetails.innerHTML = html;
            } else {
                flightDetails.innerHTML = '<div class="alert alert-warning">Flight details not found.</div>';
            }
        })
        .catch(error => {
            console.error('Error loading flight details:', error);
            flightDetails.innerHTML = '<div class="alert alert-danger">Error loading flight details.</div>';
        });
}

/**
 * Initialize select2 for dropdowns if the library is available
 */
function initializeSelect2() {
    if (typeof $.fn.select2 === 'function') {
        $('#flightSelect').select2({
            placeholder: 'Select a flight',
            allowClear: true,
            width: '100%'
        });
        
        $('#crewSelect').select2({
            placeholder: 'Select crew member',
            allowClear: true,
            width: '100%'
        });
        
        $('#aircraftSelect').select2({
            placeholder: 'Select aircraft',
            allowClear: true,
            width: '100%'
        });
    }
}

/**
 * Validate the simulation form before submission
 */
function validateSimulationForm() {
    const simulationType = document.getElementById('simulationType');
    const flightSelect = document.getElementById('flightSelect');
    
    if (!simulationType || !simulationType.value) {
        alert('Please select a simulation type.');
        return false;
    }
    
    if (!flightSelect || !flightSelect.value) {
        alert('Please select a flight for simulation.');
        return false;
    }
    
    // Validate type-specific fields
    switch (simulationType.value) {
        case 'delay':
            const delayMinutes = document.getElementById('delayMinutes');
            if (!delayMinutes || !delayMinutes.value) {
                alert('Please enter delay minutes.');
                return false;
            }
            break;
            
        case 'cancellation':
            const cancellationReason = document.getElementById('cancellationReason');
            if (!cancellationReason || !cancellationReason.value) {
                alert('Please select a cancellation reason.');
                return false;
            }
            break;
            
        case 'crew_unavailable':
            const crewSelect = document.getElementById('crewSelect');
            if (!crewSelect || !crewSelect.value) {
                alert('Please select an unavailable crew member.');
                return false;
            }
            break;
            
        case 'aircraft_unavailable':
            const aircraftSelect = document.getElementById('aircraftSelect');
            if (!aircraftSelect || !aircraftSelect.value) {
                alert('Please select an unavailable aircraft.');
                return false;
            }
            break;
    }
    
    return true;
}

/**
 * Initialize decision options in the simulation results
 */
function initializeDecisionOptions() {
    const decisionOptions = document.querySelectorAll('.decision-option');
    if (!decisionOptions.length) return;
    
    decisionOptions.forEach(option => {
        option.addEventListener('click', function() {
            // Remove selected class from all options
            decisionOptions.forEach(opt => opt.classList.remove('selected'));
            
            // Add selected class to the clicked option
            this.classList.add('selected');
            
            // Set the decision ID in the hidden field
            const decisionId = this.dataset.decisionId;
            const decisionIdField = document.getElementById('selectedDecisionId');
            if (decisionIdField) {
                decisionIdField.value = decisionId;
            }
            
            // Enable the implement button
            const implementButton = document.getElementById('implementButton');
            if (implementButton) {
                implementButton.disabled = false;
            }
        });
    });
}
