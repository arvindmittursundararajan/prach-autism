document.addEventListener('DOMContentLoaded', function() {
    // Check if the radar chart container exists
    const radarChartContainer = document.getElementById('radarChart');
    if (!radarChartContainer) return;

    // Get radar chart data from the data element
    let behaviorScore = parseFloat(radarChartContainer.dataset.behavior) || 0;
    let sensoryScore = parseFloat(radarChartContainer.dataset.sensory) || 0;
    let socialScore = parseFloat(radarChartContainer.dataset.social) || 0;
    let communicationScore = parseFloat(radarChartContainer.dataset.communication) || 0;
    let cognitiveScore = parseFloat(radarChartContainer.dataset.cognitive) || 0;

    // Create the radar chart
    const ctx = radarChartContainer.getContext('2d');
    
    new Chart(ctx, {
        type: 'radar',
        data: {
            labels: ['Behavior', 'Sensory', 'Social', 'Communication', 'Cognitive'],
            datasets: [{
                label: 'Assessment Scores',
                data: [
                    behaviorScore,
                    sensoryScore,
                    socialScore,
                    communicationScore,
                    cognitiveScore
                ],
                backgroundColor: 'rgba(52, 152, 219, 0.2)',
                borderColor: 'rgba(52, 152, 219, 1)',
                pointBackgroundColor: 'rgba(52, 152, 219, 1)',
                pointBorderColor: '#fff',
                pointHoverBackgroundColor: '#fff',
                pointHoverBorderColor: 'rgba(52, 152, 219, 1)'
            }]
        },
        options: {
            scales: {
                r: {
                    angleLines: {
                        display: true
                    },
                    suggestedMin: 0,
                    suggestedMax: 5,
                    ticks: {
                        stepSize: 1
                    }
                }
            },
            plugins: {
                legend: {
                    display: true,
                    position: 'top'
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            let label = context.dataset.label || '';
                            if (label) {
                                label += ': ';
                            }
                            if (context.parsed.r !== null) {
                                label += context.parsed.r;
                            }
                            return label;
                        }
                    }
                }
            }
        }
    });
});
