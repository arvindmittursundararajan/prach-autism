/**
 * Goals page functionality
 */

function initializeGoalsPage() {
    // Add event listener to generate goals button
    const generateBtn = document.getElementById('generateGoalsBtn');
    if (generateBtn) {
        generateBtn.addEventListener('click', generateGoals);
    }
    
    // Add event listener to add goal button
    const addGoalBtn = document.getElementById('addGoalBtn');
    if (addGoalBtn) {
        addGoalBtn.addEventListener('click', showAddGoalModal);
    }
    
    // Attach event listeners to goal status change dropdowns
    attachStatusChangeListeners();
}

/**
 * Generate goals using AI
 */
function generateGoals() {
    const patientId = document.getElementById('patientId').value;
    const generateBtn = document.getElementById('generateGoalsBtn');
    const loadingSpinner = document.getElementById('goalsLoadingSpinner');
    
    // Show loading spinner
    generateBtn.classList.add('d-none');
    loadingSpinner.classList.remove('d-none');
    
    // Make API call to generate goals
    fetch(`/patient/${patientId}/generate_goals`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        }
    })
    .then(response => response.json())
    .then(data => {
        // Hide loading spinner
        generateBtn.classList.remove('d-none');
        loadingSpinner.classList.add('d-none');
        
        if (data.success) {
            showAlert('Goals generated successfully! Refreshing page...', 'success');
            // Refresh the page to show new goals
            setTimeout(() => {
                window.location.reload();
            }, 1500);
        } else {
            showAlert(`Error: ${data.error || 'Failed to generate goals'}`, 'danger');
        }
    })
    .catch(error => {
        // Hide loading spinner
        generateBtn.classList.remove('d-none');
        loadingSpinner.classList.add('d-none');
        
        console.error('Error:', error);
        showAlert('An error occurred while generating goals', 'danger');
    });
}

/**
 * Attach event listeners to goal status change dropdowns
 */
function attachStatusChangeListeners() {
    document.querySelectorAll('.goal-status-select').forEach(select => {
        select.addEventListener('change', function() {
            const goalId = this.getAttribute('data-goal-id');
            const newStatus = this.value;
            const cardElement = this.closest('.goal-card');
            
            updateGoalStatus(goalId, newStatus, cardElement);
        });
    });
}

/**
 * Update a goal's status
 * @param {string} goalId - The ID of the goal to update
 * @param {string} newStatus - The new status ('pending', 'in_progress', or 'completed')
 * @param {HTMLElement} cardElement - The card element to update
 */
function updateGoalStatus(goalId, newStatus, cardElement) {
    fetch(`/goal/${goalId}/update_status`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            status: newStatus
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Update the card's status classes
            cardElement.classList.remove('pending', 'in-progress', 'completed');
            cardElement.classList.add(newStatus.replace('_', '-'));
            
            // Show success message
            showAlert('Goal status updated successfully', 'success');
        } else {
            showAlert(`Error: ${data.error || 'Failed to update goal status'}`, 'danger');
            // Reset the select to previous value
            const select = cardElement.querySelector('.goal-status-select');
            const previousStatus = cardElement.classList.contains('pending') ? 'pending' : 
                                 cardElement.classList.contains('in-progress') ? 'in_progress' : 'completed';
            select.value = previousStatus;
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showAlert('An error occurred while updating goal status', 'danger');
    });
}

/**
 * Show an alert message
 * @param {string} message - The message to display
 * @param {string} type - The alert type ('success', 'info', 'warning', 'danger')
 */
function showAlert(message, type) {
    const alertsContainer = document.getElementById('alerts');
    const alert = document.createElement('div');
    alert.className = `alert alert-${type} alert-dismissible fade show`;
    alert.role = 'alert';
    alert.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    `;
    
    alertsContainer.appendChild(alert);
    
    // Auto dismiss after 5 seconds
    setTimeout(() => {
        alert.classList.remove('show');
        setTimeout(() => {
            alertsContainer.removeChild(alert);
        }, 150);
    }, 5000);
}

/**
 * Show modal for adding a new goal
 */
function showAddGoalModal() {
    // Create the modal if it doesn't exist
    if (!document.getElementById('addGoalModal')) {
        createAddGoalModal();
    }
    
    // Show the modal
    const modal = new bootstrap.Modal(document.getElementById('addGoalModal'));
    modal.show();
}

/**
 * Create the add goal modal
 */
function createAddGoalModal() {
    const patientId = document.getElementById('patientId').value;
    const analysisId = document.getElementById('analysisId')?.value || '';
    
    const modal = document.createElement('div');
    modal.className = 'modal fade';
    modal.id = 'addGoalModal';
    modal.tabIndex = -1;
    modal.setAttribute('aria-labelledby', 'addGoalModalLabel');
    modal.setAttribute('aria-hidden', 'true');
    
    modal.innerHTML = `
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addGoalModalLabel">Add New Goal</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="addGoalForm">
                        <div class="mb-3">
                            <label for="goalDescription" class="form-label">Goal Description</label>
                            <textarea class="form-control" id="goalDescription" rows="3" placeholder="I will be able to..." required></textarea>
                            <div class="form-text">Enter a specific, measurable goal from the client's perspective (e.g., "I will be able to brush my teeth independently")</div>
                        </div>
                        <div class="mb-3">
                            <label for="goalType" class="form-label">Goal Type</label>
                            <select class="form-select" id="goalType" required>
                                <option value="short">Short-term (2-4 weeks)</option>
                                <option value="medium">Medium-term (3-6 months)</option>
                                <option value="long">Long-term (6-12 months)</option>
                            </select>
                        </div>
                        <input type="hidden" id="goalPatientId" value="${patientId}">
                        <input type="hidden" id="goalAnalysisId" value="${analysisId}">
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="saveGoalBtn">Save Goal</button>
                </div>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Add event listener to save button
    document.getElementById('saveGoalBtn').addEventListener('click', saveGoal);
}

/**
 * Save a manually created goal
 */
function saveGoal() {
    const description = document.getElementById('goalDescription').value.trim();
    const goalType = document.getElementById('goalType').value;
    const patientId = document.getElementById('goalPatientId').value;
    const analysisId = document.getElementById('goalAnalysisId').value;
    
    if (!description) {
        showAlert('Please enter a goal description', 'warning');
        return;
    }
    
    // Create the goal object
    const goalData = {
        description: description,
        goal_type: goalType,
        patient_id: patientId,
        analysis_id: analysisId
    };
    
    // Send the goal data to the server
    fetch('/add_goal', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(goalData)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Hide the modal
            const modalElement = document.getElementById('addGoalModal');
            const modal = bootstrap.Modal.getInstance(modalElement);
            modal.hide();
            
            showAlert('Goal added successfully! Refreshing page...', 'success');
            
            // Refresh the page to show the new goal
            setTimeout(() => {
                window.location.reload();
            }, 1500);
        } else {
            showAlert(`Error: ${data.error || 'Failed to add goal'}`, 'danger');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showAlert('An error occurred while adding the goal', 'danger');
    });
}

// Initialize the page when DOM is fully loaded
document.addEventListener('DOMContentLoaded', initializeGoalsPage);