document.addEventListener('DOMContentLoaded', function() {
    // DOM elements
    const fileUploadForm = document.getElementById('fileUploadForm');
    const fileUploadContainer = document.getElementById('fileUploadContainer');
    const fileInput = document.getElementById('fileInput');
    const fileTypeSelect = document.getElementById('fileType');
    const filesList = document.getElementById('filesList');
    const patientId = document.getElementById('patientId').value;
    const analyzeButton = document.getElementById('analyzeButton');
    const radarChartContainer = document.getElementById('radarChart');
    const recommendationContainer = document.getElementById('recommendationContainer');
    const chatForm = document.getElementById('chatForm');
    const chatInput = document.getElementById('chatInput');
    const chatMessages = document.getElementById('chatMessages');
    const loadingSpinner = document.getElementById('loadingSpinner');
    const analysisSpinner = document.getElementById('analysisSpinner');
    const chatSpinner = document.getElementById('chatSpinner');

    // Initialize radar chart if container exists
    let radarChart = null;
    if (radarChartContainer) {
        initializeRadarChart();
    }

    // Event listeners for file upload via drag and drop
    if (fileUploadContainer) {
        fileUploadContainer.addEventListener('dragover', function(e) {
            e.preventDefault();
            fileUploadContainer.classList.add('drag-over');
        });

        fileUploadContainer.addEventListener('dragleave', function() {
            fileUploadContainer.classList.remove('drag-over');
        });

        fileUploadContainer.addEventListener('drop', function(e) {
            e.preventDefault();
            fileUploadContainer.classList.remove('drag-over');
            
            if (e.dataTransfer.files.length) {
                fileInput.files = e.dataTransfer.files;
                // Trigger change event
                const event = new Event('change');
                fileInput.dispatchEvent(event);
            }
        });

        fileUploadContainer.addEventListener('click', function() {
            fileInput.click();
        });
    }

    // File input change listener
    if (fileInput) {
        fileInput.addEventListener('change', function() {
            if (fileInput.files.length) {
                uploadFile();
            }
        });
    }

    // We don't need to listen for form submit events since we're handling file uploads directly 
    // through the change event of the file input

    // Analyze button click
    if (analyzeButton) {
        analyzeButton.addEventListener('click', function() {
            analyzeSelectedFiles();
        });
    }

    // Chat form submit
    if (chatForm) {
        chatForm.addEventListener('submit', function(e) {
            e.preventDefault();
            sendChatMessage();
        });
    }

    // Function to upload file
    function uploadFile() {
        if (!fileInput.files.length) {
            showAlert('Please select a file to upload', 'danger');
            return;
        }

        const file = fileInput.files[0];
        const fileType = fileTypeSelect.value;
        
        // Basic validation
        if (fileType === 'audio' && !file.name.match(/\.(mp3|wav|ogg|m4a)$/i)) {
            showAlert('Please select a valid audio file', 'danger');
            return;
        }
        
        if (fileType === 'text' && !file.name.match(/\.(txt|doc|docx|pdf)$/i)) {
            showAlert('Please select a valid text file', 'danger');
            return;
        }

        // Create FormData
        const formData = new FormData();
        formData.append('file', file);
        formData.append('fileType', fileType);

        // Show loading spinner
        loadingSpinner.classList.remove('d-none');

        // Send file to server
        fetch(`/upload_file/${patientId}`, {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            loadingSpinner.classList.add('d-none');
            
            if (data.success) {
                showAlert('File uploaded successfully', 'success');
                fileInput.value = ''; // Clear the file input
                
                // Add file to the list
                addFileToList(data.file);
                
                // If this was an audio file and a transcript was generated,
                // we should refresh the file list to show the transcript
                if (fileType === 'audio' && data.transcript) {
                    loadFiles();
                }
            } else {
                showAlert(data.message, 'danger');
            }
        })
        .catch(error => {
            loadingSpinner.classList.add('d-none');
            console.error('Error:', error);
            showAlert('An error occurred during file upload', 'danger');
        });
    }

    // Function to add a file to the list
    function addFileToList(file) {
        const fileItem = document.createElement('div');
        fileItem.className = 'file-item';
        fileItem.dataset.fileId = file.id;
        
        // Icon based on file type
        let icon = 'file-text';
        if (file.file_type === 'audio') {
            icon = 'headphones';
        } else if (file.file_type === 'video') {
            icon = 'video';
        }
        
        fileItem.innerHTML = `
            <div class="d-flex align-items-center">
                <input type="checkbox" class="form-check-input file-checkbox" id="file-${file.id}" data-file-id="${file.id}">
                <div class="file-name ms-2">
                    <i class="fas fa-${icon} me-2"></i>${file.filename}
                </div>
            </div>
            <div class="file-actions">
                <button class="btn btn-sm btn-outline-primary view-file" data-file-id="${file.id}">
                    <i class="fas fa-eye"></i>
                </button>
                <button class="btn btn-sm btn-outline-danger delete-file" data-file-id="${file.id}">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        `;
        
        filesList.appendChild(fileItem);
        
        // Add event listeners to the buttons
        const viewButton = fileItem.querySelector('.view-file');
        const deleteButton = fileItem.querySelector('.delete-file');
        
        viewButton.addEventListener('click', function() {
            viewFile(file.id);
        });
        
        deleteButton.addEventListener('click', function() {
            deleteFile(file.id);
        });
    }

    // Function to load all files
    function loadFiles() {
        // Clear the files list
        filesList.innerHTML = '';
        
        // Show loading spinner
        const filesSpinner = document.createElement('div');
        filesSpinner.className = 'spinner-container';
        filesSpinner.innerHTML = '<div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading...</span></div>';
        filesList.appendChild(filesSpinner);
        
        // Fetch files from server
        fetch(`/dashboard/${patientId}`)
        .then(response => response.text())
        .then(html => {
            // Parse the HTML to extract file data
            const parser = new DOMParser();
            const doc = parser.parseFromString(html, 'text/html');
            const fileItems = doc.querySelectorAll('.file-item');
            
            // Clear the files list
            filesList.innerHTML = '';
            
            // Add each file to the list
            fileItems.forEach(item => {
                filesList.appendChild(item.cloneNode(true));
            });
            
            // Add event listeners to the buttons
            document.querySelectorAll('.view-file').forEach(button => {
                button.addEventListener('click', function() {
                    viewFile(this.dataset.fileId);
                });
            });
            
            document.querySelectorAll('.delete-file').forEach(button => {
                button.addEventListener('click', function() {
                    deleteFile(this.dataset.fileId);
                });
            });
        })
        .catch(error => {
            console.error('Error:', error);
            filesList.innerHTML = '<div class="alert alert-danger">Error loading files</div>';
        });
    }

    // Function to view file content
    function viewFile(fileId) {
        // Create modal
        const modal = document.createElement('div');
        modal.className = 'modal fade';
        modal.id = 'fileViewModal';
        modal.setAttribute('tabindex', '-1');
        modal.setAttribute('aria-labelledby', 'fileViewModalLabel');
        modal.setAttribute('aria-hidden', 'true');
        
        modal.innerHTML = `
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="fileViewModalLabel">File Content</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="spinner-border text-primary" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                        <pre class="file-content mt-3" style="white-space: pre-wrap;"></pre>
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        
        // Initialize Bootstrap modal
        const modalInstance = new bootstrap.Modal(modal);
        modalInstance.show();
        
        // Fetch file content
        fetch(`/get_file_content/${fileId}`)
        .then(response => response.json())
        .then(data => {
            const spinner = modal.querySelector('.spinner-border');
            const contentEl = modal.querySelector('.file-content');
            
            spinner.remove();
            
            if (data.success) {
                contentEl.textContent = data.content;
            } else {
                contentEl.innerHTML = `<div class="alert alert-danger">${data.message}</div>`;
            }
        })
        .catch(error => {
            console.error('Error:', error);
            const spinner = modal.querySelector('.spinner-border');
            const contentEl = modal.querySelector('.file-content');
            
            spinner.remove();
            contentEl.innerHTML = '<div class="alert alert-danger">Error loading file content</div>';
        });
        
        // Clean up when modal is closed
        modal.addEventListener('hidden.bs.modal', function() {
            document.body.removeChild(modal);
        });
    }

    // Function to delete file
    function deleteFile(fileId) {
        if (confirm('Are you sure you want to delete this file?')) {
            fetch(`/delete_file/${fileId}`, {
                method: 'POST'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Remove file from the list
                    const fileItem = document.querySelector(`.file-item[data-file-id="${fileId}"]`);
                    if (fileItem) {
                        fileItem.remove();
                    }
                    showAlert('File deleted successfully', 'success');
                } else {
                    showAlert(data.message, 'danger');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showAlert('An error occurred while deleting the file', 'danger');
            });
        }
    }

    // Function to analyze selected files
    function analyzeSelectedFiles() {
        // Get selected file IDs
        const selectedFiles = [];
        document.querySelectorAll('.file-checkbox:checked').forEach(checkbox => {
            selectedFiles.push(parseInt(checkbox.dataset.fileId));
        });
        
        if (selectedFiles.length === 0) {
            showAlert('Please select at least one file to analyze', 'warning');
            return;
        }
        
        // Show analysis spinner
        analysisSpinner.classList.remove('d-none');
        
        // Send analysis request
        fetch('/analyze_files', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                patient_id: patientId,
                file_ids: selectedFiles
            })
        })
        .then(response => response.json())
        .then(data => {
            analysisSpinner.classList.add('d-none');
            
            if (data.success) {
                // Update radar chart with new scores
                updateRadarChart(data.analysis.scores);
                
                // Update recommendation
                recommendationContainer.innerHTML = `
                    <h5>Recommendations</h5>
                    ${data.analysis.recommendation}
                `;
                
                showAlert('Analysis completed successfully', 'success');
            } else {
                showAlert(data.message, 'danger');
            }
        })
        .catch(error => {
            analysisSpinner.classList.add('d-none');
            console.error('Error:', error);
            showAlert('An error occurred during analysis', 'danger');
        });
    }

    // Function to send chat message
    function sendChatMessage() {
        const message = chatInput.value.trim();
        
        if (!message) {
            return;
        }
        
        // Add user message to chat
        addChatMessage(message, 'user');
        
        // Clear input
        chatInput.value = '';
        
        // Get selected file IDs
        const selectedFiles = [];
        document.querySelectorAll('.file-checkbox:checked').forEach(checkbox => {
            selectedFiles.push(parseInt(checkbox.dataset.fileId));
        });
        
        // Show chat spinner
        chatSpinner.classList.remove('d-none');
        
        // Send request to server
        fetch('/get_chat_response', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                patient_id: patientId,
                file_ids: selectedFiles,
                query: message
            })
        })
        .then(response => response.json())
        .then(data => {
            chatSpinner.classList.add('d-none');
            
            if (data.success) {
                // Add assistant response to chat
                addChatMessage(data.response, 'assistant');
            } else {
                addChatMessage(`Error: ${data.message}`, 'assistant');
            }
            
            // Scroll to bottom of chat
            chatMessages.scrollTop = chatMessages.scrollHeight;
        })
        .catch(error => {
            chatSpinner.classList.add('d-none');
            console.error('Error:', error);
            addChatMessage('An error occurred while processing your request', 'assistant');
            
            // Scroll to bottom of chat
            chatMessages.scrollTop = chatMessages.scrollHeight;
        });
    }

    // Function to add message to chat
    function addChatMessage(message, sender) {
        const messageEl = document.createElement('div');
        messageEl.className = `chat-message ${sender}-message`;
        
        // For user messages, use text content to avoid HTML injection
        if (sender === 'user') {
            messageEl.textContent = message;
        } else {
            // For assistant messages, allow HTML content
            messageEl.innerHTML = message;
            
            // Add styling to HTML elements inside assistant messages
            const paragraphs = messageEl.querySelectorAll('p');
            paragraphs.forEach(p => {
                p.style.margin = '0.5rem 0';
            });
            
            const lists = messageEl.querySelectorAll('ul, ol');
            lists.forEach(list => {
                list.style.paddingLeft = '1.5rem';
                list.style.margin = '0.5rem 0';
            });
            
            const listItems = messageEl.querySelectorAll('li');
            listItems.forEach(item => {
                item.style.margin = '0.25rem 0';
            });
        }
        
        chatMessages.appendChild(messageEl);
        
        // Scroll to bottom of chat
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    // Function to initialize radar chart
    function initializeRadarChart() {
        // Get existing data if available
        let scores = {
            behavior: 0,
            sensory: 0,
            social: 0,
            communication: 0,
            cognitive: 0
        };
        
        // Check if initial data is available
        const initialDataEl = document.getElementById('initialChartData');
        if (initialDataEl) {
            try {
                const initialData = JSON.parse(initialDataEl.textContent);
                scores = initialData;
            } catch (e) {
                console.error('Error parsing initial chart data:', e);
            }
        }
        
        // Initialize Chart.js radar chart
        const ctx = radarChartContainer.getContext('2d');
        
        radarChart = new Chart(ctx, {
            type: 'radar',
            data: {
                labels: ['Behavior', 'Sensory', 'Social', 'Communication', 'Cognitive'],
                datasets: [{
                    label: 'Assessment Scores',
                    data: [
                        scores.behavior,
                        scores.sensory,
                        scores.social,
                        scores.communication,
                        scores.cognitive
                    ],
                    backgroundColor: 'rgba(52, 152, 219, 0.2)',
                    borderColor: 'rgba(52, 152, 219, 1)',
                    pointBackgroundColor: 'rgba(52, 152, 219, 1)',
                    pointBorderColor: '#fff',
                    pointHoverBackgroundColor: '#fff',
                    pointHoverBorderColor: 'rgba(52, 152, 219, 1)'
                }]
            },
            options: {
                scales: {
                    r: {
                        angleLines: {
                            display: true
                        },
                        suggestedMin: 0,
                        suggestedMax: 5
                    }
                }
            }
        });
        
        // Update score display
        updateScoreDisplay(scores);
    }

    // Function to update radar chart
    function updateRadarChart(scores) {
        if (!radarChart) {
            return;
        }
        
        radarChart.data.datasets[0].data = [
            scores.behavior,
            scores.sensory,
            scores.social,
            scores.communication,
            scores.cognitive
        ];
        
        radarChart.update();
        
        // Update score display
        updateScoreDisplay(scores);
    }

    // Function to update score display
    function updateScoreDisplay(scores) {
        const scoreDetails = document.getElementById('scoreDetails');
        if (!scoreDetails) {
            return;
        }
        
        // Make sure there's a heading above the score details
        const parentElement = scoreDetails.parentElement;
        if (!parentElement.querySelector('h6')) {
            const heading = document.createElement('h6');
            heading.className = 'text-center mb-3';
            heading.innerHTML = 'Assessment Scores <small class="text-muted">(Scale: 0-5)</small>';
            parentElement.insertBefore(heading, scoreDetails);
        }
        
        scoreDetails.innerHTML = `
            <div class="score-item">
                <div class="score-label">Behavior</div>
                <div class="score-value">${scores.behavior}<small>/5</small></div>
            </div>
            <div class="score-item">
                <div class="score-label">Sensory</div>
                <div class="score-value">${scores.sensory}<small>/5</small></div>
            </div>
            <div class="score-item">
                <div class="score-label">Social</div>
                <div class="score-value">${scores.social}<small>/5</small></div>
            </div>
            <div class="score-item">
                <div class="score-label">Communication</div>
                <div class="score-value">${scores.communication}<small>/5</small></div>
            </div>
            <div class="score-item">
                <div class="score-label">Cognitive</div>
                <div class="score-value">${scores.cognitive}<small>/5</small></div>
            </div>
        `;
    }

    // Function to show alerts
    function showAlert(message, type) {
        const alertContainer = document.getElementById('alertContainer');
        if (!alertContainer) {
            console.error('Alert container not found');
            return;
        }
        
        const alert = document.createElement('div');
        alert.className = `alert alert-${type} alert-dismissible fade show`;
        alert.role = 'alert';
        
        alert.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        `;
        
        alertContainer.appendChild(alert);
        
        // Auto dismiss after 5 seconds
        setTimeout(() => {
            if (alert.parentNode) {
                const bsAlert = bootstrap.Alert.getOrCreateInstance(alert);
                bsAlert.close();
            }
        }, 5000);
    }
});
