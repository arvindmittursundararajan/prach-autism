document.addEventListener('DOMContentLoaded', function() {
    // DOM elements
    const fileUploadContainer = document.getElementById('fileUploadContainer');
    const fileInput = document.getElementById('fileInput');
    const fileTypeSelect = document.getElementById('fileType');
    const filesList = document.getElementById('filesList');
    const deleteButtons = document.querySelectorAll('.delete-file');
    const viewButtons = document.querySelectorAll('.view-file');
    const patientDeleteForms = document.querySelectorAll('.delete-patient-form');

    // File drag and drop handling
    if (fileUploadContainer) {
        fileUploadContainer.addEventListener('dragover', function(e) {
            e.preventDefault();
            fileUploadContainer.classList.add('drag-over');
        });

        fileUploadContainer.addEventListener('dragleave', function() {
            fileUploadContainer.classList.remove('drag-over');
        });

        fileUploadContainer.addEventListener('drop', function(e) {
            e.preventDefault();
            fileUploadContainer.classList.remove('drag-over');
            
            if (e.dataTransfer.files.length) {
                fileInput.files = e.dataTransfer.files;
            }
        });

        fileUploadContainer.addEventListener('click', function() {
            fileInput.click();
        });
    }

    // Handle file delete buttons
    deleteButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            
            if (confirm('Are you sure you want to delete this file?')) {
                const fileId = this.dataset.fileId;
                
                fetch(`/delete_file/${fileId}`, {
                    method: 'POST'
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Remove file from the list
                        const fileItem = this.closest('.file-item');
                        if (fileItem) {
                            fileItem.remove();
                        }
                        
                        showAlert('File deleted successfully', 'success');
                    } else {
                        showAlert(data.message, 'danger');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    showAlert('An error occurred while deleting the file', 'danger');
                });
            }
        });
    });

    // Handle file view buttons
    viewButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const fileId = this.dataset.fileId;
            
            // Create and show modal
            const modal = document.createElement('div');
            modal.className = 'modal fade';
            modal.id = 'fileViewModal';
            modal.setAttribute('tabindex', '-1');
            modal.setAttribute('aria-labelledby', 'fileViewModalLabel');
            modal.setAttribute('aria-hidden', 'true');
            
            modal.innerHTML = `
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="fileViewModalLabel">File Content</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="spinner-border text-primary" role="status">
                                <span class="visually-hidden">Loading...</span>
                            </div>
                            <pre class="file-content mt-3" style="white-space: pre-wrap;"></pre>
                        </div>
                    </div>
                </div>
            `;
            
            document.body.appendChild(modal);
            
            // Initialize Bootstrap modal
            const modalInstance = new bootstrap.Modal(modal);
            modalInstance.show();
            
            // Fetch file content
            fetch(`/get_file_content/${fileId}`)
            .then(response => response.json())
            .then(data => {
                const spinner = modal.querySelector('.spinner-border');
                const contentEl = modal.querySelector('.file-content');
                
                spinner.remove();
                
                if (data.success) {
                    contentEl.textContent = data.content;
                } else {
                    contentEl.innerHTML = `<div class="alert alert-danger">${data.message}</div>`;
                }
            })
            .catch(error => {
                console.error('Error:', error);
                const spinner = modal.querySelector('.spinner-border');
                const contentEl = modal.querySelector('.file-content');
                
                spinner.remove();
                contentEl.innerHTML = '<div class="alert alert-danger">Error loading file content</div>';
            });
            
            // Clean up when modal is closed
            modal.addEventListener('hidden.bs.modal', function() {
                document.body.removeChild(modal);
            });
        });
    });

    // Handle patient delete forms
    patientDeleteForms.forEach(form => {
        form.addEventListener('submit', function(e) {
            if (!confirm('Are you sure you want to delete this patient? This will delete all associated files and cannot be undone.')) {
                e.preventDefault();
            }
        });
    });

    // Function to show alerts
    function showAlert(message, type) {
        const alertContainer = document.getElementById('alertContainer');
        if (!alertContainer) {
            console.error('Alert container not found');
            return;
        }
        
        const alert = document.createElement('div');
        alert.className = `alert alert-${type} alert-dismissible fade show`;
        alert.role = 'alert';
        
        alert.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        `;
        
        alertContainer.appendChild(alert);
        
        // Auto dismiss after 5 seconds
        setTimeout(() => {
            if (alert.parentNode) {
                const bsAlert = bootstrap.Alert.getOrCreateInstance(alert);
                bsAlert.close();
            }
        }, 5000);
    }
});
