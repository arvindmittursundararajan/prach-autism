import os
import json
import logging
from openai import OpenAI, AzureOpenAI
from config import (
    AZURE_OPENAI_ENDPOINT,
    AZURE_OPENAI_API_KEY, 
    AZURE_OPENAI_API_VERSION,
    AZURE_OPENAI_DEPLOYMENT,
    OPENAI_API_KEY
)
from prompts import ANALYSIS_PROMPT, GOALS_PROMPT, CHAT_PROMPT

# Initialize the client - set up Azure OpenAI Service client with key-based authentication
def get_openai_client():
    """
    Get configured OpenAI client, preferring Azure OpenAI if credentials are available
    """
    # Try to use Azure OpenAI first
    if AZURE_OPENAI_ENDPOINT and AZURE_OPENAI_API_KEY:
        try:
            client = AzureOpenAI(
                azure_endpoint=AZURE_OPENAI_ENDPOINT,
                api_key=AZURE_OPENAI_API_KEY,
                api_version=AZURE_OPENAI_API_VERSION,
            )
            logging.info(f"Using Azure OpenAI client with endpoint: {AZURE_OPENAI_ENDPOINT}")
            return client
        except Exception as e:
            logging.error(f"Failed to initialize Azure OpenAI client: {str(e)}")
            
    # Fall back to regular OpenAI if environment variable exists
    if OPENAI_API_KEY:
        try:
            client = OpenAI(api_key=OPENAI_API_KEY)
            logging.info("Using regular OpenAI client")
            return client
        except Exception as e:
            logging.error(f"Failed to initialize regular OpenAI client: {str(e)}")
    
    logging.error("No valid OpenAI clients could be initialized")
    return None

# Get the configured client
logging.basicConfig(level=logging.DEBUG)
logging.info(f"Initializing OpenAI client with Azure endpoint: {AZURE_OPENAI_ENDPOINT}")
logging.info(f"Using API version: {AZURE_OPENAI_API_VERSION}")
logging.info(f"Using deployment name: {AZURE_OPENAI_DEPLOYMENT}")

openai_client = get_openai_client()

if openai_client:
    logging.info("Successfully initialized OpenAI client")
else:
    logging.error("Failed to initialize OpenAI client")

def get_model_name():
    """Get appropriate model name based on configuration"""
    # For Azure OpenAI, we need to use the deployment name
    # For regular OpenAI, we use the model name directly
    if AZURE_OPENAI_ENDPOINT:
        logging.info(f"Using Azure OpenAI deployment: {AZURE_OPENAI_DEPLOYMENT}")
        return AZURE_OPENAI_DEPLOYMENT
    else:
        return "gpt-4o"

def summarize_article(text):
    """
    Summarize text using OpenAI
    """
    if not openai_client:
        return "Error: OpenAI client not initialized"
    
    try:
        prompt = f"Please summarize the following text concisely while maintaining key points:\n\n{text}"
        
        # Use appropriate model name
        model = get_model_name()
        
        response = openai_client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": prompt}],
        )
        return response.choices[0].message.content
    except Exception as e:
        logging.error(f"Error in summarize_article: {str(e)}")
        return f"Error summarizing text: {str(e)}"

def analyze_sentiment(text):
    """
    Analyze sentiment of text using OpenAI
    """
    if not openai_client:
        return {"error": "OpenAI client not initialized"}
    
    try:
        # Use appropriate model name
        model = get_model_name()
        
        response = openai_client.chat.completions.create(
            model=model,
            messages=[
                {
                    "role": "system",
                    "content": "You are a sentiment analysis expert. "
                    + "Analyze the sentiment of the text and provide a rating "
                    + "from 1 to 5 stars and a confidence score between 0 and 1. "
                    + "Respond with JSON in this format: "
                    + "{'rating': number, 'confidence': number}",
                },
                {"role": "user", "content": text},
            ]
        )
        result = json.loads(response.choices[0].message.content)
        return {
            "rating": max(1, min(5, round(result["rating"]))),
            "confidence": max(0, min(1, result["confidence"])),
        }
    except Exception as e:
        logging.error(f"Error in analyze_sentiment: {str(e)}")
        return {"error": f"Failed to analyze sentiment: {str(e)}"}

def transcribe_audio_fallback(audio_file_path):
    """
    Transcribe audio using OpenAI's Whisper model
    This is a fallback for when Azure Speech API is not available
    
    Args:
        audio_file_path: Path to audio file
        
    Returns:
        Transcription text
    """
    if not openai_client:
        return "Error: OpenAI client not initialized"
    
    try:
        with open(audio_file_path, "rb") as audio_file:
            response = openai_client.audio.transcriptions.create(
                model="whisper-1", 
                file=audio_file
            )
        return response.text
    except Exception as e:
        logging.error(f"Error in OpenAI transcribe_audio: {str(e)}")
        return f"Error transcribing audio: {str(e)}"

def generate_analysis(file_contents, patient):
    """
    Generate analysis of patient files using OpenAI
    
    Args:
        file_contents: List of dictionaries with file content
        patient: Patient object
        
    Returns:
        Dictionary with analysis results
    """
    if not openai_client:
        raise ValueError("Error: OpenAI client not initialized")
    
    try:
        # Create a combined text of all file contents
        combined_text = ""
        for file in file_contents:
            combined_text += f"File content: {file['content']}\n\n"
        
        # Add client information
        client_info = f"Client name: {patient.name}, Age: {patient.age}, Notes: {patient.notes}"
        
        # Use appropriate model name
        model = get_model_name()
        
        # Use the analysis prompt template
        prompt = ANALYSIS_PROMPT.format(
            client_info=client_info,
            combined_text=combined_text
        )
        
        # First attempt with response_format parameter
        response = openai_client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": prompt}],
            response_format={"type": "json_object"}
        )
        
        # Get the raw response content
        raw_content = response.choices[0].message.content
        logging.debug(f"Raw analysis response: {raw_content}")
        
        # Parse the JSON response
        result = json.loads(raw_content)
        
        # Validate the result
        if 'scores' not in result or 'recommendation' not in result:
            raise ValueError("Malformed response from OpenAI API: missing required fields")
            
        logging.info("Successfully parsed analysis JSON response")
        
        # Ensure all scores are within range
        for key in ['behavior', 'sensory', 'social', 'communication', 'cognitive']:
            if key not in result['scores']:
                result['scores'][key] = 3.0
            else:
                result['scores'][key] = max(1.0, min(5.0, float(result['scores'][key])))
        
        return result
        
    except json.JSONDecodeError as e:
        logging.error(f"JSON decode error in analysis: {str(e)}")
        logging.debug(f"Raw content that failed to parse: {raw_content}")
        
        # Try more aggressive cleaning before failing
        try:
            # Find the first '{' and the last '}'
            start_idx = raw_content.find('{')
            end_idx = raw_content.rfind('}')
            
            if start_idx >= 0 and end_idx > start_idx:
                clean_content = raw_content[start_idx:end_idx+1]
                logging.debug(f"Attempting to parse extracted JSON: {clean_content}")
                
                result = json.loads(clean_content)
                
                # Validate the clean result
                if 'scores' not in result or 'recommendation' not in result:
                    raise ValueError("Malformed response from OpenAI API after cleanup")
                
                # Ensure all scores are within range
                for key in ['behavior', 'sensory', 'social', 'communication', 'cognitive']:
                    if key not in result['scores']:
                        result['scores'][key] = 3.0
                    else:
                        result['scores'][key] = max(1.0, min(5.0, float(result['scores'][key])))
                
                logging.info("Successfully parsed analysis JSON after extraction")
                return result
            else:
                raise ValueError("Could not find JSON object markers in the response")
        except Exception as extraction_error:
            logging.error(f"Failed to extract JSON after aggressive cleaning: {str(extraction_error)}")
            raise ValueError(f"Failed to parse analysis response: {str(e)}")
            
    except Exception as e:
        logging.error(f"Error in generate_analysis: {str(e)}")
        raise ValueError(f"Error generating analysis: {str(e)}")

def generate_goals(patient, analysis, file_contents):
    """
    Generate therapeutic goals based on patient analysis and files
    
    Args:
        patient: Patient object
        analysis: Analysis object
        file_contents: List of dictionaries with file content
        
    Returns:
        Dictionary with short, medium, and long-term goals
    """
    if not openai_client:
        raise ValueError("Error: OpenAI client not initialized")
    
    try:
        # Create a combined text of all file contents
        combined_text = ""
        for file in file_contents:
            combined_text += f"File content: {file['content']}\n\n"
        
        # Add client information
        client_info = f"Client name: {patient.name}, Age: {patient.age}, Notes: {patient.notes}"
        
        # Add analysis information
        analysis_info = f"""
        Assessment Scores:
        - Behavior: {analysis.behavior_score}/5
        - Sensory: {analysis.sensory_score}/5
        - Social: {analysis.social_score}/5
        - Communication: {analysis.communication_score}/5
        - Cognitive: {analysis.cognitive_score}/5
        
        Recommendations: {analysis.recommendation}
        """
        
        # Use appropriate model name
        model = get_model_name()
        
        # Use the goals prompt template
        prompt = GOALS_PROMPT.format(
            client_info=client_info,
            analysis_info=analysis_info,
            combined_text=combined_text
        )
        
        # First attempt with response_format parameter
        logging.info("Attempting to generate goals with JSON response format")
        response = openai_client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": prompt}],
            response_format={"type": "json_object"}
        )
        
        # Get the raw response content
        raw_content = response.choices[0].message.content
        logging.debug(f"Raw goals response: {raw_content}")
        
        # Parse the JSON response
        result = json.loads(raw_content)
        
        # Validate the result
        if not all(key in result for key in ['short_term', 'medium_term', 'long_term']):
            raise ValueError("Malformed response from OpenAI API: missing required fields")
            
        logging.info("Successfully parsed goals JSON response")
        return result
        
    except json.JSONDecodeError as e:
        logging.error(f"JSON decode error in generate_goals: {str(e)}")
        logging.debug(f"Raw content that failed to parse: {raw_content}")
        
        # Try more aggressive cleaning before failing
        try:
            # Find the first '{' and the last '}'
            start_idx = raw_content.find('{')
            end_idx = raw_content.rfind('}')
            
            if start_idx >= 0 and end_idx > start_idx:
                clean_content = raw_content[start_idx:end_idx+1]
                logging.debug(f"Attempting to parse extracted JSON: {clean_content}")
                
                result = json.loads(clean_content)
                
                # Validate the clean result
                if not all(key in result for key in ['short_term', 'medium_term', 'long_term']):
                    raise ValueError("Malformed response from OpenAI API after cleanup")
                
                logging.info("Successfully parsed goals JSON after extraction")
                return result
            else:
                raise ValueError("Could not find JSON object markers in the response")
                
        except Exception as extraction_error:
            logging.error(f"Failed to extract JSON after aggressive cleaning: {str(extraction_error)}")
            
            # Try one more time with an explicit instruction
            try:
                logging.info("Retrying with explicit JSON formatting instruction")
                prompt += "\n\nImportant: Your response must be valid JSON with exactly the structure shown above, with no markdown formatting."
                
                response = openai_client.chat.completions.create(
                    model=model,
                    messages=[{"role": "user", "content": prompt}],
                    response_format={"type": "json_object"}
                )
                
                raw_content = response.choices[0].message.content
                result = json.loads(raw_content)
                
                # Validate the result
                if not all(key in result for key in ['short_term', 'medium_term', 'long_term']):
                    raise ValueError("Malformed response from OpenAI API after retry")
                    
                logging.info("Successfully parsed goals JSON response on retry")
                return result
                
            except Exception as retry_error:
                logging.error(f"Error in retry attempt: {str(retry_error)}")
                raise ValueError(f"Failed to parse goals response after multiple attempts: {str(e)}")
            
    except Exception as e:
        logging.error(f"Error in generate_goals: {str(e)}")
        raise ValueError(f"Error generating goals: {str(e)}")

def get_chat_recommendation(query, patient_info, file_contents):
    """
    Generate chat response based on patient information and files
    
    Args:
        query: User's query
        patient_info: Dictionary with patient details
        file_contents: List of dictionaries with file content
        
    Returns:
        Response text
    """
    if not openai_client:
        raise ValueError("Error: OpenAI client not initialized. Please check your API configuration.")
    
    try:
        # Create a combined text of all file contents
        combined_text = ""
        for file in file_contents:
            combined_text += f"File name: {file['filename']}\nContent: {file['content']}\n\n"
        
        # Format client information
        client_details = f"Client name: {patient_info['name']}, Age: {patient_info['age']}, Notes: {patient_info['notes']}"
        
        # Use appropriate model name
        model = get_model_name()
        
        # Use the chat prompt template
        prompt = CHAT_PROMPT.format(
            client_details=client_details,
            combined_text=combined_text,
            query=query
        )
        
        # First attempt
        response = openai_client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": prompt}],
            max_tokens=800,
        )
        
        result = response.choices[0].message.content
        if not result or result.strip() == "":
            raise ValueError("Empty response received from OpenAI API")
            
        logging.info("Successfully received chat response")
        return result
        
    except Exception as e:
        logging.error(f"Error in get_chat_recommendation: {str(e)}")
        
        # Try one more time with a simpler prompt
        try:
            logging.info("Retrying with a simplified prompt")
            simplified_prompt = f"You are a BCBA therapist. The client is {patient_info['name']}, age {patient_info['age']}. Question: {query}"
            
            response = openai_client.chat.completions.create(
                model=model,
                messages=[{"role": "user", "content": simplified_prompt}],
                max_tokens=800,
            )
            
            result = response.choices[0].message.content
            if not result or result.strip() == "":
                raise ValueError("Empty response received from OpenAI API on retry")
                
            logging.info("Successfully received chat response on retry")
            return result
            
        except Exception as retry_error:
            logging.error(f"Error in chat recommendation retry: {str(retry_error)}")
            raise ValueError(f"Error generating chat response: {str(e)}")
