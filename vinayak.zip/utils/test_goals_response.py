import os
import json
import logging
import sys

# Set up logging to see what's happening
logging.basicConfig(level=logging.DEBUG)

# Add parent directory to sys.path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Import the necessary functions
from utils.azure_ai import get_openai_client, get_model_name
from prompts.goals_prompt import GOALS_PROMPT

# Get the OpenAI client
openai_client = get_openai_client()
if not openai_client:
    print("Error: OpenAI client not initialized")
    exit(1)

# Mock data for testing
client_info = "Client name: Test Client, Age: 6, Notes: Testing goal generation"
analysis_info = """
Assessment Scores:
- Behavior: 3.5/5
- Sensory: 4.0/5
- Social: 2.5/5
- Communication: 3.0/5
- Cognitive: 3.5/5

Recommendations: Focus on communication skills and social interactions.
"""
combined_text = "File content: The client shows interest in sensory activities and can focus for short periods."

# Format the prompt
prompt = GOALS_PROMPT.format(
    client_info=client_info,
    analysis_info=analysis_info,
    combined_text=combined_text
)

# Use appropriate model name
model = get_model_name()

# Call the OpenAI API directly
try:
    print("Sending request to OpenAI API...")
    response = openai_client.chat.completions.create(
        model=model,
        messages=[{"role": "user", "content": prompt}],
        response_format={"type": "json_object"}
    )
    
    # Get the raw content
    raw_content = response.choices[0].message.content
    print("\n\nRAW RESPONSE CONTENT:")
    print("-" * 50)
    print(repr(raw_content))  # Print with repr to see escape characters
    print("-" * 50)
    
    # Try to clean and parse the JSON
    print("\nATTEMPTING TO CLEAN AND PARSE JSON...")
    clean_content = raw_content.strip()
    
    # Print each character with its ASCII value to find problematic characters
    print("\nCHARACTER ANALYSIS:")
    for i, char in enumerate(clean_content[:30]):  # First 30 chars for brevity
        print(f"Position {i}: '{char}' (ASCII: {ord(char)})")
    
    # If there are JSON markers, extract only the JSON part
    if "```json" in clean_content:
        print("\nFound ```json marker, extracting content...")
        clean_content = clean_content.split("```json")[1]
    if "```" in clean_content:
        print("Found closing ``` marker, extracting content...")
        clean_content = clean_content.split("```")[0]
    
    # Final clean-up
    clean_content = clean_content.strip()
    print("\nCLEANED CONTENT:")
    print(repr(clean_content))
    
    # Try to parse the JSON
    try:
        result = json.loads(clean_content)
        print("\nSUCCESSFULLY PARSED JSON:")
        print(json.dumps(result, indent=2))
    except json.JSONDecodeError as e:
        print(f"\nJSON DECODE ERROR: {str(e)}")
        
        # Try more aggressive cleaning
        print("\nTRYING MORE AGGRESSIVE CLEANING...")
        # Find the first '{' and the last '}'
        start_idx = clean_content.find('{')
        end_idx = clean_content.rfind('}')
        
        if start_idx >= 0 and end_idx > start_idx:
            clean_content = clean_content[start_idx:end_idx+1]
            print("EXTRACTED JSON OBJECT:")
            print(repr(clean_content))
            
            try:
                result = json.loads(clean_content)
                print("\nSUCCESSFULLY PARSED JSON AFTER AGGRESSIVE CLEANING:")
                print(json.dumps(result, indent=2))
            except json.JSONDecodeError as e2:
                print(f"\nJSON DECODE ERROR AFTER AGGRESSIVE CLEANING: {str(e2)}")
        else:
            print("Could not find JSON object markers { and }")
    
except Exception as e:
    print(f"Error: {str(e)}")