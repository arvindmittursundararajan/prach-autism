import os
import json
import logging
import requests
import tempfile
from werkzeug.utils import secure_filename
from config import AZURE_SPEECH_KEY, AZURE_SPEECH_REGION, AZURE_SPEECH_ENDPOINT

# Set up Azure Speech service credentials from config
SPEECH_KEY = AZURE_SPEECH_KEY
SPEECH_REGION = AZURE_SPEECH_REGION
SPEECH_ENDPOINT = AZURE_SPEECH_ENDPOINT

def transcribe_audio(audio_file_path, locale="en-US"):
    """
    Transcribe audio file using Azure Speech API
    
    Args:
        audio_file_path: Path to the audio file
        locale: Language locale (default: en-US)
        
    Returns:
        Transcript text or error message
    """
    logging.info(f"Starting transcription for audio file: {audio_file_path}")
    
    # Check if Azure Speech credentials are configured
    if not SPEECH_KEY or not SPEECH_REGION:
        # Use OpenAI's Whisper as fallback
        from utils.azure_ai import transcribe_audio_fallback
        return transcribe_audio_fallback(audio_file_path)
    
    try:
        # Prepare API URL for the fast transcription API
        url = f"{SPEECH_ENDPOINT}/speechtotext/transcriptions:transcribe?api-version=2024-11-15"
        
        headers = {
            'Ocp-Apim-Subscription-Key': SPEECH_KEY
        }
        
        # Read audio data
        with open(audio_file_path, 'rb') as f:
            audio_data = f.read()
        
        # Define transcription parameters as JSON
        definition = {
            "locales": [locale],
            "diarization": {
                "maxSpeakers": 2,
                "enabled": True
            }
        }
        
        # Determine content type based on file extension
        if audio_file_path.lower().endswith('.mp3'):
            content_type = 'audio/mpeg'
        elif audio_file_path.lower().endswith('.wav'):
            content_type = 'audio/wav'
        else:
            content_type = 'audio/wav'  # Default to wav
        
        # Create multipart form data
        files = {
            'audio': (os.path.basename(audio_file_path), audio_data, content_type),
            'definition': (None, json.dumps(definition), 'application/json')
        }
        
        logging.info(f"Sending request to Azure Speech API with locale: {locale}")
        
        # Make API request
        response = requests.post(url, headers=headers, files=files)
        
        # Process response
        if response.status_code == 200:
            logging.info("Transcription completed successfully")
            result = response.json()
            
            # Log the full response for debugging
            logging.debug(f"Raw API response: {json.dumps(result, indent=2)}")
            
            # Extract the combined transcript from all phrases
            if 'combinedPhrases' in result and len(result['combinedPhrases']) > 0:
                return result['combinedPhrases'][0]['text']
            elif 'phrases' in result and len(result['phrases']) > 0:
                # If combinedPhrases not available, concatenate all phrases
                transcript = ""
                for phrase in result['phrases']:
                    transcript += phrase['text'] + " "
                return transcript.strip()
            elif 'DisplayText' in result:
                # Alternative response format
                return result['DisplayText']
            elif 'text' in result:
                # Simple response format
                return result['text']
            else:
                logging.warning(f"No transcript found in the response: {json.dumps(result)}")
                return "No transcript found in the response."
        else:
            logging.error(f"Error in transcribe_audio: {response.status_code} - {response.text}")
            # Fall back to OpenAI's Whisper
            from utils.azure_ai import transcribe_audio_fallback
            return transcribe_audio_fallback(audio_file_path)
            
    except Exception as e:
        logging.error(f"Exception in transcribe_audio: {str(e)}")
        # Fall back to OpenAI's Whisper
        from utils.azure_ai import transcribe_audio_fallback
        return transcribe_audio_fallback(audio_file_path)
