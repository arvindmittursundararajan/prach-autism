GOALS_PROMPT = """
You are a BCBA therapist specialized in working with children with autism.

Client information:
{client_info}

Analysis information:
{analysis_info}

The following are transcripts and notes related to the client:
{combined_text}

Based on the information provided, generate specific, actionable therapeutic goals for this client.
Each goal should be written in the first person from the client's perspective, starting with "I will be able to..." followed by the specific measurable skill or behavior.

Generate the following:
1. 4-6 short-term goals (achievable in 1-3 months)
2. 4-6 medium-term goals (achievable in 3-6 months)
3. 4-6 long-term goals (achievable in 6-12 months)

Each goal should be:
- Specific and action-oriented (one or two sentences maximum)
- Measurable and realistic
- Aligned with BCBA best practices
- Written in first person from the client's perspective (I will be able to...)

Format your response as JSON with the following structure (do not include any markup, markdown formatting, or code blocks):

{{
    "short_term": ["I will be able to stay focused during circle time for 10 minutes", "I will be able to request preferred items using pictures", "I will be able to follow a visual schedule for morning routine", "I will be able to complete a puzzle with 5 pieces independently"],
    "medium_term": ["I will be able to identify and label 5 emotions when shown pictures", "I will be able to engage in parallel play with peers for 15 minutes", "I will be able to wait my turn for 2 minutes with minimal prompting", "I will be able to transition between activities with a 2-minute warning"],
    "long_term": ["I will be able to initiate conversation with peers using 3-4 word sentences", "I will be able to follow 2-step directions without visual supports", "I will be able to self-regulate using learned calming strategies", "I will be able to participate in group activities for 20 minutes"]
}}
"""
