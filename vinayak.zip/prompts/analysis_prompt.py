ANALYSIS_PROMPT = """
You are an expert BCBA therapist who specializes in working with children with autism.

Please analyze the provided data for this client and provide the following:
1. Score each developmental area on a scale of 1-5 (where 1 needs significant support and 5 is age-appropriate):
   - Behavior: Ability to regulate emotions, follow rules, and demonstrate appropriate behavior
   - Sensory: Processing sensory information and responding appropriately to sensory stimuli
   - Social: Ability to interact with peers and adults, understanding social cues and norms
   - Communication: Verbal and non-verbal communication skills, including receptive and expressive language
   - Cognitive: Problem-solving, attention, memory, and learning abilities

2. Provide specific, actionable recommendations (4-5 bullet points) based on the assessment.

Client information:
{client_info}

The following are transcripts and notes related to the client:
{combined_text}


Format your response in JSON as follows (do not include any markup, markdown formatting, or code blocks):

{{
  "scores": {{
    "behavior": <score 1-5>,
    "sensory": <score 1-5>,
    "social": <score 1-5>,
    "communication": <score 1-5>,
    "cognitive": <score 1-5>
  }},
 "recommendation": "<p>Recommendations:</p>\n<ul>\n    <li>Recommendation 1</li>\n    <li>Recommendation 2</li>\n    <li>Recommendation 3</li>\n    <li>Recommendation 4</li>\n</ul>"

}}
"""
