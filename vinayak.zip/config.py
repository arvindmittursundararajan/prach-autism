import os

# Azure Speech API Configuration
AZURE_SPEECH_KEY = os.environ.get("AZURE_SPEECH_KEY", "2mSPwp45gyLppO9GnL0BxrQtqmu5dV4wNO6PqgKvdDyREqICfoKGJQQJ99BDAC4f1cMXJ3w3AAAAACOGL6uo")
AZURE_SPEECH_REGION = os.environ.get("AZURE_SPEECH_REGION", "westus")
AZURE_SPEECH_ENDPOINT = f"https://{AZURE_SPEECH_REGION}.api.cognitive.microsoft.com"

# Azure OpenAI Configuration
AZURE_OPENAI_ENDPOINT = os.environ.get("AZURE_OPENAI_ENDPOINT", "https://uc2hub8618198510.openai.azure.com/")
AZURE_OPENAI_API_KEY = os.environ.get("AZURE_OPENAI_API_KEY", "2mSPwp45gyLppO9GnL0BxrQtqmu5dV4wNO6PqgKvdDyREqICfoKGJQQJ99BDAC4f1cMXJ3w3AAAAACOGL6uo")
AZURE_OPENAI_API_VERSION = os.environ.get("AZURE_OPENAI_API_VERSION", "2024-02-15-preview")
AZURE_OPENAI_DEPLOYMENT = os.environ.get("AZURE_OPENAI_DEPLOYMENT", "Prompt-gpt-SpeechInput")

# OpenAI fallback (if Azure OpenAI not configured)
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY", "")
