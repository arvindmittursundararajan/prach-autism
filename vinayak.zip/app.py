import os
import logging
from datetime import datetime
from flask import Flask, render_template, redirect, request, flash, url_for, jsonify, send_from_directory
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, login_user, login_required, logout_user, current_user
from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.utils import secure_filename
import uuid
import json
from sqlalchemy.orm import DeclarativeBase

# Create the Flask app
class Base(DeclarativeBase):
    pass

db = SQLAlchemy(model_class=Base)
app = Flask(__name__)

# App configuration
app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key")
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///bcba_assist.db"
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}
app.config["UPLOAD_FOLDER"] = "uploads"

# Ensure upload folder exists
os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)

# Initialize database
db.init_app(app)

# Initialize login manager
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# Import models here to avoid circular imports
from models import User, Patient, PatientFile, Analysis, Goal

@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))

# Import forms
from forms import LoginForm, PatientForm

# Import utilities
from utils.azure_speech import transcribe_audio
from utils.azure_ai import summarize_article, analyze_sentiment, generate_analysis, generate_goals

# Create all tables in the database
with app.app_context():
    db.create_all()
    
    # Create demo user if it doesn't exist
    if not User.query.filter_by(username="demo").first():
        demo_user = User(
            username="demo",
            email="demo@bcba-assist.io",
            password_hash=generate_password_hash("demo")
        )
        db.session.add(demo_user)
        db.session.commit()
        logging.info("Demo user created")

# Routes
@app.route('/')
def index():
    if current_user.is_authenticated:
        return redirect(url_for('profile'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user and check_password_hash(user.password_hash, form.password.data):
            login_user(user)
            return redirect(url_for('profile'))
        else:
            flash('Invalid username or password', 'danger')
    return render_template('login.html', form=form)

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

@app.route('/profile', methods=['GET'])
@login_required
def profile():
    patients = Patient.query.filter_by(user_id=current_user.id).all()
    form = PatientForm()
    return render_template('profile.html', patients=patients, form=form)

@app.route('/add_patient', methods=['POST'])
@login_required
def add_patient():
    form = PatientForm()
    if form.validate_on_submit():
        patient = Patient(
            name=form.name.data,
            age=form.age.data,
            notes=form.notes.data,
            user_id=current_user.id,
            created_at=datetime.now()
        )
        db.session.add(patient)
        db.session.commit()
        
        # Create patient directory
        patient_dir = os.path.join(app.config['UPLOAD_FOLDER'], str(patient.id))
        os.makedirs(patient_dir, exist_ok=True)
        
        flash('Patient added successfully', 'success')
    else:
        for field, errors in form.errors.items():
            for error in errors:
                flash(f"{field}: {error}", "danger")
    
    return redirect(url_for('profile'))

@app.route('/delete_patient/<int:patient_id>', methods=['POST'])
@login_required
def delete_patient(patient_id):
    patient = Patient.query.get_or_404(patient_id)
    
    # Check if the patient belongs to the current user
    if patient.user_id != current_user.id:
        flash('Unauthorized access', 'danger')
        return redirect(url_for('profile'))
    
    # Delete all files associated with the patient
    files = PatientFile.query.filter_by(patient_id=patient_id).all()
    for file in files:
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], str(patient_id), file.filename)
        if os.path.exists(file_path):
            os.remove(file_path)
        db.session.delete(file)
    
    # Delete all analyses associated with the patient
    analyses = Analysis.query.filter_by(patient_id=patient_id).all()
    for analysis in analyses:
        db.session.delete(analysis)
    
    # Delete the patient
    db.session.delete(patient)
    db.session.commit()
    
    # Remove patient directory
    patient_dir = os.path.join(app.config['UPLOAD_FOLDER'], str(patient_id))
    if os.path.exists(patient_dir):
        import shutil
        shutil.rmtree(patient_dir)
    
    flash('Patient deleted successfully', 'success')
    return redirect(url_for('profile'))

@app.route('/dashboard/<int:patient_id>')
@login_required
def dashboard(patient_id):
    patient = Patient.query.get_or_404(patient_id)
    
    # Check if the patient belongs to the current user
    if patient.user_id != current_user.id:
        flash('Unauthorized access', 'danger')
        return redirect(url_for('profile'))
    
    # Get patient files
    files = PatientFile.query.filter_by(patient_id=patient_id).all()
    
    # Get the most recent analysis if available
    analysis = Analysis.query.filter_by(patient_id=patient_id).order_by(Analysis.created_at.desc()).first()
    
    return render_template('dashboard.html', patient=patient, files=files, analysis=analysis)

@app.route('/upload_file/<int:patient_id>', methods=['POST'])
@login_required
def upload_file(patient_id):
    patient = Patient.query.get_or_404(patient_id)
    
    # Check if the patient belongs to the current user
    if patient.user_id != current_user.id:
        return jsonify({'success': False, 'message': 'Unauthorized access'})
    
    if 'file' not in request.files:
        return jsonify({'success': False, 'message': 'No file part'})
    
    file = request.files['file']
    file_type = request.form.get('fileType', 'text')
    
    if file.filename == '':
        return jsonify({'success': False, 'message': 'No selected file'})
    
    if file:
        filename = secure_filename(file.filename)
        file_uuid = str(uuid.uuid4())
        # Add UUID to filename to ensure uniqueness
        filename_parts = filename.rsplit('.', 1)
        if len(filename_parts) > 1:
            unique_filename = f"{filename_parts[0]}_{file_uuid}.{filename_parts[1]}"
        else:
            unique_filename = f"{filename}_{file_uuid}"
        
        patient_dir = os.path.join(app.config['UPLOAD_FOLDER'], str(patient_id))
        os.makedirs(patient_dir, exist_ok=True)
        
        file_path = os.path.join(patient_dir, unique_filename)
        file.save(file_path)
        
        # Create transcript for audio files
        transcript_filename = None
        if file_type == 'audio':
            try:
                transcript_text = transcribe_audio(file_path)
                transcript_filename = f"transcript_{file_uuid}.txt"
                transcript_path = os.path.join(patient_dir, transcript_filename)
                
                with open(transcript_path, 'w') as f:
                    f.write(transcript_text)
                
                # Save the transcript file to database
                transcript_file = PatientFile(
                    filename=transcript_filename,
                    file_type='text',
                    original_filename=f"Transcript of {filename}",
                    patient_id=patient_id,
                    created_at=datetime.now()
                )
                db.session.add(transcript_file)
                
            except Exception as e:
                logging.error(f"Transcription error: {str(e)}")
                return jsonify({'success': False, 'message': f'Error generating transcript: {str(e)}'})
        
        # Save the file record to database
        db_file = PatientFile(
            filename=unique_filename,
            file_type=file_type,
            original_filename=filename,
            patient_id=patient_id,
            created_at=datetime.now()
        )
        db.session.add(db_file)
        db.session.commit()
        
        return jsonify({
            'success': True, 
            'message': 'File uploaded successfully',
            'file': {
                'id': db_file.id,
                'filename': db_file.original_filename,
                'file_type': db_file.file_type,
                'created_at': db_file.created_at.strftime('%Y-%m-%d %H:%M:%S')
            },
            'transcript': transcript_filename
        })
    
    return jsonify({'success': False, 'message': 'File upload failed'})

@app.route('/delete_file/<int:file_id>', methods=['POST'])
@login_required
def delete_file(file_id):
    file = PatientFile.query.get_or_404(file_id)
    patient = Patient.query.get_or_404(file.patient_id)
    
    # Check if the patient belongs to the current user
    if patient.user_id != current_user.id:
        return jsonify({'success': False, 'message': 'Unauthorized access'})
    
    # Delete the file from filesystem
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], str(file.patient_id), file.filename)
    if os.path.exists(file_path):
        os.remove(file_path)
    
    # Delete the file from database
    db.session.delete(file)
    db.session.commit()
    
    return jsonify({'success': True, 'message': 'File deleted successfully'})

@app.route('/get_file_content/<int:file_id>')
@login_required
def get_file_content(file_id):
    file = PatientFile.query.get_or_404(file_id)
    patient = Patient.query.get_or_404(file.patient_id)
    
    # Check if the patient belongs to the current user
    if patient.user_id != current_user.id:
        return jsonify({'success': False, 'message': 'Unauthorized access'})
    
    # Get the file path
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], str(file.patient_id), file.filename)
    
    if not os.path.exists(file_path):
        return jsonify({'success': False, 'message': 'File not found'})
    
    # Read the file content
    try:
        with open(file_path, 'r') as f:
            content = f.read()
        
        return jsonify({'success': True, 'content': content})
    except Exception as e:
        return jsonify({'success': False, 'message': f'Error reading file: {str(e)}'})

@app.route('/analyze_files', methods=['POST'])
@login_required
def analyze_files():
    data = request.json
    patient_id = data.get('patient_id')
    file_ids = data.get('file_ids', [])
    
    if not patient_id or not file_ids:
        return jsonify({'success': False, 'message': 'Missing data'})
    
    patient = Patient.query.get_or_404(patient_id)
    
    # Check if the patient belongs to the current user
    if patient.user_id != current_user.id:
        return jsonify({'success': False, 'message': 'Unauthorized access'})
    
    # Get the files
    files = PatientFile.query.filter(PatientFile.id.in_(file_ids)).all()
    if not files:
        return jsonify({'success': False, 'message': 'No files found'})
    
    # Collect file contents
    file_contents = []
    for file in files:
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], str(patient.id), file.filename)
        if os.path.exists(file_path):
            try:
                with open(file_path, 'r') as f:
                    content = f.read()
                    file_contents.append({
                        'id': file.id,
                        'content': content,
                        'type': file.file_type
                    })
            except Exception as e:
                logging.error(f"Error reading file {file.filename}: {str(e)}")
    
    if not file_contents:
        return jsonify({'success': False, 'message': 'Could not read any files'})
    
    try:
        # Analyze the files using Azure AI
        result = generate_analysis(file_contents, patient)
        
        # Save the analysis
        analysis = Analysis(
            patient_id=patient_id,
            behavior_score=result['scores']['behavior'],
            sensory_score=result['scores']['sensory'],
            social_score=result['scores']['social'],
            communication_score=result['scores']['communication'],
            cognitive_score=result['scores']['cognitive'],
            recommendation=result['recommendation'],
            created_at=datetime.now()
        )
        db.session.add(analysis)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Analysis completed',
            'analysis': {
                'id': analysis.id,
                'scores': {
                    'behavior': analysis.behavior_score,
                    'sensory': analysis.sensory_score,
                    'social': analysis.social_score,
                    'communication': analysis.communication_score,
                    'cognitive': analysis.cognitive_score
                },
                'recommendation': analysis.recommendation,
                'created_at': analysis.created_at.strftime('%Y-%m-%d %H:%M:%S')
            }
        })
    except Exception as e:
        logging.error(f"Analysis error: {str(e)}")
        return jsonify({'success': False, 'message': f'Error during analysis: {str(e)}'})

@app.route('/get_chat_response', methods=['POST'])
@login_required
def get_chat_response():
    data = request.json
    patient_id = data.get('patient_id')
    file_ids = data.get('file_ids', [])
    query = data.get('query', '')
    
    if not patient_id or not query:
        return jsonify({'success': False, 'message': 'Missing data'})
    
    patient = Patient.query.get_or_404(patient_id)
    
    # Check if the patient belongs to the current user
    if patient.user_id != current_user.id:
        return jsonify({'success': False, 'message': 'Unauthorized access'})
    
    # Get patient details
    patient_info = {
        'name': patient.name,
        'age': patient.age,
        'notes': patient.notes
    }
    
    # Get the selected files content
    file_contents = []
    if file_ids:
        files = PatientFile.query.filter(PatientFile.id.in_(file_ids)).all()
        for file in files:
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], str(patient.id), file.filename)
            if os.path.exists(file_path):
                try:
                    with open(file_path, 'r') as f:
                        content = f.read()
                        file_contents.append({
                            'id': file.id,
                            'filename': file.original_filename,
                            'content': content
                        })
                except Exception as e:
                    logging.error(f"Error reading file {file.filename}: {str(e)}")
    
    try:
        from utils.azure_ai import get_chat_recommendation
        response = get_chat_recommendation(query, patient_info, file_contents)
        
        return jsonify({
            'success': True,
            'response': response
        })
    except Exception as e:
        logging.error(f"Chat response error: {str(e)}")
        return jsonify({'success': False, 'message': f'Error generating response: {str(e)}'})

@app.route('/patient/<int:patient_id>/goals')
@login_required
def patient_goals(patient_id):
    patient = Patient.query.get_or_404(patient_id)
    
    # Check if the patient belongs to the current user
    if patient.user_id != current_user.id:
        flash('Unauthorized access', 'danger')
        return redirect(url_for('profile'))
    
    # Get the most recent analysis if available
    analysis = Analysis.query.filter_by(patient_id=patient_id).order_by(Analysis.created_at.desc()).first()
    
    # Get goals grouped by type
    short_term_goals = []
    medium_term_goals = []
    long_term_goals = []
    
    if analysis:
        short_term_goals = Goal.query.filter_by(analysis_id=analysis.id, goal_type='short_term').all()
        medium_term_goals = Goal.query.filter_by(analysis_id=analysis.id, goal_type='medium_term').all()
        long_term_goals = Goal.query.filter_by(analysis_id=analysis.id, goal_type='long_term').all()
    
    return render_template('goals.html', 
                          patient=patient, 
                          analysis=analysis, 
                          short_term_goals=short_term_goals,
                          medium_term_goals=medium_term_goals,
                          long_term_goals=long_term_goals)

@app.route('/patient/<int:patient_id>/generate_goals', methods=['POST'])
@login_required
def generate_patient_goals(patient_id):
    patient = Patient.query.get_or_404(patient_id)
    
    # Check if the patient belongs to the current user
    if patient.user_id != current_user.id:
        return jsonify({'success': False, 'error': 'Unauthorized access'})
    
    # Get the most recent analysis
    analysis = Analysis.query.filter_by(patient_id=patient_id).order_by(Analysis.created_at.desc()).first()
    
    if not analysis:
        return jsonify({'success': False, 'error': 'No analysis found for this patient. Please create an analysis first.'})
    
    # Get all patient files
    files = PatientFile.query.filter_by(patient_id=patient_id).all()
    
    # Collect file contents
    file_contents = []
    for file in files:
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], str(patient.id), file.filename)
        if os.path.exists(file_path):
            try:
                with open(file_path, 'r') as f:
                    content = f.read()
                    file_contents.append({
                        'id': file.id,
                        'content': content,
                        'type': file.file_type
                    })
            except Exception as e:
                logging.error(f"Error reading file {file.filename}: {str(e)}")
    
    try:
        # Check if file contents were found
        if not file_contents:
            return jsonify({'success': False, 'error': 'No readable text documents were found for this client. Please upload at least one text document.'})
        
        # Generate goals using Azure AI
        try:
            goals_result = generate_goals(patient, analysis, file_contents)
        except Exception as azure_error:
            logging.error(f"Azure AI error in goal generation: {str(azure_error)}")
            return jsonify({'success': False, 'error': f'Azure AI error: {str(azure_error)}. Please try again or check your Azure configuration.'})
        
        # Validate the goals result
        if not all(key in goals_result for key in ['short_term', 'medium_term', 'long_term']):
            logging.error(f"Invalid goals result format: {goals_result}")
            return jsonify({'success': False, 'error': 'The goals generated had an invalid format. Please try again.'})
            
        # Delete existing goals for this analysis
        existing_goals = Goal.query.filter_by(analysis_id=analysis.id).all()
        for goal in existing_goals:
            db.session.delete(goal)
        
        # Save new goals
        for goal_text in goals_result.get('short_term', []):
            if goal_text and isinstance(goal_text, str):
                goal = Goal(
                    patient_id=patient_id,
                    analysis_id=analysis.id,
                    description=goal_text,
                    goal_type='short_term',
                    status='pending',
                    created_at=datetime.now()
                )
                db.session.add(goal)
        
        for goal_text in goals_result.get('medium_term', []):
            if goal_text and isinstance(goal_text, str):
                goal = Goal(
                    patient_id=patient_id,
                    analysis_id=analysis.id,
                    description=goal_text,
                    goal_type='medium_term',
                    status='pending',
                    created_at=datetime.now()
                )
                db.session.add(goal)
        
        for goal_text in goals_result.get('long_term', []):
            if goal_text and isinstance(goal_text, str):
                goal = Goal(
                    patient_id=patient_id,
                    analysis_id=analysis.id,
                    description=goal_text,
                    goal_type='long_term',
                    status='pending',
                    created_at=datetime.now()
                )
                db.session.add(goal)
        
        db.session.commit()
        
        return jsonify({'success': True})
        
    except Exception as e:
        logging.error(f"Goals generation error: {str(e)}")
        db.session.rollback()  # Roll back any pending changes
        return jsonify({'success': False, 'error': f'Error generating goals: {str(e)}'})

@app.route('/goal/<int:goal_id>/update_status', methods=['POST'])
@login_required
def update_goal_status(goal_id):
    goal = Goal.query.get_or_404(goal_id)
    patient = Patient.query.get_or_404(goal.patient_id)
    
    # Check if the patient belongs to the current user
    if patient.user_id != current_user.id:
        return jsonify({'success': False, 'error': 'Unauthorized access'})
    
    data = request.json
    new_status = data.get('status')
    
    if new_status not in ['pending', 'in_progress', 'completed']:
        return jsonify({'success': False, 'error': 'Invalid status'})
    
    goal.status = new_status
    goal.updated_at = datetime.now()
    db.session.commit()
    
    return jsonify({'success': True})

@app.route('/add_goal', methods=['POST'])
@login_required
def add_goal():
    try:
        data = request.json
        description = data.get('description')
        goal_type = data.get('goal_type')
        patient_id = data.get('patient_id')
        analysis_id = data.get('analysis_id')
        
        # Validate input
        if not description or not goal_type or not patient_id:
            return jsonify({'success': False, 'error': 'Missing required fields'})
        
        # Validate goal type
        if goal_type not in ['short', 'medium', 'long']:
            return jsonify({'success': False, 'error': 'Invalid goal type'})
            
        # Get the patient and verify ownership
        patient = Patient.query.get_or_404(patient_id)
        if patient.user_id != current_user.id:
            return jsonify({'success': False, 'error': 'Unauthorized access'})
            
        # Get the analysis if specified
        analysis = None
        if analysis_id:
            analysis = Analysis.query.get_or_404(analysis_id)
            if analysis.patient_id != int(patient_id):
                return jsonify({'success': False, 'error': 'Analysis does not match patient'})
                
        # If no analysis is specified, get the latest one if available
        if not analysis:
            analysis = Analysis.query.filter_by(patient_id=patient_id).order_by(Analysis.created_at.desc()).first()
            
        if not analysis:
            return jsonify({'success': False, 'error': 'No analysis available. Please create an analysis for this patient first.'})
            
        # Map goal_type to database format
        goal_type_map = {
            'short': 'short_term',
            'medium': 'medium_term',
            'long': 'long_term'
        }
            
        # Create and save the goal
        goal = Goal(
            analysis_id=analysis.id,
            patient_id=patient.id,
            description=description,
            goal_type=goal_type_map[goal_type],
            status='pending',
            created_at=datetime.now(),
            updated_at=datetime.now()
        )
        
        db.session.add(goal)
        db.session.commit()
        
        return jsonify({'success': True})
        
    except Exception as e:
        logging.error(f"Error adding goal: {str(e)}")
        return jsonify({'success': False, 'error': f'Error adding goal: {str(e)}'})

@app.route('/uploads/<path:filename>')
@login_required
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
