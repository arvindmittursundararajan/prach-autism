from app import db
from flask_login import UserMixin
from datetime import datetime

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.now)
    
    # Relationships
    patients = db.relationship('Patient', backref='user', lazy='dynamic', cascade="all, delete-orphan")

class Patient(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    age = db.Column(db.Integer)
    notes = db.Column(db.Text)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.now)
    
    # Relationships
    files = db.relationship('PatientFile', backref='patient', lazy='dynamic', cascade="all, delete-orphan")
    analyses = db.relationship('Analysis', backref='patient', lazy='dynamic', cascade="all, delete-orphan")

class PatientFile(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    filename = db.Column(db.String(255), nullable=False)
    original_filename = db.Column(db.String(255), nullable=False)
    file_type = db.Column(db.String(50), nullable=False)  # audio, text, video
    patient_id = db.Column(db.Integer, db.ForeignKey('patient.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.now)

class Analysis(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.Integer, db.ForeignKey('patient.id'), nullable=False)
    behavior_score = db.Column(db.Float)
    sensory_score = db.Column(db.Float)
    social_score = db.Column(db.Float)
    communication_score = db.Column(db.Float)
    cognitive_score = db.Column(db.Float)
    recommendation = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.now)
    
    # Add relationship to goals
    goals = db.relationship('Goal', backref='analysis', lazy='dynamic', cascade="all, delete-orphan")

class Goal(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    analysis_id = db.Column(db.Integer, db.ForeignKey('analysis.id'), nullable=False)
    patient_id = db.Column(db.Integer, db.ForeignKey('patient.id'), nullable=False)
    description = db.Column(db.Text, nullable=False)
    goal_type = db.Column(db.String(20), nullable=False)  # 'short', 'medium', or 'long'
    status = db.Column(db.String(20), default='pending')  # 'pending', 'in_progress', 'completed'
    created_at = db.Column(db.DateTime, default=datetime.now)
    updated_at = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now)
