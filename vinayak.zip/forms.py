from flask_wtf import FlaskForm
from wtforms import StringField, IntegerField, TextAreaField, PasswordField, SubmitField
from wtforms.validators import DataRequired, Email, Length, Optional, NumberRange

class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(min=2, max=64)])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Login')

class PatientForm(FlaskForm):
    name = StringField('Patient Name', validators=[DataRequired(), Length(min=2, max=100)])
    age = IntegerField('Age', validators=[Optional(), NumberRange(min=1, max=100)])
    notes = TextAreaField('Notes', validators=[Optional()])
    submit = SubmitField('Add Patient')
