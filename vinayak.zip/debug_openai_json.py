import os
import json
import logging
from utils.azure_ai import get_openai_client, get_model_name
from prompts.goals_prompt import GOALS_PROMPT

# Set up logging
logging.basicConfig(level=logging.DEBUG)

# Get OpenAI client
openai_client = get_openai_client()
model = get_model_name()

# Mock data for testing
mock_client_info = "Client name: Test Client, Age: 6, Notes: Testing JSON response"
mock_analysis_info = """
Assessment Scores:
- Behavior: 3.5/5
- Sensory: 4.0/5
- Social: 2.5/5
- Communication: 3.0/5
- Cognitive: 3.8/5

Recommendations: Continue working on social skills and communication.
"""
mock_text = "Child has difficulty with focus during group activities but shows interest in art."

# Create test prompt
prompt = GOALS_PROMPT.format(
    client_info=mock_client_info,
    analysis_info=mock_analysis_info,
    combined_text=mock_text
)

print("Sending prompt to OpenAI...")
print("-" * 40)

# Get response
response = openai_client.chat.completions.create(
    model=model,
    messages=[{"role": "user", "content": prompt}]
)

print("Response received!")
print("-" * 40)

# Print raw response for inspection 
raw_content = response.choices[0].message.content
print("RAW RESPONSE CONTENT:")
print("-" * 40)
print(raw_content)
print("-" * 40)

# Try to clean the content
print("ATTEMPTING TO CLEAN CONTENT...")
clean_content = raw_content

# Remove markdown formatting if present
if "```json" in clean_content:
    print("- Found ```json marker, removing...")
    clean_content = clean_content.split("```json")[1]
    
if "```" in clean_content:
    print("- Found ``` marker, removing...")
    parts = clean_content.split("```")
    # Take the part between first and second ```
    if len(parts) >= 2:
        clean_content = parts[1] if parts[0].strip() == "" else parts[0]

# Special case: handle possible prefix and postfix text
possible_json_start = clean_content.find('{')
possible_json_end = clean_content.rfind('}')

if possible_json_start != -1 and possible_json_end != -1:
    print(f"- Found JSON object markers {{ and }} at positions {possible_json_start}, {possible_json_end}")
    clean_content = clean_content[possible_json_start:possible_json_end+1]

# Remove any leading/trailing whitespace
clean_content = clean_content.strip()

print("\nCLEANED CONTENT:")
print("-" * 40)
print(clean_content)
print("-" * 40)

# Try to parse JSON
try:
    result = json.loads(clean_content)
    print("\nSUCCESSFULLY PARSED JSON:")
    print("-" * 40)
    print(json.dumps(result, indent=2))
    print("\nJSON structure is valid with keys:", list(result.keys()))
except json.JSONDecodeError as e:
    print(f"\nJSON DECODE ERROR: {str(e)}")
    print(f"Error at position {e.pos}: Line {e.lineno}, Column {e.colno}")
    
    # Show the problematic area
    error_context = clean_content[max(0, e.pos-20):min(len(clean_content), e.pos+20)]
    print(f"Context around error: [...{error_context}...]")