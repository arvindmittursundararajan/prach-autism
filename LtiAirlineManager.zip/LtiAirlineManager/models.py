import datetime
from datetime import timedelta
import logging
import random
from app import db

logger = logging.getLogger(__name__)

# Airport model
class Airport(db.Model):
    __tablename__ = 'airports'
    
    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(3), unique=True, nullable=False)
    name = db.Column(db.String(100), nullable=False)
    city = db.Column(db.String(50), nullable=False)
    country = db.Column(db.String(50), nullable=False)
    lat = db.Column(db.Float)
    lng = db.Column(db.Float)
    
    # Relationships
    based_crew = db.relationship('Crew', backref='base_airport', lazy=True)
    current_aircraft = db.relationship('Aircraft', backref='current_airport', lazy=True)
    departure_flights = db.relationship('Flight', foreign_keys='Flight.departure_airport_id', backref='departure_airport', lazy=True)
    arrival_flights = db.relationship('Flight', foreign_keys='Flight.arrival_airport_id', backref='arrival_airport', lazy=True)
    
    def __repr__(self):
        return f"<Airport {self.code}>"

# Aircraft model
class Aircraft(db.Model):
    __tablename__ = 'aircraft'
    
    id = db.Column(db.Integer, primary_key=True)
    registration = db.Column(db.String(10), unique=True, nullable=False)
    aircraft_type = db.Column(db.String(20), nullable=False)
    seat_capacity = db.Column(db.Integer, nullable=False)
    manufacturing_date = db.Column(db.Date)
    status = db.Column(db.String(20), default='available')  # available, in_flight, maintenance, grounded
    total_flight_hours = db.Column(db.Float, default=0.0)
    maintenance_due_hours = db.Column(db.Float, default=500.0)
    fuel_capacity = db.Column(db.Integer, default=20000)
    current_fuel = db.Column(db.Integer, default=10000)
    current_airport_id = db.Column(db.Integer, db.ForeignKey('airports.id'), nullable=True)
    
    # Relationships
    flights = db.relationship('Flight', backref='aircraft', lazy=True)
    
    def __repr__(self):
        return f"<Aircraft {self.registration}>"

# Crew model
class Crew(db.Model):
    __tablename__ = 'crew'
    
    id = db.Column(db.Integer, primary_key=True)
    employee_id = db.Column(db.String(10), unique=True, nullable=False)
    first_name = db.Column(db.String(50), nullable=False)
    last_name = db.Column(db.String(50), nullable=False)
    position = db.Column(db.String(20), nullable=False)  # captain, first_officer, flight_attendant, purser
    qualification = db.Column(db.String(20), nullable=False)  # Aircraft types they are qualified for
    status = db.Column(db.String(20), default='available')  # available, on_duty, rest, sick, vacation, training
    base_airport_id = db.Column(db.Integer, db.ForeignKey('airports.id'), nullable=True)
    hours_flown = db.Column(db.Float, default=0.0)
    rest_until = db.Column(db.DateTime, nullable=True)
    
    # Relationships
    flight_assignments = db.relationship('FlightCrew', backref='crew_member', lazy=True)
    
    def __repr__(self):
        return f"<Crew {self.employee_id} - {self.first_name} {self.last_name}>"

# Flight model
class Flight(db.Model):
    __tablename__ = 'flights'
    
    id = db.Column(db.Integer, primary_key=True)
    flight_number = db.Column(db.String(10), nullable=False)
    departure_airport_id = db.Column(db.Integer, db.ForeignKey('airports.id'), nullable=False)
    arrival_airport_id = db.Column(db.Integer, db.ForeignKey('airports.id'), nullable=False)
    scheduled_departure = db.Column(db.DateTime, nullable=False)
    scheduled_arrival = db.Column(db.DateTime, nullable=False)
    actual_departure = db.Column(db.DateTime, nullable=True)
    actual_arrival = db.Column(db.DateTime, nullable=True)
    status = db.Column(db.String(20), default='scheduled')  # scheduled, boarding, departed, in_air, landed, completed, delayed, cancelled
    aircraft_id = db.Column(db.Integer, db.ForeignKey('aircraft.id'), nullable=True)
    passenger_count = db.Column(db.Integer, default=0)
    
    # Relationships
    crew = db.relationship('FlightCrew', backref='flight', lazy=True)
    
    def __repr__(self):
        return f"<Flight {self.flight_number}>"

# Flight-Crew association table
class FlightCrew(db.Model):
    __tablename__ = 'flight_crew'
    
    id = db.Column(db.Integer, primary_key=True)
    flight_id = db.Column(db.Integer, db.ForeignKey('flights.id'), nullable=False)
    crew_id = db.Column(db.Integer, db.ForeignKey('crew.id'), nullable=False)
    role = db.Column(db.String(20), nullable=False)  # captain, first_officer, flight_attendant, purser
    
    def __repr__(self):
        return f"<FlightCrew {self.id}>"

# Alert model
class Alert(db.Model):
    __tablename__ = 'alerts'
    
    id = db.Column(db.Integer, primary_key=True)
    alert_type = db.Column(db.String(50), nullable=False)
    severity = db.Column(db.String(20), nullable=False)  # critical, high, medium, low
    description = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    resolved_at = db.Column(db.DateTime, nullable=True)
    resolution_notes = db.Column(db.Text, nullable=True)
    flight_id = db.Column(db.Integer, db.ForeignKey('flights.id'), nullable=True)
    aircraft_id = db.Column(db.Integer, db.ForeignKey('aircraft.id'), nullable=True)
    crew_id = db.Column(db.Integer, db.ForeignKey('crew.id'), nullable=True)
    
    # Relationships
    flight = db.relationship('Flight', backref='alerts', lazy=True)
    aircraft = db.relationship('Aircraft', backref='alerts', lazy=True)
    crew = db.relationship('Crew', backref='alerts', lazy=True)
    
    def __repr__(self):
        return f"<Alert {self.id} - {self.alert_type}>"

# Simulation Result model
class SimulationResult(db.Model):
    __tablename__ = 'simulation_results'
    
    id = db.Column(db.Integer, primary_key=True)
    simulation_type = db.Column(db.String(50), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    parameters = db.Column(db.Text, nullable=True)  # JSON string of parameters
    result_summary = db.Column(db.Text, nullable=True)  # Summary of results
    result_details = db.Column(db.Text, nullable=True)  # JSON string of detailed results
    
    def __repr__(self):
        return f"<SimulationResult {self.id} - {self.simulation_type}>"

# Helper function to initialize the database with seed data
def init_db():
    # Check if database is already populated
    if Airport.query.count() > 0:
        logger.info("Database already populated, skipping initialization")
        return
    
    logger.info("Initializing database with seed data")
    
    # Add Indian airports
    airports = [
        Airport(code='DEL', name='Indira Gandhi International Airport', city='New Delhi', country='India', lat=28.5561, lng=77.1000),
        Airport(code='BOM', name='Chhatrapati Shivaji Maharaj International Airport', city='Mumbai', country='India', lat=19.0896, lng=72.8656),
        Airport(code='MAA', name='Chennai International Airport', city='Chennai', country='India', lat=12.9941, lng=80.1709),
        Airport(code='BLR', name='Kempegowda International Airport', city='Bengaluru', country='India', lat=13.1986, lng=77.7066),
        Airport(code='HYD', name='Rajiv Gandhi International Airport', city='Hyderabad', country='India', lat=17.2403, lng=78.4294),
        Airport(code='CCU', name='Netaji Subhash Chandra Bose International Airport', city='Kolkata', country='India', lat=22.6520, lng=88.4463),
        Airport(code='COK', name='Cochin International Airport', city='Kochi', country='India', lat=10.1520, lng=76.3922),
        Airport(code='PNQ', name='Pune Airport', city='Pune', country='India', lat=18.5793, lng=73.9089)
    ]
    
    db.session.add_all(airports)
    db.session.commit()
    
    # Add aircraft with Indian registrations (VT-)
    aircraft_types = ['B737', 'B787', 'A320', 'A321', 'A330', 'ATR72']
    seat_capacity = {'B737': 180, 'B787': 280, 'A320': 170, 'A321': 200, 'A330': 250, 'ATR72': 70}
    
    aircraft = []
    for i in range(1, 16):
        aircraft_type = random.choice(aircraft_types)
        registration = f"VT-LTI{i:02d}"
        aircraft.append(Aircraft(
            registration=registration,
            aircraft_type=aircraft_type,
            seat_capacity=seat_capacity[aircraft_type],
            manufacturing_date=datetime.date(2018, random.randint(1, 12), random.randint(1, 28)),
            status=random.choice(['available', 'available', 'in_flight', 'maintenance']),
            total_flight_hours=random.randint(1000, 4000),
            maintenance_due_hours=random.randint(4500, 5000),
            fuel_capacity=random.randint(15000, 30000),
            current_fuel=random.randint(5000, 15000),
            current_airport_id=random.choice(airports).id if random.random() > 0.2 else None
        ))
    
    db.session.add_all(aircraft)
    db.session.commit()
    
    # Add crew with Indian names
    indian_first_names = ['Aarav', 'Arjun', 'Rohan', 'Vihaan', 'Aditya', 'Kabir', 'Ananya', 'Ishita', 'Riya', 'Prisha', 
                         'Neha', 'Deepak', 'Sunita', 'Rajiv', 'Sanjay', 'Amit', 'Ramesh', 'Kavita', 'Pratik', 'Sameera']
    indian_last_names = ['Sharma', 'Patel', 'Verma', 'Singh', 'Kumar', 'Agarwal', 'Gupta', 'Reddy', 'Chowdhury', 'Nair',
                         'Joshi', 'Mehta', 'Rao', 'Desai', 'Shah', 'Yadav', 'Kapoor', 'Menon', 'Malhotra', 'Iyer']
    positions = ['captain', 'first_officer', 'flight_attendant', 'purser']
    qualification_map = {
        'captain': ['B737', 'B787', 'A320', 'A330', 'ATR72'],
        'first_officer': ['B737', 'A320', 'ATR72'],
        'flight_attendant': ['B737', 'B787', 'A320', 'A321', 'A330', 'ATR72'],
        'purser': ['B737', 'B787', 'A320', 'A321', 'A330', 'ATR72']
    }
    
    crew = []
    for i in range(1, 41):
        position = random.choice(positions)
        qualification = random.choice(qualification_map[position])
        first_name = random.choice(indian_first_names)
        last_name = random.choice(indian_last_names)
        crew.append(Crew(
            employee_id=f"LTI{i:04d}",
            first_name=first_name,
            last_name=last_name,
            position=position,
            qualification=qualification,
            status=random.choice(['available', 'available', 'on_duty', 'rest', 'sick', 'vacation']),
            base_airport_id=random.choice(airports).id,
            hours_flown=random.randint(100, 1000),
            rest_until=datetime.datetime.utcnow() + timedelta(hours=random.randint(0, 48)) if random.random() > 0.7 else None
        ))
    
    db.session.add_all(crew)
    db.session.commit()
    
    # Add flights
    now = datetime.datetime.utcnow()
    flights = []
    
    for i in range(1, 31):
        dep_airport_id = random.choice(airports).id
        arr_airport_id = random.choice([a.id for a in airports if a.id != dep_airport_id])
        departure_time = now + timedelta(hours=random.randint(-24, 72)) 
        flight_duration = timedelta(hours=random.randint(1, 5), minutes=random.randint(0, 59))
        arrival_time = departure_time + flight_duration
        
        status = 'scheduled'
        if departure_time < now:
            status = random.choice(['departed', 'in_air', 'landed', 'completed', 'delayed'])
        
        flight = Flight(
            flight_number=f"LTI-{random.randint(1, 9)}{random.randint(0, 9)}{random.randint(0, 9)}",
            departure_airport_id=dep_airport_id,
            arrival_airport_id=arr_airport_id,
            scheduled_departure=departure_time,
            scheduled_arrival=arrival_time,
            actual_departure=departure_time + timedelta(minutes=random.randint(-10, 30)) if status != 'scheduled' else None,
            actual_arrival=None if status in ['departed', 'in_air'] else (arrival_time + timedelta(minutes=random.randint(-10, 40)) if status in ['landed', 'completed'] else None),
            status=status,
            aircraft_id=random.choice(aircraft).id if random.random() > 0.1 else None,
            passenger_count=random.randint(30, 150) if status != 'scheduled' else 0
        )
        flights.append(flight)
    
    db.session.add_all(flights)
    db.session.commit()
    
    # Assign crew to flights
    for flight in flights:
        # Skip completed flights sometimes
        if flight.status == 'completed' and random.random() < 0.3:
            continue
            
        # Assign captain
        if flight.aircraft_id is not None:
            aircraft = Aircraft.query.get(flight.aircraft_id)
            if aircraft is not None:
                captains = [c for c in crew if c.position == 'captain' and c.qualification == aircraft.aircraft_type]
            else:
                captains = [c for c in crew if c.position == 'captain']
        else:
            captains = [c for c in crew if c.position == 'captain']
        if captains:
            flight_crew = FlightCrew(
                flight_id=flight.id,
                crew_id=random.choice(captains).id,
                role='captain'
            )
            db.session.add(flight_crew)
        
        # Assign first officer
        if flight.aircraft_id is not None:
            aircraft = Aircraft.query.get(flight.aircraft_id)
            if aircraft is not None:
                first_officers = [c for c in crew if c.position == 'first_officer' and c.qualification == aircraft.aircraft_type]
            else:
                first_officers = [c for c in crew if c.position == 'first_officer']
        else:
            first_officers = [c for c in crew if c.position == 'first_officer']
        if first_officers:
            flight_crew = FlightCrew(
                flight_id=flight.id,
                crew_id=random.choice(first_officers).id,
                role='first_officer'
            )
            db.session.add(flight_crew)
        
        # Assign purser
        pursers = [c for c in crew if c.position == 'purser']
        if pursers:
            flight_crew = FlightCrew(
                flight_id=flight.id,
                crew_id=random.choice(pursers).id,
                role='purser'
            )
            db.session.add(flight_crew)
        
        # Assign flight attendants (2-6 depending on aircraft)
        flight_attendants = [c for c in crew if c.position == 'flight_attendant']
        if flight_attendants:
            num_attendants = random.randint(2, min(6, len(flight_attendants)))
            selected_attendants = random.sample(flight_attendants, num_attendants)
            for attendant in selected_attendants:
                flight_crew = FlightCrew(
                    flight_id=flight.id,
                    crew_id=attendant.id,
                    role='flight_attendant'
                )
                db.session.add(flight_crew)
    
    db.session.commit()
    
    # Create some alerts
    alert_types = ['Weather Delay', 'Maintenance Issue', 'Crew Shortage', 'Air Traffic Control', 'Security Concern', 
                  'Technical Problem', 'Ground Handling Delay', 'Medical Emergency', 'Catering Delay', 'Documentation Issue']
    severities = ['critical', 'high', 'medium', 'low']
    
    alerts = []
    for i in range(1, 11):
        alert_type = random.choice(alert_types)
        severity = random.choice(severities)
        
        # Select a random entity to associate the alert with
        entity_type = random.choice(['flight', 'aircraft', 'crew', None])
        flight_id = random.choice(flights).id if entity_type == 'flight' else None
        
        # Get a list of all aircraft from the database for the random selection
        all_aircraft = Aircraft.query.all()
        aircraft_id = random.choice(all_aircraft).id if entity_type == 'aircraft' and all_aircraft else None
        
        # Get a list of all crew from the database for the random selection
        all_crew = Crew.query.all()
        crew_id = random.choice(all_crew).id if entity_type == 'crew' and all_crew else None
        
        # Generate description based on type
        descriptions = {
            'Weather Delay': 'Severe weather conditions affecting flight operations',
            'Maintenance Issue': 'Unscheduled maintenance required for aircraft',
            'Crew Shortage': 'Insufficient crew available for flight',
            'Air Traffic Control': 'ATC restrictions causing delays',
            'Security Concern': 'Additional security screening required',
            'Technical Problem': 'Technical issue reported on aircraft',
            'Ground Handling Delay': 'Delays in ground handling services',
            'Medical Emergency': 'Medical emergency reported',
            'Catering Delay': 'Catering supplies delayed',
            'Documentation Issue': 'Issue with flight documentation'
        }
        
        description = descriptions.get(alert_type, 'Operational alert')
        
        # Some alerts are resolved, some are active
        resolved = random.random() > 0.6
        resolved_at = datetime.datetime.utcnow() - timedelta(hours=random.randint(1, 12)) if resolved else None
        resolution_notes = 'Issue has been resolved successfully' if resolved else None
        
        alert = Alert(
            alert_type=alert_type,
            severity=severity,
            description=description,
            created_at=datetime.datetime.utcnow() - timedelta(hours=random.randint(1, 24)),
            resolved_at=resolved_at,
            resolution_notes=resolution_notes,
            flight_id=flight_id,
            aircraft_id=aircraft_id,
            crew_id=crew_id
        )
        alerts.append(alert)
    
    db.session.add_all(alerts)
    db.session.commit()
    
    # Create some simulation results
    simulation_types = [
        'Flight Delay Impact Analysis',
        'Flight Cancellation Cost Calculation',
        'Crew Unavailability Handling',
        'Aircraft Maintenance Emergency',
        'Weather Disruption Management',
        'Airport Capacity Constraints',
        'Air Traffic Control Restrictions',
        'Fuel Shortage Scenarios',
        'Passenger Connection Impacts',
        'Schedule Vulnerability Detection',
        'Ground Handling Delays',
        'Security Incident Simulation'
    ]
    
    import json
    
    simulation_results = []
    for sim_type in simulation_types:
        # Create a sample result with random parameters and outcomes
        parameters = {
            'severity': random.choice(['Low', 'Medium', 'High', 'Critical']),
            'duration': random.randint(1, 12),
            'affected_flights': random.randint(1, 10),
            'start_time': (datetime.datetime.utcnow() - timedelta(days=random.randint(1, 30))).isoformat(),
            'location': random.choice([a.code for a in airports])
        }
        
        results = {
            'affected_passengers': random.randint(100, 2000),
            'operational_cost': random.randint(5000, 50000),
            'delay_minutes': random.randint(30, 480),
            'cancellations': random.randint(0, 5),
            'recovery_time': random.randint(2, 48)
        }
        
        result = SimulationResult(
            simulation_type=sim_type,
            created_at=datetime.datetime.utcnow() - timedelta(days=random.randint(1, 30)),
            parameters=json.dumps(parameters),
            result_summary=f"Impact: {results['affected_passengers']} passengers, {results['delay_minutes']} minutes delay, {results['cancellations']} cancellations",
            result_details=json.dumps(results)
        )
        simulation_results.append(result)
    
    db.session.add_all(simulation_results)
    db.session.commit()
    
    logger.info("Database initialized successfully with seed data")
