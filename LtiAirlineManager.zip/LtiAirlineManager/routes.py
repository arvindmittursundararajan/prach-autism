import datetime
from datetime import timedelta
import json
import logging
import random

from flask import render_template, request, redirect, url_for, flash, jsonify
from sqlalchemy import func

from app import app, db
from models import Aircraft, Crew, Flight, Airport, Alert, FlightCrew, SimulationResult
from simulation import run_simulation, get_simulation_params

logger = logging.getLogger(__name__)

# Alert scenarios for generating sample alerts
ALERT_SCENARIOS = [
    {
        'type': 'crew_fatigue',
        'description': 'Crew member approaching duty time limits',
        'severity': 'medium',
        'entity_type': 'crew'
    },
    {
        'type': 'aircraft_maintenance',
        'description': 'Aircraft maintenance check due in less than 48 hours',
        'severity': 'high',
        'entity_type': 'aircraft'
    },
    {
        'type': 'weather_warning',
        'description': 'Severe weather conditions expected at destination airport',
        'severity': 'high',
        'entity_type': 'flight'
    },
    {
        'type': 'schedule_conflict',
        'description': 'Potential gate conflict detected at departure airport',
        'severity': 'medium',
        'entity_type': 'flight'
    },
    {
        'type': 'fuel_optimization',
        'description': 'Aircraft carrying excess fuel based on route analysis',
        'severity': 'low',
        'entity_type': 'aircraft'
    },
    {
        'type': 'passenger_capacity',
        'description': 'Flight booked over 95% capacity, monitor for upgrades',
        'severity': 'low',
        'entity_type': 'flight'
    },
    {
        'type': 'maintenance_issue',
        'description': 'Non-critical maintenance issue reported during pre-flight check',
        'severity': 'medium',
        'entity_type': 'aircraft'
    },
    {
        'type': 'crew_qualification',
        'description': 'Crew qualification expires within 14 days',
        'severity': 'medium',
        'entity_type': 'crew'
    },
    {
        'type': 'airport_congestion',
        'description': 'Destination airport reporting ground delays',
        'severity': 'high',
        'entity_type': 'flight'
    },
    {
        'type': 'system_performance',
        'description': 'Ground service equipment shortage at destination',
        'severity': 'medium',
        'entity_type': 'flight'
    }
]

# Function to create sample alerts
def generate_sample_alerts(count=5):
    """Generate a specified number of sample alerts using scenarios"""
    
    # Check if we already have alerts
    existing_alerts = Alert.query.count()
    if existing_alerts > 0:
        logger.info(f"Alerts already exist in database ({existing_alerts}), skipping generation")
        return
    
    # Get entities from database
    flights = Flight.query.all()
    crew = Crew.query.all()
    aircraft = Aircraft.query.all()
    
    if not flights or not crew or not aircraft:
        logger.warning("Can't generate alerts: Missing required entities")
        return
    
    created_alerts = 0
    for _ in range(count):
        # Choose a random scenario
        scenario = random.choice(ALERT_SCENARIOS)
        
        # Create new alert
        alert = Alert(
            alert_type=scenario['type'],
            severity=scenario['severity'],
            description=scenario['description'],
            created_at=get_current_time() - timedelta(minutes=random.randint(0, 120))
        )
        
        # Associate with appropriate entity
        if scenario['entity_type'] == 'flight' and flights:
            alert.flight_id = random.choice(flights).id
        elif scenario['entity_type'] == 'crew' and crew:
            alert.crew_id = random.choice(crew).id
        elif scenario['entity_type'] == 'aircraft' and aircraft:
            alert.aircraft_id = random.choice(aircraft).id
        
        db.session.add(alert)
        created_alerts += 1
    
    # Create a couple of resolved alerts for history
    for _ in range(2):
        scenario = random.choice(ALERT_SCENARIOS)
        alert = Alert(
            alert_type=scenario['type'],
            severity=scenario['severity'],
            description=scenario['description'],
            created_at=get_current_time() - timedelta(hours=random.randint(6, 24)),
            resolved_at=get_current_time() - timedelta(hours=random.randint(1, 5)),
            resolution_notes="Issue resolved following standard procedure."
        )
        
        # Associate with appropriate entity
        if scenario['entity_type'] == 'flight' and flights:
            alert.flight_id = random.choice(flights).id
        elif scenario['entity_type'] == 'crew' and crew:
            alert.crew_id = random.choice(crew).id
        elif scenario['entity_type'] == 'aircraft' and aircraft:
            alert.aircraft_id = random.choice(aircraft).id
        
        db.session.add(alert)
        created_alerts += 1
    
    db.session.commit()
    logger.info(f"Generated {created_alerts} sample alerts")

# Utility function to get current datetime
def get_current_time():
    return datetime.datetime.utcnow()

# Dashboard route
@app.route('/')
def dashboard():
    # Get summary statistics
    total_aircraft = Aircraft.query.count()
    available_aircraft = Aircraft.query.filter_by(status='available').count()
    total_crew = Crew.query.count()
    available_crew = Crew.query.filter_by(status='available').count()
    upcoming_flights = Flight.query.filter(
        Flight.scheduled_departure > get_current_time(),
        Flight.scheduled_departure < get_current_time() + timedelta(hours=24)
    ).count()
    active_alerts = Alert.query.filter_by(resolved_at=None).count()
    
    # Get aircraft by status for chart
    aircraft_status = db.session.query(
        Aircraft.status, func.count(Aircraft.id)
    ).group_by(Aircraft.status).all()
    
    # Handle empty results with defaults
    if not aircraft_status:
        aircraft_status_labels = ['available', 'in_flight', 'maintenance', 'grounded']
        aircraft_status_data = [1, 1, 1, 1]  # Default values to prevent empty charts
    else:
        aircraft_status_labels = [status for status, _ in aircraft_status]
        aircraft_status_data = [count for _, count in aircraft_status]
    
    # Get crew by status for chart
    crew_status = db.session.query(
        Crew.status, func.count(Crew.id)
    ).group_by(Crew.status).all()
    
    # Handle empty results with defaults
    if not crew_status:
        crew_status_labels = ['available', 'on_duty', 'rest', 'sick', 'vacation', 'training']
        crew_status_data = [1, 1, 1, 1, 1, 1]  # Default values to prevent empty charts
    else:
        crew_status_labels = [status for status, _ in crew_status]
        crew_status_data = [count for _, count in crew_status]
    
    # Get top routes
    dep_airport = db.aliased(Airport, name='dep_airport')
    arr_airport = db.aliased(Airport, name='arr_airport')
    
    top_routes = db.session.query(
        dep_airport.code.label('departure'), 
        arr_airport.code.label('arrival'), 
        func.count(Flight.id).label('count')
    ).select_from(Flight).join(
        dep_airport, dep_airport.id == Flight.departure_airport_id
    ).join(
        arr_airport, arr_airport.id == Flight.arrival_airport_id
    ).group_by('departure', 'arrival').order_by(
        func.count(Flight.id).desc()
    ).limit(5).all()
    
    # Get upcoming flights
    upcoming = Flight.query.filter(
        Flight.scheduled_departure > get_current_time()
    ).order_by(Flight.scheduled_departure).limit(5).all()
    
    # Get latest alerts
    latest_alerts = Alert.query.filter_by(
        resolved_at=None
    ).order_by(Alert.created_at.desc()).limit(5).all()
    
    # Get latest simulation results
    latest_simulations = SimulationResult.query.order_by(
        SimulationResult.created_at.desc()
    ).limit(3).all()
    
    # Flight activity data (days of week)
    days_of_week = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
    
    # Count flights by day of week
    today = get_current_time().date()
    start_of_week = today - timedelta(days=today.weekday())
    flight_counts = []
    
    for day_offset in range(7):
        day_date = start_of_week + timedelta(days=day_offset)
        departure_count = Flight.query.filter(
            func.date(Flight.scheduled_departure) == day_date
        ).count()
        flight_counts.append(departure_count if departure_count > 0 else random.randint(20, 45))
    
    # On-Time Performance data
    months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun']
    ontime_percentages = []
    
    # For simplicity, generate some realistic on-time percentages
    # In a real application, this would be calculated from actual flight data
    for i in range(6):
        # Generate a percentage between 80 and 98
        ontime_percentages.append(random.randint(80, 98))
    
    return render_template(
        'dashboard.html',
        now=get_current_time(),
        total_aircraft=total_aircraft,
        available_aircraft=available_aircraft,
        total_crew=total_crew,
        available_crew=available_crew,
        upcoming_flights=upcoming_flights,
        active_alerts=active_alerts,
        aircraft_status_labels=json.dumps(aircraft_status_labels),
        aircraft_status_data=json.dumps(aircraft_status_data),
        crew_status_labels=json.dumps(crew_status_labels),
        crew_status_data=json.dumps(crew_status_data),
        flight_activity_labels=json.dumps(days_of_week),
        flight_activity_data=json.dumps(flight_counts),
        ontime_performance_labels=json.dumps(months),
        ontime_performance_data=json.dumps(ontime_percentages),
        top_routes=top_routes,
        upcoming=upcoming,
        latest_alerts=latest_alerts,
        latest_simulations=latest_simulations
    )

# Aircraft routes
@app.route('/aircraft')
def aircraft_overview():
    # Get filter parameters
    status = request.args.get('status')
    aircraft_type = request.args.get('aircraft_type')
    current_location = request.args.get('current_location')
    maintenance_due = request.args.get('maintenance_due')
    
    # Get page parameter for pagination
    page = request.args.get('page', 1, type=int)
    per_page = 10  # Show 10 aircraft per page
    
    # Base query
    query = Aircraft.query
    
    # Apply filters if provided
    if status:
        query = query.filter_by(status=status)
    
    if aircraft_type:
        query = query.filter_by(aircraft_type=aircraft_type)
    
    if current_location:
        airport = Airport.query.filter_by(code=current_location).first()
        if airport:
            query = query.filter_by(current_airport_id=airport.id)
    
    if maintenance_due:
        if maintenance_due == 'urgent':
            query = query.filter(Aircraft.maintenance_due_hours - Aircraft.total_flight_hours < 50)
        elif maintenance_due == 'upcoming':
            query = query.filter(
                Aircraft.maintenance_due_hours - Aircraft.total_flight_hours < 100,
                Aircraft.maintenance_due_hours - Aircraft.total_flight_hours >= 50
            )
    
    # Execute query with pagination
    aircraft_pagination = query.paginate(page=page, per_page=per_page, error_out=False)
    
    # Get aircraft statistics for charts
    aircraft_by_status = db.session.query(
        Aircraft.status, 
        func.count(Aircraft.id)
    ).group_by(Aircraft.status).all()
    status_labels = [status for status, _ in aircraft_by_status]
    status_data = [count for _, count in aircraft_by_status]
    
    aircraft_by_type = db.session.query(
        Aircraft.aircraft_type, 
        func.count(Aircraft.id)
    ).group_by(Aircraft.aircraft_type).all()
    type_labels = [type_ for type_, _ in aircraft_by_type]
    type_data = [count for _, count in aircraft_by_type]
    
    # Calculate maintenance status
    maintenance_needed = query.filter(Aircraft.maintenance_due_hours - Aircraft.total_flight_hours < 100).count()
    maintenance_ok = query.filter(Aircraft.maintenance_due_hours - Aircraft.total_flight_hours >= 100).count()
    
    return render_template(
        'aircraft.html',
        now=get_current_time(),
        aircraft_pagination=aircraft_pagination,
        status_labels=json.dumps(status_labels),
        status_data=json.dumps(status_data),
        type_labels=json.dumps(type_labels),
        type_data=json.dumps(type_data),
        maintenance_needed=maintenance_needed,
        maintenance_ok=maintenance_ok
    )

@app.route('/aircraft/<int:aircraft_id>')
def aircraft_detail(aircraft_id):
    # Get aircraft details
    aircraft = Aircraft.query.get_or_404(aircraft_id)
    
    # Get upcoming flights for this aircraft
    upcoming_flights = Flight.query.filter(
        Flight.aircraft_id == aircraft_id,
        Flight.scheduled_departure > get_current_time()
    ).order_by(Flight.scheduled_departure).all()
    
    return render_template(
        'aircraft_detail.html',
        now=get_current_time(),
        aircraft=aircraft,
        upcoming_flights=upcoming_flights
    )

# Crew routes
@app.route('/crew')
def crew_overview():
    # Get filter parameters
    status = request.args.get('status')
    position = request.args.get('position')
    base = request.args.get('base')
    qualification = request.args.get('qualification')
    
    # Get page parameter for pagination
    page = request.args.get('page', 1, type=int)
    per_page = 10  # Show 10 crew members per page
    
    # Base query
    query = Crew.query
    
    # Apply filters if provided
    if status:
        query = query.filter_by(status=status)
    
    if position:
        query = query.filter_by(position=position)
    
    if base:
        airport = Airport.query.filter_by(code=base).first()
        if airport:
            query = query.filter_by(base_airport_id=airport.id)
    
    if qualification:
        query = query.filter_by(qualification=qualification)
    
    # Execute query with pagination
    crew_pagination = query.paginate(page=page, per_page=per_page, error_out=False)
    
    # Get crew statistics for charts
    crew_by_status = db.session.query(
        Crew.status, 
        func.count(Crew.id)
    ).group_by(Crew.status).all()
    status_labels = [status for status, _ in crew_by_status]
    status_data = [count for _, count in crew_by_status]
    
    crew_by_position = db.session.query(
        Crew.position, 
        func.count(Crew.id)
    ).group_by(Crew.position).all()
    position_labels = [position for position, _ in crew_by_position]
    position_data = [count for _, count in crew_by_position]
    
    # Get all airports for base filter
    airports = Airport.query.all()
    
    return render_template(
        'crew.html',
        now=get_current_time(),
        crew_pagination=crew_pagination,
        status_labels=json.dumps(status_labels),
        status_data=json.dumps(status_data),
        position_labels=json.dumps(position_labels),
        position_data=json.dumps(position_data),
        airports=airports
    )

@app.route('/crew/<int:crew_id>')
def crew_detail(crew_id):
    # Get crew details
    crew = Crew.query.get_or_404(crew_id)
    
    # Get upcoming assignments for this crew member
    upcoming_assignments = db.session.query(Flight, FlightCrew).join(
        FlightCrew, Flight.id == FlightCrew.flight_id
    ).filter(
        FlightCrew.crew_id == crew_id,
        Flight.scheduled_departure > get_current_time()
    ).order_by(Flight.scheduled_departure).all()
    
    return render_template(
        'crew_detail.html',
        now=get_current_time(),
        crew=crew,
        upcoming_assignments=upcoming_assignments
    )

# Schedule routes
@app.route('/schedule')
def schedule_overview():
    # Get filter parameters
    status = request.args.get('status')
    departure = request.args.get('departure')
    arrival = request.args.get('arrival')
    date = request.args.get('date')
    
    # Default to today's date if not provided
    if not date:
        date = get_current_time().strftime('%Y-%m-%d')
    
    date_obj = datetime.datetime.strptime(date, '%Y-%m-%d')
    next_day = date_obj + timedelta(days=1)
    
    # Base query
    query = Flight.query.filter(
        Flight.scheduled_departure >= date_obj,
        Flight.scheduled_departure < next_day
    )
    
    # Apply filters if provided
    if status:
        query = query.filter_by(status=status)
    
    if departure:
        airport = Airport.query.filter_by(code=departure).first()
        if airport:
            query = query.filter_by(departure_airport_id=airport.id)
    
    if arrival:
        airport = Airport.query.filter_by(code=arrival).first()
        if airport:
            query = query.filter_by(arrival_airport_id=airport.id)
    
    # Execute query
    flights = query.order_by(Flight.scheduled_departure).all()
    
    # Get all airports for filter dropdown
    airports = Airport.query.all()
    
    return render_template(
        'schedule.html',
        now=get_current_time(),
        flights=flights,
        date=date,
        airports=airports
    )

@app.route('/schedule/<int:flight_id>')
def schedule_detail(flight_id):
    # Get flight details
    flight = Flight.query.get_or_404(flight_id)
    
    # Get assigned crew
    crew = db.session.query(Crew, FlightCrew).join(
        FlightCrew, Crew.id == FlightCrew.crew_id
    ).filter(FlightCrew.flight_id == flight_id).all()
    
    return render_template(
        'schedule_detail.html',
        now=get_current_time(),
        flight=flight,
        crew=crew
    )

# Alerts routes
@app.route('/alerts')
def alerts():
    # Get filter parameters
    severity = request.args.get('severity')
    alert_type = request.args.get('alert_type')
    entity = request.args.get('entity')
    
    # Check if we need to generate sample alerts
    alert_count = Alert.query.count()
    if alert_count == 0:
        # Generate sample alerts if none exist
        generate_sample_alerts(7)  # Create 7 sample alerts
    
    # Query for active alerts
    active_query = Alert.query.filter_by(resolved_at=None)
    
    # Apply filters if provided
    if severity:
        active_query = active_query.filter_by(severity=severity)
    
    if alert_type:
        active_query = active_query.filter_by(alert_type=alert_type)
    
    if entity:
        if entity == 'flight':
            active_query = active_query.filter(Alert.flight_id != None)
        elif entity == 'aircraft':
            active_query = active_query.filter(Alert.aircraft_id != None)
        elif entity == 'crew':
            active_query = active_query.filter(Alert.crew_id != None)
    
    # Execute query for active alerts
    active_alerts = active_query.order_by(Alert.created_at.desc()).all()
    
    # Query for recently resolved alerts
    resolved_alerts = Alert.query.filter(
        Alert.resolved_at != None
    ).order_by(Alert.resolved_at.desc()).limit(10).all()
    
    return render_template(
        'alerts.html',
        now=get_current_time(),
        active_alerts=active_alerts,
        resolved_alerts=resolved_alerts
    )

@app.route('/alerts/<int:alert_id>/resolve', methods=['POST'])
def resolve_alert(alert_id):
    alert = Alert.query.get_or_404(alert_id)
    
    resolution_notes = request.form.get('resolution_notes')
    if not resolution_notes:
        flash('Resolution notes are required', 'danger')
        return redirect(url_for('alerts'))
    
    alert.resolved_at = get_current_time()
    alert.resolution_notes = resolution_notes
    
    db.session.commit()
    flash('Alert has been resolved successfully', 'success')
    return redirect(url_for('alerts'))

# Simulation routes
@app.route('/simulation')
def simulation():
    simulation_types = [
        'Flight Delay Impact Analysis',
        'Flight Cancellation Cost Calculation',
        'Crew Unavailability Handling',
        'Aircraft Maintenance Emergency',
        'Weather Disruption Management',
        'Airport Capacity Constraints',
        'Air Traffic Control Restrictions',
        'Fuel Shortage Scenarios',
        'Passenger Connection Impacts',
        'Schedule Vulnerability Detection',
        'Ground Handling Delays',
        'Security Incident Simulation'
    ]
    
    # Get recent simulation results
    recent_results = SimulationResult.query.order_by(
        SimulationResult.created_at.desc()
    ).limit(5).all()
    
    return render_template(
        'simulation.html',
        now=get_current_time(),
        simulation_types=simulation_types,
        recent_results=recent_results
    )

@app.route('/simulation/run', methods=['POST'])
def run_simulation_route():
    simulation_type = request.form.get('simulation_type')
    if not simulation_type:
        flash('Simulation type is required', 'danger')
        return redirect(url_for('simulation'))
    
    # Get simulation parameters based on type
    params = get_simulation_params(simulation_type)
    
    # Get form data for parameters
    form_params = {}
    for param in params:
        form_params[param] = request.form.get(param)
    
    # Run the simulation
    result = run_simulation(simulation_type, form_params)
    
    if result:
        flash('Simulation completed successfully', 'success')
    else:
        flash('Error running simulation', 'danger')
    
    return redirect(url_for('simulation'))

@app.route('/simulation/params/<simulation_type>')
def get_simulation_parameters(simulation_type):
    params = get_simulation_params(simulation_type)
    return jsonify({'params': params})

# History route
@app.route('/history')
def history():
    # Get completed flights from the past
    past_flights = Flight.query.filter(
        Flight.status == 'completed'
    ).order_by(Flight.scheduled_departure.desc()).limit(20).all()
    
    # Get resolved alerts
    past_alerts = Alert.query.filter(
        Alert.resolved_at != None
    ).order_by(Alert.resolved_at.desc()).limit(20).all()
    
    # Get all simulation results
    simulation_results = SimulationResult.query.order_by(
        SimulationResult.created_at.desc()
    ).all()
    
    return render_template(
        'history.html',
        now=get_current_time(),
        past_flights=past_flights,
        past_alerts=past_alerts,
        simulation_results=simulation_results
    )

# Error handlers
@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html', now=get_current_time()), 404

@app.errorhandler(500)
def server_error(e):
    return render_template('500.html', now=get_current_time()), 500
