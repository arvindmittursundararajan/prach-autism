import datetime
import json
import logging
import random
from datetime import timedelta

from app import db
from models import Aircraft, Crew, Flight, Airport, Alert, SimulationResult

logger = logging.getLogger(__name__)

# Utility function to get simulation parameters for different simulation types
def get_simulation_params(simulation_type):
    # Define parameters for each simulation type
    params = {
        'Flight Delay Impact Analysis': [
            'delay_duration',
            'affected_airport',
            'start_time',
            'propagation_factor'
        ],
        'Flight Cancellation Cost Calculation': [
            'flight_numbers',
            'rebooking_capacity',
            'hotel_cost',
            'compensation_level'
        ],
        'Crew Unavailability Handling': [
            'unavailable_crew_percentage',
            'position_affected',
            'duration_days',
            'advance_notice'
        ],
        'Aircraft Maintenance Emergency': [
            'aircraft_type',
            'number_affected',
            'maintenance_duration',
            'parts_availability'
        ],
        'Weather Disruption Management': [
            'affected_airports',
            'weather_type',
            'duration_hours',
            'severity'
        ],
        'Airport Capacity Constraints': [
            'airport_code',
            'capacity_reduction_percentage',
            'duration_hours',
            'cause'
        ],
        'Air Traffic Control Restrictions': [
            'affected_airspace',
            'restriction_type',
            'reduction_percentage',
            'duration_hours'
        ],
        'Fuel Shortage Scenarios': [
            'affected_airports',
            'shortage_percentage',
            'duration_days',
            'priority_flights'
        ],
        'Passenger Connection Impacts': [
            'minimum_connection_time',
            'affected_hub',
            'passenger_volume',
            'rebooking_options'
        ],
        'Schedule Vulnerability Detection': [
            'time_period',
            'fleet_utilization',
            'crew_utilization',
            'buffer_minutes'
        ],
        'Ground Handling Delays': [
            'airport_code',
            'handling_area',
            'delay_minutes',
            'flights_per_hour'
        ],
        'Security Incident Simulation': [
            'airport_code',
            'incident_type',
            'resolution_time',
            'terminal_areas'
        ]
    }
    
    return params.get(simulation_type, [])

# Functions to perform different simulations
def simulate_flight_delay(params):
    """Simulate the impact of flight delays on the network."""
    try:
        delay_duration = int(params.get('delay_duration', 60))
    except (ValueError, TypeError):
        delay_duration = 60  # Default value if conversion fails
        
    affected_airport_code = params.get('affected_airport', 'DEL')
    
    start_time = params.get('start_time', datetime.datetime.utcnow().isoformat())
    
    try:
        propagation_factor = float(params.get('propagation_factor', 0.7))
    except (ValueError, TypeError):
        propagation_factor = 0.7  # Default value if conversion fails
    
    try:
        # Parse start_time if it's a string
        if isinstance(start_time, str):
            start_time = datetime.datetime.fromisoformat(start_time)
    except (ValueError, TypeError):
        start_time = datetime.datetime.utcnow()
    
    # Find affected airport
    affected_airport = Airport.query.filter_by(code=affected_airport_code).first()
    if not affected_airport:
        logger.error(f"Airport {affected_airport_code} not found")
        return None
    
    # Find flights departing from the affected airport after start_time
    affected_flights = Flight.query.filter(
        Flight.departure_airport_id == affected_airport.id,
        Flight.scheduled_departure >= start_time,
        Flight.scheduled_departure <= start_time + timedelta(hours=12)
    ).all()
    
    if not affected_flights:
        logger.warning(f"No flights found departing from {affected_airport_code} in the given time period")
        return {
            'affected_flights': 0,
            'total_delay_minutes': 0,
            'affected_passengers': 0,
            'downstream_impact': 0,
            'operational_cost': 0
        }
    
    # Calculate primary impacts
    total_delay_minutes = 0
    affected_passengers = 0
    downstream_flights = 0
    
    for flight in affected_flights:
        # Apply delay
        flight_delay = random.randint(max(10, delay_duration - 30), delay_duration + 30)
        total_delay_minutes += flight_delay
        affected_passengers += flight.passenger_count if flight.passenger_count else 0
        
        # Check for aircraft rotations (downstream impacts)
        next_flights = Flight.query.filter(
            Flight.aircraft_id == flight.aircraft_id,
            Flight.scheduled_departure > flight.scheduled_arrival,
            Flight.scheduled_departure < flight.scheduled_arrival + timedelta(hours=8)
        ).all()
        
        for next_flight in next_flights:
            if random.random() < propagation_factor:
                downstream_delay = int(flight_delay * random.uniform(0.6, 0.9))
                total_delay_minutes += downstream_delay
                affected_passengers += next_flight.passenger_count if next_flight.passenger_count else 0
                downstream_flights += 1
    
    # Calculate operational costs (approximate)
    cost_per_minute = 50  # cost per minute of delay
    operational_cost = total_delay_minutes * cost_per_minute
    
    # Prepare result
    result = {
        'affected_flights': len(affected_flights),
        'total_delay_minutes': total_delay_minutes,
        'affected_passengers': affected_passengers,
        'downstream_impact': downstream_flights,
        'operational_cost': operational_cost
    }
    
    # Create and store simulation result
    simulation_result = SimulationResult(
        simulation_type='Flight Delay Impact Analysis',
        parameters=json.dumps(params),
        result_summary=f"Impact: {len(affected_flights) + downstream_flights} flights, {affected_passengers} passengers, {total_delay_minutes} minutes delay",
        result_details=json.dumps(result)
    )
    
    db.session.add(simulation_result)
    db.session.commit()
    
    return result

def simulate_cancellation_cost(params):
    """Simulate the cost impact of flight cancellations."""
    flight_numbers = params.get('flight_numbers', '')
    
    try:
        rebooking_capacity = int(params.get('rebooking_capacity', 70))
    except (ValueError, TypeError):
        rebooking_capacity = 70  # Default value if conversion fails
        
    try:
        hotel_cost = int(params.get('hotel_cost', 80))
    except (ValueError, TypeError):
        hotel_cost = 80  # Default value if conversion fails
        
    compensation_level = params.get('compensation_level', 'medium')
    
    # Parse flight numbers
    flight_list = [f.strip() for f in flight_numbers.split(',') if f.strip()]
    
    if not flight_list:
        # If no specific flights, choose some random ones
        flights = Flight.query.filter(
            Flight.scheduled_departure > datetime.datetime.utcnow(),
            Flight.scheduled_departure < datetime.datetime.utcnow() + timedelta(days=1)
        ).limit(random.randint(2, 5)).all()
    else:
        flights = Flight.query.filter(Flight.flight_number.in_(flight_list)).all()
    
    if not flights:
        logger.warning("No flights found to simulate cancellation")
        return None
    
    # Calculate costs
    total_passengers = sum(f.passenger_count if f.passenger_count else random.randint(50, 150) for f in flights)
    
    # Rebooking costs
    rebookable_passengers = int(total_passengers * rebooking_capacity / 100)
    non_rebookable = total_passengers - rebookable_passengers
    
    # Compensation based on level
    compensation_rates = {
        'low': 100,
        'medium': 250,
        'high': 450
    }
    compensation_rate = compensation_rates.get(compensation_level, 250)
    
    # Calculate costs
    rebooking_cost = rebookable_passengers * 50  # Average rebooking admin cost
    hotel_accommodation = non_rebookable * hotel_cost  # Hotel costs for passengers who can't be rebooked
    passenger_compensation = total_passengers * compensation_rate  # Compensation payments
    operational_costs = len(flights) * 2000  # Misc operational costs
    
    total_cost = rebooking_cost + hotel_accommodation + passenger_compensation + operational_costs
    
    # Prepare result
    result = {
        'cancelled_flights': len(flights),
        'total_passengers': total_passengers,
        'rebookable_passengers': rebookable_passengers,
        'non_rebookable_passengers': non_rebookable,
        'rebooking_cost': rebooking_cost,
        'hotel_accommodation': hotel_accommodation,
        'passenger_compensation': passenger_compensation,
        'operational_costs': operational_costs,
        'total_cost': total_cost
    }
    
    # Create and store simulation result
    simulation_result = SimulationResult(
        simulation_type='Flight Cancellation Cost Calculation',
        parameters=json.dumps(params),
        result_summary=f"Cost Impact: ₹{total_cost:,} for {len(flights)} flights and {total_passengers} passengers",
        result_details=json.dumps(result)
    )
    
    db.session.add(simulation_result)
    db.session.commit()
    
    return result

def simulate_crew_unavailability(params):
    """Simulate the impact of crew unavailability."""
    try:
        unavailable_percentage = int(params.get('unavailable_crew_percentage', 20))
    except (ValueError, TypeError):
        unavailable_percentage = 20  # Default value if conversion fails
    
    position_affected = params.get('position_affected', 'all')
    
    try:
        duration_days = int(params.get('duration_days', 3))
    except (ValueError, TypeError):
        duration_days = 3  # Default value if conversion fails
    
    try:
        advance_notice = int(params.get('advance_notice', 1))
    except (ValueError, TypeError):
        advance_notice = 1  # Default value if conversion fails
    
    # Calculate start and end dates
    start_date = datetime.datetime.utcnow() + timedelta(days=advance_notice)
    end_date = start_date + timedelta(days=duration_days)
    
    # Get affected crew
    crew_query = Crew.query
    if position_affected != 'all':
        crew_query = crew_query.filter_by(position=position_affected)
    
    crews = crew_query.all()
    unavailable_count = int(len(crews) * unavailable_percentage / 100)
    unavailable_crew = random.sample(crews, min(unavailable_count, len(crews)))
    
    # Find affected flights
    affected_flights = []
    
    for crew_member in unavailable_crew:
        # Find flights assigned to this crew during affected period
        crew_flights = db.session.query(Flight).join(
            'crew'
        ).filter(
            Flight.crew.any(id=crew_member.id),
            Flight.scheduled_departure >= start_date,
            Flight.scheduled_departure <= end_date
        ).all()
        
        affected_flights.extend(crew_flights)
    
    # Remove duplicates
    affected_flights = list(set(affected_flights))
    
    # Calculate impact
    affected_passengers = sum(f.passenger_count if f.passenger_count else 0 for f in affected_flights)
    
    # Estimate how many flights can be covered by reassignment
    reassignable = int(len(affected_flights) * random.uniform(0.5, 0.8))
    cancellations = len(affected_flights) - reassignable
    
    # Calculate costs
    reassignment_cost = reassignable * 500  # Cost to reassign crew
    cancellation_cost = cancellations * 5000  # Cost of cancellations
    total_cost = reassignment_cost + cancellation_cost
    
    # Prepare result
    result = {
        'unavailable_crew': unavailable_count,
        'affected_flights': len(affected_flights),
        'affected_passengers': affected_passengers,
        'reassignable_flights': reassignable,
        'cancelled_flights': cancellations,
        'reassignment_cost': reassignment_cost,
        'cancellation_cost': cancellation_cost,
        'total_cost': total_cost
    }
    
    # Create and store simulation result
    simulation_result = SimulationResult(
        simulation_type='Crew Unavailability Handling',
        parameters=json.dumps(params),
        result_summary=f"Impact: {unavailable_count} crew unavailable affecting {len(affected_flights)} flights, {cancellations} cancellations",
        result_details=json.dumps(result)
    )
    
    db.session.add(simulation_result)
    db.session.commit()
    
    return result

def simulate_maintenance_emergency(params):
    """Simulate the impact of emergency aircraft maintenance."""
    aircraft_type = params.get('aircraft_type', 'all')
    number_affected = int(params.get('number_affected', 2))
    maintenance_duration = int(params.get('maintenance_duration', 48))
    parts_availability = params.get('parts_availability', 'normal')
    
    # Get affected aircraft
    aircraft_query = Aircraft.query.filter(Aircraft.status.in_(['available', 'in_flight']))
    if aircraft_type != 'all':
        aircraft_query = aircraft_query.filter_by(aircraft_type=aircraft_type)
    
    available_aircraft = aircraft_query.all()
    affected_aircraft = random.sample(available_aircraft, min(number_affected, len(available_aircraft)))
    
    if not affected_aircraft:
        logger.warning("No aircraft available for maintenance emergency simulation")
        return None
    
    # Calculate maintenance time
    if parts_availability == 'limited':
        maintenance_hours = maintenance_duration * 1.5
    elif parts_availability == 'critical':
        maintenance_hours = maintenance_duration * 2.5
    else:
        maintenance_hours = maintenance_duration
    
    # Find affected flights
    start_time = datetime.datetime.utcnow()
    end_time = start_time + timedelta(hours=maintenance_hours)
    
    affected_flights = []
    for aircraft in affected_aircraft:
        flights = Flight.query.filter(
            Flight.aircraft_id == aircraft.id,
            Flight.scheduled_departure >= start_time,
            Flight.scheduled_departure <= end_time
        ).all()
        affected_flights.extend(flights)
    
    # Calculate impact
    affected_passengers = sum(f.passenger_count if f.passenger_count else 0 for f in affected_flights)
    
    # Estimate costs
    maintenance_cost = number_affected * 15000  # Base maintenance cost
    if parts_availability == 'limited':
        maintenance_cost *= 1.3
    elif parts_availability == 'critical':
        maintenance_cost *= 2
    
    operational_impact = len(affected_flights) * 2000  # Operational disruption costs
    total_cost = maintenance_cost + operational_impact
    
    # Prepare result
    result = {
        'affected_aircraft': number_affected,
        'maintenance_hours': maintenance_hours,
        'affected_flights': len(affected_flights),
        'affected_passengers': affected_passengers,
        'maintenance_cost': maintenance_cost,
        'operational_impact': operational_impact,
        'total_cost': total_cost
    }
    
    # Create and store simulation result
    simulation_result = SimulationResult(
        simulation_type='Aircraft Maintenance Emergency',
        parameters=json.dumps(params),
        result_summary=f"Impact: {number_affected} aircraft grounded for {maintenance_hours} hours, {len(affected_flights)} flights affected",
        result_details=json.dumps(result)
    )
    
    db.session.add(simulation_result)
    db.session.commit()
    
    return result

def simulate_weather_disruption(params):
    """Simulate the impact of weather disruptions."""
    affected_airports_str = params.get('affected_airports', 'DEL,BOM')
    weather_type = params.get('weather_type', 'thunderstorm')
    duration_hours = int(params.get('duration_hours', 6))
    severity = params.get('severity', 'moderate')
    
    # Parse affected airports
    affected_airport_codes = [code.strip() for code in affected_airports_str.split(',')]
    affected_airports = Airport.query.filter(Airport.code.in_(affected_airport_codes)).all()
    
    if not affected_airports:
        logger.warning("No valid airports specified for weather disruption")
        return None
    
    # Calculate operational impact based on weather and severity
    capacity_reduction = {
        'light': {'fog': 30, 'rain': 20, 'thunderstorm': 40, 'snow': 50},
        'moderate': {'fog': 50, 'rain': 40, 'thunderstorm': 60, 'snow': 70},
        'severe': {'fog': 80, 'rain': 60, 'thunderstorm': 90, 'snow': 95}
    }
    
    reduction_percentage = capacity_reduction.get(severity, {}).get(weather_type, 50)
    
    # Find affected flights
    start_time = datetime.datetime.utcnow()
    end_time = start_time + timedelta(hours=duration_hours)
    
    affected_departures = Flight.query.filter(
        Flight.departure_airport_id.in_([a.id for a in affected_airports]),
        Flight.scheduled_departure >= start_time,
        Flight.scheduled_departure <= end_time
    ).all()
    
    affected_arrivals = Flight.query.filter(
        Flight.arrival_airport_id.in_([a.id for a in affected_airports]),
        Flight.scheduled_arrival >= start_time,
        Flight.scheduled_arrival <= end_time
    ).all()
    
    # Remove duplicates
    all_affected = list(set(affected_departures + affected_arrivals))
    
    # Calculate impact
    affected_passengers = sum(f.passenger_count if f.passenger_count else 0 for f in all_affected)
    
    # Categorize impact
    cancelled = int(len(all_affected) * reduction_percentage / 100)
    delayed = len(all_affected) - cancelled
    
    # Calculate costs
    cancellation_cost = cancelled * 5000
    delay_cost = delayed * 1000
    total_cost = cancellation_cost + delay_cost
    
    # Prepare result
    result = {
        'affected_airports': len(affected_airports),
        'weather_type': weather_type,
        'severity': severity,
        'duration_hours': duration_hours,
        'reduction_percentage': reduction_percentage,
        'affected_flights': len(all_affected),
        'cancelled_flights': cancelled,
        'delayed_flights': delayed,
        'affected_passengers': affected_passengers,
        'total_cost': total_cost
    }
    
    # Create and store simulation result
    simulation_result = SimulationResult(
        simulation_type='Weather Disruption Management',
        parameters=json.dumps(params),
        result_summary=f"Impact: {weather_type} affecting {len(affected_airports)} airports, {cancelled} cancellations, {delayed} delays",
        result_details=json.dumps(result)
    )
    
    db.session.add(simulation_result)
    db.session.commit()
    
    return result

def simulate_airport_capacity(params):
    """Simulate the impact of airport capacity constraints."""
    airport_code = params.get('airport_code', 'DEL')
    capacity_reduction_percentage = int(params.get('capacity_reduction_percentage', 30))
    duration_hours = int(params.get('duration_hours', 12))
    cause = params.get('cause', 'construction')
    
    # Find affected airport
    affected_airport = Airport.query.filter_by(code=airport_code).first()
    if not affected_airport:
        logger.warning(f"Airport {airport_code} not found")
        return None
    
    # Calculate time period
    start_time = datetime.datetime.utcnow()
    end_time = start_time + timedelta(hours=duration_hours)
    
    # Find affected flights
    affected_departures = Flight.query.filter(
        Flight.departure_airport_id == affected_airport.id,
        Flight.scheduled_departure >= start_time,
        Flight.scheduled_departure <= end_time
    ).all()
    
    affected_arrivals = Flight.query.filter(
        Flight.arrival_airport_id == affected_airport.id,
        Flight.scheduled_arrival >= start_time,
        Flight.scheduled_arrival <= end_time
    ).all()
    
    # Remove duplicates
    all_affected = list(set(affected_departures + affected_arrivals))
    
    # Calculate impact
    affected_passengers = sum(f.passenger_count if f.passenger_count else 0 for f in all_affected)
    
    # Determine flights that need to be cancelled/delayed based on capacity reduction
    flights_to_handle = int(len(all_affected) * capacity_reduction_percentage / 100)
    cancelled = int(flights_to_handle * 0.4)  # 40% of affected flights cancelled
    delayed = flights_to_handle - cancelled    # Remaining are delayed
    
    # Calculate costs
    cancellation_cost = cancelled * 5000
    delay_cost = delayed * 1000
    facility_cost = 5000 if cause == 'construction' else 2000
    total_cost = cancellation_cost + delay_cost + facility_cost
    
    # Prepare result
    result = {
        'affected_airport': airport_code,
        'capacity_reduction': capacity_reduction_percentage,
        'duration_hours': duration_hours,
        'cause': cause,
        'affected_flights': len(all_affected),
        'cancelled_flights': cancelled,
        'delayed_flights': delayed,
        'affected_passengers': affected_passengers,
        'total_cost': total_cost
    }
    
    # Create and store simulation result
    simulation_result = SimulationResult(
        simulation_type='Airport Capacity Constraints',
        parameters=json.dumps(params),
        result_summary=f"Impact: {capacity_reduction_percentage}% capacity reduction at {airport_code}, {cancelled} cancellations, {delayed} delays",
        result_details=json.dumps(result)
    )
    
    db.session.add(simulation_result)
    db.session.commit()
    
    return result

def simulate_atc_restrictions(params):
    """Simulate the impact of air traffic control restrictions."""
    affected_airspace = params.get('affected_airspace', 'North India')
    restriction_type = params.get('restriction_type', 'flow_control')
    reduction_percentage = int(params.get('reduction_percentage', 40))
    duration_hours = int(params.get('duration_hours', 8))
    
    # Map airspace to airports
    airspace_mapping = {
        'North India': ['DEL', 'LKO', 'JAI'],
        'South India': ['MAA', 'BLR', 'HYD'],
        'West India': ['BOM', 'AMD', 'PNQ'],
        'East India': ['CCU', 'GAU', 'BBI'],
        'Central India': ['NAG', 'IDR', 'BHO']
    }
    
    affected_airport_codes = airspace_mapping.get(affected_airspace, ['DEL', 'BOM'])
    affected_airports = Airport.query.filter(Airport.code.in_(affected_airport_codes)).all()
    
    if not affected_airports:
        logger.warning(f"No airports found for airspace {affected_airspace}")
        return None
    
    # Calculate time period
    start_time = datetime.datetime.utcnow()
    end_time = start_time + timedelta(hours=duration_hours)
    
    # Find affected flights
    affected_departures = Flight.query.filter(
        Flight.departure_airport_id.in_([a.id for a in affected_airports]),
        Flight.scheduled_departure >= start_time,
        Flight.scheduled_departure <= end_time
    ).all()
    
    affected_arrivals = Flight.query.filter(
        Flight.arrival_airport_id.in_([a.id for a in affected_airports]),
        Flight.scheduled_arrival >= start_time,
        Flight.scheduled_arrival <= end_time
    ).all()
    
    # Remove duplicates
    all_affected = list(set(affected_departures + affected_arrivals))
    
    # Calculate impact based on restriction type
    delay_factor = {
        'flow_control': 30,
        'ground_stop': 90,
        'airspace_closure': 120,
        'rerouting': 45
    }
    
    avg_delay_minutes = delay_factor.get(restriction_type, 30)
    
    # Calculate affected flights based on reduction percentage
    affected_count = int(len(all_affected) * reduction_percentage / 100)
    
    # Calculate total delay
    total_delay_minutes = affected_count * avg_delay_minutes
    
    # Calculate affected passengers
    affected_passengers = sum(f.passenger_count if f.passenger_count else 0 for f in all_affected[:affected_count])
    
    # Calculate costs
    cost_per_minute = 50
    operational_cost = total_delay_minutes * cost_per_minute
    fuel_cost = affected_count * 500  # Additional fuel for holding patterns or rerouting
    total_cost = operational_cost + fuel_cost
    
    # Prepare result
    result = {
        'affected_airspace': affected_airspace,
        'restriction_type': restriction_type,
        'reduction_percentage': reduction_percentage,
        'duration_hours': duration_hours,
        'affected_airports': len(affected_airports),
        'affected_flights': affected_count,
        'affected_passengers': affected_passengers,
        'avg_delay_minutes': avg_delay_minutes,
        'total_delay_minutes': total_delay_minutes,
        'operational_cost': operational_cost,
        'fuel_cost': fuel_cost,
        'total_cost': total_cost
    }
    
    # Create and store simulation result
    simulation_result = SimulationResult(
        simulation_type='Air Traffic Control Restrictions',
        parameters=json.dumps(params),
        result_summary=f"Impact: {restriction_type} in {affected_airspace}, {affected_count} flights delayed by avg {avg_delay_minutes} minutes",
        result_details=json.dumps(result)
    )
    
    db.session.add(simulation_result)
    db.session.commit()
    
    return result

def simulate_fuel_shortage(params):
    """Simulate the impact of fuel shortages at airports."""
    affected_airports_str = params.get('affected_airports', 'DEL,BOM')
    shortage_percentage = int(params.get('shortage_percentage', 30))
    duration_days = int(params.get('duration_days', 2))
    priority_flights = params.get('priority_flights', 'international')
    
    # Parse affected airports
    affected_airport_codes = [code.strip() for code in affected_airports_str.split(',')]
    affected_airports = Airport.query.filter(Airport.code.in_(affected_airport_codes)).all()
    
    if not affected_airports:
        logger.warning("No valid airports specified for fuel shortage")
        return None
    
    # Calculate time period
    start_time = datetime.datetime.utcnow()
    end_time = start_time + timedelta(days=duration_days)
    
    # Find affected departing flights
    affected_flights = Flight.query.filter(
        Flight.departure_airport_id.in_([a.id for a in affected_airports]),
        Flight.scheduled_departure >= start_time,
        Flight.scheduled_departure <= end_time
    ).all()
    
    if not affected_flights:
        logger.warning("No flights found for the affected airports in the given time period")
        return None
    
    # Calculate impact based on shortage percentage and priority
    affected_count = int(len(affected_flights) * shortage_percentage / 100)
    
    # Determine which flights to prioritize
    if priority_flights == 'international':
        # This is a simplified priority logic - in reality would be more complex
        prioritized = [f for f in affected_flights if random.random() > 0.7]  # Simulating international flights
    elif priority_flights == 'wide_body':
        prioritized = [f for f in affected_flights if f.aircraft_id and Aircraft.query.get(f.aircraft_id).aircraft_type in ['B787', 'A330']]
    else:
        prioritized = [f for f in affected_flights if random.random() > 0.5]  # Random prioritization
    
    # Calculate cancellations - non-prioritized flights are more likely to be cancelled
    non_prioritized = [f for f in affected_flights if f not in prioritized]
    
    # Calculate cancellations and delays
    cancellations = int(affected_count * 0.3)  # 30% of affected flights are cancelled
    delays = affected_count - cancellations
    
    # Calculate affected passengers
    affected_passengers = sum(f.passenger_count if f.passenger_count else 0 for f in affected_flights[:affected_count])
    
    # Calculate costs
    cancellation_cost = cancellations * 5000
    delay_cost = delays * 1000
    additional_fuel_cost = delays * 800  # Cost of sourcing emergency fuel or tanking extra
    total_cost = cancellation_cost + delay_cost + additional_fuel_cost
    
    # Prepare result
    result = {
        'affected_airports': len(affected_airports),
        'shortage_percentage': shortage_percentage,
        'duration_days': duration_days,
        'priority_flights': priority_flights,
        'affected_flights': affected_count,
        'cancelled_flights': cancellations,
        'delayed_flights': delays,
        'affected_passengers': affected_passengers,
        'cancellation_cost': cancellation_cost,
        'delay_cost': delay_cost,
        'additional_fuel_cost': additional_fuel_cost,
        'total_cost': total_cost
    }
    
    # Create and store simulation result
    simulation_result = SimulationResult(
        simulation_type='Fuel Shortage Scenarios',
        parameters=json.dumps(params),
        result_summary=f"Impact: {shortage_percentage}% fuel shortage at {len(affected_airports)} airports, {cancellations} cancellations, {delays} delays",
        result_details=json.dumps(result)
    )
    
    db.session.add(simulation_result)
    db.session.commit()
    
    return result

def simulate_passenger_connections(params):
    """Simulate the impact of missed passenger connections."""
    try:
        minimum_connection_time = int(params.get('minimum_connection_time', 45))
    except (ValueError, TypeError):
        minimum_connection_time = 45  # Default value if conversion fails
        
    affected_hub = params.get('affected_hub', 'DEL')
    
    try:
        passenger_volume = int(params.get('passenger_volume', 500))
    except (ValueError, TypeError):
        passenger_volume = 500  # Default value if conversion fails
        
    rebooking_options = params.get('rebooking_options', 'moderate')
    
    # Find affected airport
    affected_airport = Airport.query.filter_by(code=affected_hub).first()
    if not affected_airport:
        logger.warning(f"Airport {affected_hub} not found")
        return None
    
    # Calculate time period for analysis
    start_time = datetime.datetime.utcnow()
    end_time = start_time + timedelta(hours=24)
    
    # Find arriving flights to the hub
    arriving_flights = Flight.query.filter(
        Flight.arrival_airport_id == affected_airport.id,
        Flight.scheduled_arrival >= start_time,
        Flight.scheduled_arrival <= end_time
    ).all()
    
    # Find departing flights from the hub
    departing_flights = Flight.query.filter(
        Flight.departure_airport_id == affected_airport.id,
        Flight.scheduled_departure >= start_time,
        Flight.scheduled_departure <= end_time
    ).all()
    
    if not arriving_flights or not departing_flights:
        logger.warning(f"Insufficient flights found for connection analysis at {affected_hub}")
        return None
    
    # Analyze potential connections
    connection_pairs = []
    for arr_flight in arriving_flights:
        for dep_flight in departing_flights:
            connection_time = (dep_flight.scheduled_departure - arr_flight.scheduled_arrival).total_seconds() / 60
            if connection_time > 0 and connection_time < 180:  # Consider connections within 3 hours
                connection_pairs.append((arr_flight, dep_flight, connection_time))
    
    # Calculate tight connections (those near the minimum connection time)
    tight_connections = [pair for pair in connection_pairs if pair[2] < minimum_connection_time + 15]
    
    # Calculate missed connections based on passenger volume
    missed_connections = int(len(tight_connections) * passenger_volume / 1000)  # Scale based on passenger volume
    
    # Calculate rebooking capacity
    rebooking_capacity = {
        'low': 0.4,
        'moderate': 0.7,
        'high': 0.9
    }
    
    rebooking_rate = rebooking_capacity.get(rebooking_options, 0.7)
    
    # Calculate impact
    rebooked_passengers = int(missed_connections * rebooking_rate)
    stranded_passengers = missed_connections - rebooked_passengers
    
    # Calculate costs
    rebooking_cost = rebooked_passengers * 150  # Cost per rebooked passenger
    accommodation_cost = stranded_passengers * 100  # Hotel and meals for stranded passengers
    compensation_cost = missed_connections * 50  # General compensation
    total_cost = rebooking_cost + accommodation_cost + compensation_cost
    
    # Prepare result
    result = {
        'affected_hub': affected_hub,
        'minimum_connection_time': minimum_connection_time,
        'total_connections': len(connection_pairs),
        'tight_connections': len(tight_connections),
        'missed_connections': missed_connections,
        'rebooked_passengers': rebooked_passengers,
        'stranded_passengers': stranded_passengers,
        'rebooking_cost': rebooking_cost,
        'accommodation_cost': accommodation_cost,
        'compensation_cost': compensation_cost,
        'total_cost': total_cost
    }
    
    # Create and store simulation result
    simulation_result = SimulationResult(
        simulation_type='Passenger Connection Impacts',
        parameters=json.dumps(params),
        result_summary=f"Impact: {missed_connections} missed connections at {affected_hub}, {stranded_passengers} stranded passengers",
        result_details=json.dumps(result)
    )
    
    db.session.add(simulation_result)
    db.session.commit()
    
    return result

def simulate_schedule_vulnerability(params):
    """Simulate schedule vulnerability detection."""
    time_period = params.get('time_period', '7d')
    fleet_utilization = int(params.get('fleet_utilization', 80))
    crew_utilization = int(params.get('crew_utilization', 85))
    buffer_minutes = int(params.get('buffer_minutes', 30))
    
    # Parse time period
    if time_period == '1d':
        days = 1
    elif time_period == '3d':
        days = 3
    elif time_period == '7d':
        days = 7
    else:
        days = 7
    
    # Calculate analysis period
    start_time = datetime.datetime.utcnow()
    end_time = start_time + timedelta(days=days)
    
    # Get all flights in the period
    flights = Flight.query.filter(
        Flight.scheduled_departure >= start_time,
        Flight.scheduled_departure <= end_time
    ).all()
    
    if not flights:
        logger.warning("No flights found for schedule vulnerability analysis")
        return None
    
    # Analyze aircraft utilization
    aircraft_rotations = {}
    for flight in flights:
        if flight.aircraft_id:
            if flight.aircraft_id not in aircraft_rotations:
                aircraft_rotations[flight.aircraft_id] = []
            aircraft_rotations[flight.aircraft_id].append(flight)
    
    # Calculate tight turnarounds (less than buffer minutes)
    tight_turnarounds = 0
    for aircraft_id, aircraft_flights in aircraft_rotations.items():
        sorted_flights = sorted(aircraft_flights, key=lambda f: f.scheduled_departure)
        for i in range(len(sorted_flights) - 1):
            current = sorted_flights[i]
            next_flight = sorted_flights[i + 1]
            turnaround_time = (next_flight.scheduled_departure - current.scheduled_arrival).total_seconds() / 60
            if turnaround_time < buffer_minutes:
                tight_turnarounds += 1
    
    # Calculate crew duty time issues
    duty_time_issues = int(len(flights) * (crew_utilization / 100) * 0.2)  # Simplified calculation
    
    # Calculate fleet utilization issues
    high_utilization_days = int(days * fleet_utilization / 100)
    
    # Calculate vulnerability score (0-100)
    vulnerability_score = (tight_turnarounds * 5 + duty_time_issues * 3 + high_utilization_days * 10) / len(flights) * 10
    vulnerability_score = min(100, vulnerability_score)
    
    # Categorize vulnerability
    if vulnerability_score < 30:
        vulnerability_category = 'Low'
    elif vulnerability_score < 60:
        vulnerability_category = 'Medium'
    else:
        vulnerability_category = 'High'
    
    # Calculate potential cost of disruptions
    potential_disruption_cost = int(tight_turnarounds * 1000 + duty_time_issues * 1500)
    
    # Prepare result
    result = {
        'time_period_days': days,
        'total_flights': len(flights),
        'fleet_utilization': fleet_utilization,
        'crew_utilization': crew_utilization,
        'buffer_minutes': buffer_minutes,
        'tight_turnarounds': tight_turnarounds,
        'duty_time_issues': duty_time_issues,
        'high_utilization_days': high_utilization_days,
        'vulnerability_score': vulnerability_score,
        'vulnerability_category': vulnerability_category,
        'potential_disruption_cost': potential_disruption_cost
    }
    
    # Create and store simulation result
    simulation_result = SimulationResult(
        simulation_type='Schedule Vulnerability Detection',
        parameters=json.dumps(params),
        result_summary=f"Vulnerability: {vulnerability_category} ({vulnerability_score:.1f}/100), {tight_turnarounds} tight turnarounds, ₹{potential_disruption_cost:,} potential cost",
        result_details=json.dumps(result)
    )
    
    db.session.add(simulation_result)
    db.session.commit()
    
    return result

def simulate_ground_handling_delays(params):
    """Simulate the impact of ground handling delays."""
    airport_code = params.get('airport_code', 'DEL')
    handling_area = params.get('handling_area', 'baggage')
    delay_minutes = int(params.get('delay_minutes', 25))
    flights_per_hour = int(params.get('flights_per_hour', 10))
    
    # Find affected airport
    affected_airport = Airport.query.filter_by(code=airport_code).first()
    if not affected_airport:
        logger.warning(f"Airport {airport_code} not found")
        return None
    
    # Calculate time period - assume 6 hour disruption
    start_time = datetime.datetime.utcnow()
    duration_hours = 6
    end_time = start_time + timedelta(hours=duration_hours)
    
    # Find affected flights
    affected_departures = Flight.query.filter(
        Flight.departure_airport_id == affected_airport.id,
        Flight.scheduled_departure >= start_time,
        Flight.scheduled_departure <= end_time
    ).all()
    
    if not affected_departures:
        logger.warning(f"No departing flights found for airport {airport_code} in the given time period")
        return None
    
    # Calculate total affected flights based on flights per hour
    total_affected = min(len(affected_departures), flights_per_hour * duration_hours)
    
    # Calculate impact based on handling area
    impact_multiplier = {
        'baggage': 0.8,       # 80% of flights affected by baggage delays
        'check_in': 0.9,      # 90% of flights affected by check-in delays
        'security': 0.7,      # 70% of flights affected by security delays
        'boarding': 0.6,      # 60% of flights affected by boarding delays
        'catering': 0.5,      # 50% of flights affected by catering delays
        'cleaning': 0.4,      # 40% of flights affected by cleaning delays
        'fueling': 0.8        # 80% of flights affected by fueling delays
    }
    
    affected_flights = int(total_affected * impact_multiplier.get(handling_area, 0.6))
    
    # Calculate delays
    total_delay_minutes = affected_flights * delay_minutes
    
    # Calculate passenger impact
    affected_passengers = sum(f.passenger_count if f.passenger_count else 0 for f in affected_departures[:affected_flights])
    
    # Calculate costs
    operational_cost = affected_flights * 500  # Base operational cost
    passenger_compensation = affected_flights * 200  # Passenger compensation
    handling_recovery = affected_flights * 300  # Cost to expedite handling recovery
    total_cost = operational_cost + passenger_compensation + handling_recovery
    
    # Prepare result
    result = {
        'affected_airport': airport_code,
        'handling_area': handling_area,
        'delay_minutes': delay_minutes,
        'duration_hours': duration_hours,
        'affected_flights': affected_flights,
        'total_delay_minutes': total_delay_minutes,
        'affected_passengers': affected_passengers,
        'operational_cost': operational_cost,
        'passenger_compensation': passenger_compensation,
        'handling_recovery': handling_recovery,
        'total_cost': total_cost
    }
    
    # Create and store simulation result
    simulation_result = SimulationResult(
        simulation_type='Ground Handling Delays',
        parameters=json.dumps(params),
        result_summary=f"Impact: {affected_flights} flights delayed by {handling_area} issues, {total_delay_minutes} total delay minutes",
        result_details=json.dumps(result)
    )
    
    db.session.add(simulation_result)
    db.session.commit()
    
    return result

def simulate_security_incident(params):
    """Simulate the impact of a security incident."""
    airport_code = params.get('airport_code', 'DEL')
    incident_type = params.get('incident_type', 'security_breach')
    resolution_time = int(params.get('resolution_time', 120))
    terminal_areas = params.get('terminal_areas', 'partial')
    
    # Find affected airport
    affected_airport = Airport.query.filter_by(code=airport_code).first()
    if not affected_airport:
        logger.warning(f"Airport {airport_code} not found")
        return None
    
    # Calculate time period
    start_time = datetime.datetime.utcnow()
    end_time = start_time + timedelta(minutes=resolution_time)
    
    # Find affected flights
    affected_departures = Flight.query.filter(
        Flight.departure_airport_id == affected_airport.id,
        Flight.scheduled_departure >= start_time,
        Flight.scheduled_departure <= end_time
    ).all()
    
    affected_arrivals = Flight.query.filter(
        Flight.arrival_airport_id == affected_airport.id,
        Flight.scheduled_arrival >= start_time,
        Flight.scheduled_arrival <= end_time
    ).all()
    
    # Calculate impact based on terminal areas affected
    terminal_impact = {
        'partial': 0.3,   # 30% of flights affected if partial terminal closure
        'full': 0.8,      # 80% of flights affected if full terminal closure
        'complete': 1.0   # 100% of flights affected if complete airport closure
    }
    
    impact_factor = terminal_impact.get(terminal_areas, 0.5)
    
    # Calculate affected flights
    affected_departure_count = int(len(affected_departures) * impact_factor)
    affected_arrival_count = int(len(affected_arrivals) * impact_factor)
    total_affected = affected_departure_count + affected_arrival_count
    
    # Calculate impact based on incident type
    incident_severity = {
        'security_breach': 0.8,        # High impact
        'suspicious_item': 0.6,        # Medium impact
        'screening_issue': 0.4,        # Lower impact
        'perimeter_breach': 0.7,       # Medium-high impact
        'unauthorized_access': 0.5     # Medium impact
    }
    
    severity_factor = incident_severity.get(incident_type, 0.6)
    
    # Calculate cancellations and delays
    cancellations = int(total_affected * severity_factor * 0.3)  # 30% of affected flights cancelled
    delays = total_affected - cancellations
    
    # Calculate passenger impact
    affected_passengers = sum(f.passenger_count if f.passenger_count else 0 for f in affected_departures[:affected_departure_count])
    affected_passengers += sum(f.passenger_count if f.passenger_count else 0 for f in affected_arrivals[:affected_arrival_count])
    
    # Calculate costs
    security_response_cost = 10000 * severity_factor  # Base security response cost
    cancellation_cost = cancellations * 5000          # Cost per cancelled flight
    delay_cost = delays * 1000                        # Cost per delayed flight
    passenger_impact_cost = affected_passengers * 50  # Cost per affected passenger
    total_cost = security_response_cost + cancellation_cost + delay_cost + passenger_impact_cost
    
    # Prepare result
    result = {
        'affected_airport': airport_code,
        'incident_type': incident_type,
        'resolution_time': resolution_time,
        'terminal_areas': terminal_areas,
        'total_affected_flights': total_affected,
        'cancelled_flights': cancellations,
        'delayed_flights': delays,
        'affected_passengers': affected_passengers,
        'security_response_cost': security_response_cost,
        'cancellation_cost': cancellation_cost,
        'delay_cost': delay_cost,
        'passenger_impact_cost': passenger_impact_cost,
        'total_cost': total_cost
    }
    
    # Create and store simulation result
    simulation_result = SimulationResult(
        simulation_type='Security Incident Simulation',
        parameters=json.dumps(params),
        result_summary=f"Impact: {incident_type} at {airport_code}, {cancellations} cancellations, {delays} delays, {affected_passengers} affected passengers",
        result_details=json.dumps(result)
    )
    
    db.session.add(simulation_result)
    db.session.commit()
    
    return result

# Main simulation function to route to specific simulation based on type
def run_simulation(simulation_type, params):
    """Run a simulation based on the specified type and parameters."""
    simulation_functions = {
        'Flight Delay Impact Analysis': simulate_flight_delay,
        'Flight Cancellation Cost Calculation': simulate_cancellation_cost,
        'Crew Unavailability Handling': simulate_crew_unavailability,
        'Aircraft Maintenance Emergency': simulate_maintenance_emergency,
        'Weather Disruption Management': simulate_weather_disruption,
        'Airport Capacity Constraints': simulate_airport_capacity,
        'Air Traffic Control Restrictions': simulate_atc_restrictions,
        'Fuel Shortage Scenarios': simulate_fuel_shortage,
        'Passenger Connection Impacts': simulate_passenger_connections,
        'Schedule Vulnerability Detection': simulate_schedule_vulnerability,
        'Ground Handling Delays': simulate_ground_handling_delays,
        'Security Incident Simulation': simulate_security_incident
    }
    
    logger.info(f"Running simulation: {simulation_type}")
    
    # Get the appropriate simulation function
    simulation_func = simulation_functions.get(simulation_type)
    
    if not simulation_func:
        logger.error(f"Unknown simulation type: {simulation_type}")
        return None
    
    # Run the simulation
    try:
        result = simulation_func(params)
        return result
    except Exception as e:
        logger.exception(f"Error running simulation: {e}")
        return None
