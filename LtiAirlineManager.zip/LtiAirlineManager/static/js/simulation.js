/**
 * Polish Airlines Operations Management System
 * Simulation JavaScript
 */

// Example simulation parameter data for each simulation type
const simulationExamples = {
    'Flight Delay Impact Analysis': {
        delay_duration: '60',
        affected_airport: 'DEL',
        start_time: new Date().toISOString().split('T')[0] + 'T08:00',
        propagation_factor: '0.7'
    },
    'Flight Cancellation Cost Calculation': {
        flight_numbers: 'LTI-101,LTI-203,LTI-415',
        rebooking_capacity: '70',
        hotel_cost: '80',
        compensation_level: 'medium'
    },
    'Crew Unavailability Handling': {
        unavailable_crew_percentage: '15',
        position_affected: 'captain',
        duration_days: '2',
        advance_notice: '1'
    },
    'Aircraft Maintenance Emergency': {
        aircraft_type: 'A320',
        number_affected: '2',
        maintenance_duration: '48',
        parts_availability: 'normal'
    },
    'Weather Disruption Management': {
        affected_airports: 'DEL,BOM',
        weather_type: 'thunderstorm',
        duration_hours: '6',
        severity: 'moderate'
    },
    'Airport Capacity Constraints': {
        airport_code: 'DEL',
        capacity_reduction_percentage: '30',
        duration_hours: '12',
        cause: 'construction'
    },
    'Air Traffic Control Restrictions': {
        affected_airspace: 'Western India',
        restriction_type: 'speed',
        reduction_percentage: '25',
        duration_hours: '8'
    },
    'Fuel Shortage Scenarios': {
        affected_airports: 'BOM,COK',
        shortage_percentage: '20',
        duration_days: '2',
        priority_flights: 'international'
    },
    'Passenger Connection Impacts': {
        minimum_connection_time: '45',
        affected_hub: 'DEL',
        passenger_volume: '1000',
        rebooking_options: 'limited'
    },
    'Schedule Vulnerability Detection': {
        time_period: new Date().toISOString().split('T')[0],
        fleet_utilization: '85',
        crew_utilization: '80',
        buffer_minutes: '30'
    },
    'Ground Handling Delays': {
        airport_code: 'BOM',
        handling_area: 'baggage',
        delay_minutes: '25',
        flights_per_hour: '8'
    },
    'Security Incident Simulation': {
        airport_code: 'DEL',
        incident_type: 'terminal_evacuation',
        resolution_time: '90',
        terminal_areas: 'domestic'
    }
};

// Simulation parameter descriptions for help tooltips
const parameterDescriptions = {
    'delay_duration': 'Average delay in minutes per affected flight',
    'affected_airport': 'IATA code of the airport where the delay originates',
    'start_time': 'When the delay scenario begins',
    'propagation_factor': 'Factor (0-1) determining how delays affect downstream flights',
    'flight_numbers': 'Comma-separated list of flight numbers to simulate cancellation',
    'rebooking_capacity': 'Percentage of passengers that can be rebooked on other flights',
    'hotel_cost': 'Average cost per passenger for overnight accommodation (in $)',
    'compensation_level': 'Level of compensation provided to affected passengers',
    'unavailable_crew_percentage': 'Percentage of crew that becomes unavailable',
    'position_affected': 'Primary crew position affected by the unavailability',
    'duration_days': 'Number of days the unavailability lasts',
    'advance_notice': 'Days of advance notice before crew becomes unavailable',
    'aircraft_type': 'Aircraft type affected by maintenance',
    'number_affected': 'Number of aircraft requiring emergency maintenance',
    'maintenance_duration': 'Expected duration of maintenance in hours',
    'parts_availability': 'Availability of parts needed for maintenance',
    'affected_airports': 'Comma-separated list of affected airport IATA codes',
    'weather_type': 'Type of weather event causing the disruption',
    'duration_hours': 'Expected duration of the disruption in hours',
    'severity': 'Severity level of the disruption',
    'airport_code': 'IATA code of the affected airport',
    'capacity_reduction_percentage': 'Percentage reduction in airport capacity',
    'cause': 'Cause of the capacity constraint',
    'affected_airspace': 'Region of airspace with ATC restrictions',
    'restriction_type': 'Type of ATC restriction applied',
    'reduction_percentage': 'Percentage reduction in traffic flow',
    'shortage_percentage': 'Percentage reduction in fuel availability',
    'priority_flights': 'Flight types given priority during shortage',
    'minimum_connection_time': 'Minimum connection time in minutes',
    'affected_hub': 'Connection hub airport IATA code',
    'passenger_volume': 'Number of connecting passengers',
    'rebooking_options': 'Availability of rebooking options',
    'time_period': 'Date to analyze for schedule vulnerabilities',
    'fleet_utilization': 'Percentage utilization of aircraft fleet',
    'crew_utilization': 'Percentage utilization of crew resources',
    'buffer_minutes': 'Minimum buffer time between flights in minutes',
    'handling_area': 'Specific ground handling area affected',
    'delay_minutes': 'Average delay in minutes per ground operation',
    'flights_per_hour': 'Number of flights per hour affected by delays',
    'incident_type': 'Type of security incident',
    'resolution_time': 'Expected time to resolve the incident in minutes',
    'terminal_areas': 'Terminal areas affected by the security incident'
};

// Initialize the simulation interface
document.addEventListener('DOMContentLoaded', function() {
    // Initialize feather icons
    feather.replace();
    
    // Add listeners to simulation type selector
    const simulationTypeSelect = document.getElementById('simulation-type');
    if (simulationTypeSelect) {
        simulationTypeSelect.addEventListener('change', function() {
            loadSimulationParams(this.value);
        });
        
        // Load default simulation
        if (simulationTypeSelect.value) {
            loadSimulationParams(simulationTypeSelect.value);
        }
    }
    
    // Add help listeners
    document.querySelectorAll('.fill-example').forEach(button => {
        button.addEventListener('click', function() {
            const simulationType = document.getElementById('simulation-type').value;
            fillExampleValues(simulationType);
        });
    });
    
    // Initialize tooltips
    initTooltips();
});

// Load parameters for a simulation type
function loadSimulationParams(simulationType) {
    // Show loading indicator
    const paramContainer = document.getElementById('simulation-params');
    paramContainer.innerHTML = '<div class="text-center py-4"><i data-feather="loader" class="spin"></i> Loading parameters...</div>';
    
    // Fetch parameters
    fetch(`/simulation/params/${encodeURIComponent(simulationType)}`)
        .then(response => response.json())
        .then(data => {
            renderParameterForm(simulationType, data.params);
        })
        .catch(error => {
            console.error('Error fetching simulation parameters:', error);
            paramContainer.innerHTML = `<div class="alert alert-danger">Error loading simulation parameters: ${error.message}</div>`;
        });
}

// Render the parameter form
function renderParameterForm(simulationType, params) {
    const paramContainer = document.getElementById('simulation-params');
    
    if (!params || params.length === 0) {
        paramContainer.innerHTML = '<div class="alert alert-warning">No parameters available for this simulation type.</div>';
        return;
    }
    
    let formHtml = '<div class="card mb-4 glass-card animate-in"><div class="card-body">';
    formHtml += '<div class="row mb-3">';
    formHtml += '<div class="col"><h5 class="card-title mb-0">Simulation Parameters</h5></div>';
    formHtml += '<div class="col-auto">';
    formHtml += '<button type="button" class="btn btn-sm btn-outline-primary fill-example">';
    formHtml += '<i data-feather="clipboard" class="feather-small mr-1"></i> Fill Example Values';
    formHtml += '</button>';
    formHtml += '</div></div>';
    
    // Add form fields
    params.forEach(param => {
        const paramId = `param-${param}`;
        const description = parameterDescriptions[param] || 'Parameter for simulation';
        
        formHtml += `
        <div class="form-group">
            <label for="${paramId}" class="d-flex align-items-center">
                ${formatParamLabel(param)}
                <i data-feather="help-circle" class="feather-small ml-1 text-muted parameter-help" 
                   data-toggle="tooltip" title="${description}"></i>
            </label>
            <input type="text" class="form-control" id="${paramId}" name="${param}" 
                   placeholder="Enter value for ${formatParamLabel(param).toLowerCase()}">
        </div>`;
    });
    
    formHtml += '</div></div>';
    
    // Add run button
    formHtml += `
    <div class="text-center">
        <button type="submit" class="btn btn-primary px-5">
            <i data-feather="play" class="feather-small mr-1"></i> Run Simulation
        </button>
    </div>`;
    
    paramContainer.innerHTML = formHtml;
    
    // Re-initialize feather icons
    feather.replace();
    
    // Initialize tooltips
    initTooltips();
    
    // Add example value button listener
    document.querySelectorAll('.fill-example').forEach(button => {
        button.addEventListener('click', function() {
            fillExampleValues(simulationType);
        });
    });
}

// Fill the form with example values
function fillExampleValues(simulationType) {
    const examples = simulationExamples[simulationType];
    if (!examples) return;
    
    // Fill each parameter with example value
    Object.keys(examples).forEach(param => {
        const input = document.querySelector(`[name="${param}"]`);
        if (input) {
            input.value = examples[param];
        }
    });
}

// Format parameter name as label
function formatParamLabel(param) {
    return param
        .split('_')
        .map(word => word.charAt(0).toUpperCase() + word.slice(1))
        .join(' ');
}

// Initialize tooltips
function initTooltips() {
    $('[data-toggle="tooltip"]').tooltip();
}

// Add animation to feather icons
function initIconAnimations() {
    document.querySelectorAll('.spin').forEach(icon => {
        icon.classList.add('feather-spin');
    });
}