// LTIMindtree Airlines - Dashboard.js
// Contains JS functionality for the main dashboard

document.addEventListener('DOMContentLoaded', function() {
    // Initialize Feather icons
    feather.replace();
    
    // Initialize all tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    });
    
    // Initialize charts if the elements exist
    initializeCharts();
    
    // Update server time
    updateServerTime();
    
    // Set active nav item
    setActiveNavItem();
});

// Update server time display
function updateServerTime() {
    const timeElement = document.getElementById('server-time');
    if (timeElement) {
        const now = new Date();
        timeElement.textContent = now.toTimeString().substring(0, 8);
        setTimeout(updateServerTime, 1000);
    }
}

// Set the active navigation item based on current URL
function setActiveNavItem() {
    const currentPath = window.location.pathname;
    const navItems = document.querySelectorAll('.navbar-nav .nav-item');
    
    navItems.forEach(item => {
        const link = item.querySelector('.nav-link');
        const href = link.getAttribute('href');
        
        // Remove active class from all
        item.classList.remove('active');
        
        // Check if current path matches the nav item's href
        if (currentPath === href || (href !== '/' && currentPath.includes(href))) {
            item.classList.add('active');
        } else if (currentPath === '/' && href === '/') {
            item.classList.add('active');
        }
    });
}

// Initialize dashboard charts
function initializeCharts() {
    // Aircraft Status Distribution Chart
    const aircraftStatusChart = document.getElementById('aircraftStatusChart');
    if (aircraftStatusChart) {
        // Get data from data attributes or use defaults
        const labels = JSON.parse(aircraftStatusChart.getAttribute('data-labels') || '[]');
        const data = JSON.parse(aircraftStatusChart.getAttribute('data-values') || '[]');
        
        new Chart(aircraftStatusChart, {
            type: 'doughnut',
            data: {
                labels: labels,
                datasets: [{
                    data: data,
                    backgroundColor: [
                        '#28a745',  // available
                        '#003F72',  // in_flight
                        '#ffc107',  // maintenance
                        '#dc3545'   // grounded
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                legend: {
                    position: 'bottom',
                    labels: {
                        boxWidth: 12
                    }
                },
                cutoutPercentage: 70,
                tooltips: {
                    callbacks: {
                        label: function(tooltipItem, data) {
                            const value = data.datasets[0].data[tooltipItem.index];
                            const label = data.labels[tooltipItem.index];
                            const total = data.datasets[0].data.reduce((a, b) => a + b, 0);
                            const percentage = Math.round((value / total) * 100);
                            return `${label}: ${value} (${percentage}%)`;
                        }
                    }
                }
            }
        });
    }
    
    // Crew Status Distribution Chart
    const crewStatusChart = document.getElementById('crewStatusChart');
    if (crewStatusChart) {
        // Get data from data attributes
        const labels = JSON.parse(crewStatusChart.getAttribute('data-labels') || '[]');
        const data = JSON.parse(crewStatusChart.getAttribute('data-values') || '[]');
        
        new Chart(crewStatusChart, {
            type: 'doughnut',
            data: {
                labels: labels,
                datasets: [{
                    data: data,
                    backgroundColor: [
                        '#28a745',  // available
                        '#003F72',  // on_duty
                        '#ff7400',  // rest
                        '#dc3545',  // sick
                        '#6c757d'   // other
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                legend: {
                    position: 'bottom',
                    labels: {
                        boxWidth: 12
                    }
                },
                cutoutPercentage: 70,
                tooltips: {
                    callbacks: {
                        label: function(tooltipItem, data) {
                            const value = data.datasets[0].data[tooltipItem.index];
                            const label = data.labels[tooltipItem.index];
                            const total = data.datasets[0].data.reduce((a, b) => a + b, 0);
                            const percentage = Math.round((value / total) * 100);
                            return `${label}: ${value} (${percentage}%)`;
                        }
                    }
                }
            }
        });
    }
    
    // Flight Activity Chart
    const flightActivityChart = document.getElementById('flightActivityChart');
    if (flightActivityChart) {
        // Get data from data attributes
        const labels = JSON.parse(flightActivityChart.getAttribute('data-labels') || '["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]');
        const data = JSON.parse(flightActivityChart.getAttribute('data-values') || '[0, 0, 0, 0, 0, 0, 0]');
        // Calculate arrivals as slightly different from departures for visual effect
        const arrivals = data.map(val => Math.max(0, val - Math.floor(Math.random() * 5)));
        
        new Chart(flightActivityChart, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [
                    {
                        label: 'Departures',
                        data: data,
                        backgroundColor: '#003F72',
                        borderColor: '#003F72',
                        borderWidth: 1
                    },
                    {
                        label: 'Arrivals',
                        data: arrivals,
                        backgroundColor: '#ff7400',
                        borderColor: '#ff7400',
                        borderWidth: 1
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero: true
                        }
                    }]
                },
                legend: {
                    position: 'bottom'
                }
            }
        });
    }
    
    // On-Time Performance Chart
    const onTimePerformanceChart = document.getElementById('onTimePerformanceChart');
    if (onTimePerformanceChart) {
        // Get data from data attributes
        const labels = JSON.parse(onTimePerformanceChart.getAttribute('data-labels') || '["Jan", "Feb", "Mar", "Apr", "May", "Jun"]');
        const data = JSON.parse(onTimePerformanceChart.getAttribute('data-values') || '[85, 87, 88, 86, 89, 90]');
        
        new Chart(onTimePerformanceChart, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: 'On-Time %',
                    data: data,
                    backgroundColor: 'rgba(0, 63, 114, 0.1)',
                    borderColor: '#003F72',
                    borderWidth: 2,
                    pointBackgroundColor: '#003F72',
                    pointRadius: 4,
                    tension: 0.3,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero: false,
                            min: 80,
                            max: 100
                        }
                    }]
                },
                legend: {
                    display: false
                }
            }
        });
    }
    
    // Fleet Utilization Chart
    const fleetUtilizationChart = document.getElementById('fleetUtilizationChart');
    if (fleetUtilizationChart) {
        const aircraftTypes = ['B737', 'A320', 'B787', 'A330', 'ATR72'];
        const utilization = [82, 79, 88, 85, 76]; // Hours per month
        
        new Chart(fleetUtilizationChart, {
            type: 'horizontalBar',
            data: {
                labels: aircraftTypes,
                datasets: [{
                    label: 'Hours/Month',
                    data: utilization,
                    backgroundColor: [
                        'rgba(0, 63, 114, 0.7)',
                        'rgba(0, 63, 114, 0.65)',
                        'rgba(0, 63, 114, 0.8)',
                        'rgba(0, 63, 114, 0.75)',
                        'rgba(0, 63, 114, 0.6)'
                    ],
                    borderColor: '#003F72',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    xAxes: [{
                        ticks: {
                            beginAtZero: true
                        }
                    }]
                },
                legend: {
                    display: false
                }
            }
        });
    }
}

// Handle click on alert rows to show details
function setupAlertRowHandlers() {
    const alertRows = document.querySelectorAll('.alert-row');
    alertRows.forEach(row => {
        row.addEventListener('click', function() {
            // Get the alert ID or other data from the row
            const alertId = this.getAttribute('data-alert-id');
            
            // In a real app, you would fetch alert details and show in a modal
            // For now we'll just toggle a class
            this.classList.toggle('expanded');
        });
    });
}

// Function to refresh dashboard data
function refreshDashboardData() {
    // In a real application, this would make an AJAX call to get fresh data
    console.log("Refreshing dashboard data...");
    
    // Example of how you would update the data:
    /*
    fetch('/api/dashboard/refresh')
        .then(response => response.json())
        .then(data => {
            // Update stats
            document.getElementById('total-aircraft-count').textContent = data.total_aircraft;
            document.getElementById('available-aircraft-count').textContent = data.available_aircraft;
            // etc...
            
            // Reinitialize charts with new data
            initializeCharts(data);
        })
        .catch(error => {
            console.error('Error refreshing dashboard:', error);
        });
    */
}

// Add a handler for the refresh button if it exists
const refreshButton = document.getElementById('refresh-dashboard');
if (refreshButton) {
    refreshButton.addEventListener('click', refreshDashboardData);
}
