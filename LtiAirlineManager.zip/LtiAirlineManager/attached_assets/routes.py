from flask import render_template, redirect, url_for, request, jsonify, flash, session
from datetime import datetime, timedelta
import logging
from sqlalchemy import func

from models import (
    db, Crew, Aircraft, Flight, Airport, Schedule, OperationalAlert, OperationalDecision,
    crew_flight,
    CREW_STATUS_AVAILABLE, CREW_STATUS_ON_DUTY, CREW_STATUS_REST,
    AIRCRAFT_STATUS_AVAILABLE, AIRCRAFT_STATUS_IN_FLIGHT,
    FLIGHT_STATUS_SCHEDULED, FLIGHT_STATUS_DELAYED, FLIGHT_STATUS_CANCELLED,
    ALERT_SEVERITY_LOW, ALERT_SEVERITY_MEDIUM, ALERT_SEVERITY_HIGH, ALERT_SEVERITY_CRITICAL
)
from utils import get_crew_availability, get_aircraft_availability, calculate_risk_score, analyze_schedule_vulnerabilities
from optimizer import generate_decision_options, evaluate_decision, implement_decision

logger = logging.getLogger(__name__)

def register_routes(app):
    # Dashboard route
    @app.route('/')
    def dashboard():
        # Get summary statistics
        crew_count = Crew.query.count()
        aircraft_count = Aircraft.query.count()
        flight_count = Flight.query.count()
        
        # Get crews and aircraft by status
        crew_by_status = db.session.query(
            Crew.status, func.count(Crew.id)
        ).group_by(Crew.status).all()
        
        aircraft_by_status = db.session.query(
            Aircraft.status, func.count(Aircraft.id)
        ).group_by(Aircraft.status).all()
        
        # Get active alerts
        active_alerts = OperationalAlert.query.filter(
            OperationalAlert.resolved_at == None
        ).order_by(OperationalAlert.severity.desc(), OperationalAlert.created_at.desc()).limit(5).all()
        
        # Get today's flights
        now = datetime.utcnow()
        today = now.date()
        today_start = datetime.combine(today, datetime.min.time())
        today_end = datetime.combine(today, datetime.max.time())
        
        todays_flights = Flight.query.filter(
            Flight.scheduled_departure.between(today_start, today_end)
        ).order_by(Flight.scheduled_departure).all()
        
        # Calculate schedule vulnerability stats
        vulnerabilities = analyze_schedule_vulnerabilities()
        
        # Calculate completion factor and on-time performance
        completed_flights = Flight.query.filter(
            Flight.scheduled_departure >= today_start - timedelta(days=7),
            Flight.scheduled_departure < today_start,
            Flight.status == 'completed'
        ).count()
        
        total_flights = Flight.query.filter(
            Flight.scheduled_departure >= today_start - timedelta(days=7),
            Flight.scheduled_departure < today_start
        ).count()
        
        on_time_flights = Flight.query.filter(
            Flight.scheduled_departure >= today_start - timedelta(days=7),
            Flight.scheduled_departure < today_start,
            Flight.status == 'completed',
            Flight.actual_departure <= Flight.scheduled_departure + timedelta(minutes=15)
        ).count()
        
        completion_factor = round((completed_flights / total_flights * 100) if total_flights > 0 else 0, 1)
        otp = round((on_time_flights / total_flights * 100) if total_flights > 0 else 0, 1)
        
        return render_template(
            'dashboard.html',
            now=now,
            crew_count=crew_count,
            aircraft_count=aircraft_count,
            flight_count=flight_count,
            crew_by_status=dict(crew_by_status),
            aircraft_by_status=dict(aircraft_by_status),
            active_alerts=active_alerts,
            todays_flights=todays_flights,
            vulnerabilities=vulnerabilities,
            completion_factor=completion_factor,
            otp=otp
        )

    # Crew management routes
    @app.route('/crew')
    def crew_overview():
        now = datetime.utcnow()
        crews = Crew.query.all()
        return render_template('crew.html', crews=crews, now=now)
    
    @app.route('/crew/<int:crew_id>')
    def crew_detail(crew_id):
        crew = Crew.query.get_or_404(crew_id)
        
        # Get upcoming flights for this crew member
        now = datetime.utcnow()
        upcoming_flights = Flight.query.join(
            crew_flight, Flight.id == crew_flight.c.flight_id
        ).filter(
            crew_flight.c.crew_id == crew_id,
            Flight.scheduled_departure > now
        ).order_by(Flight.scheduled_departure).all()
        
        return render_template('crew_detail.html', crew=crew, upcoming_flights=upcoming_flights, now=now)

    # Aircraft management routes
    @app.route('/aircraft')
    def aircraft_overview():
        now = datetime.utcnow()
        aircraft = Aircraft.query.all()
        return render_template('aircraft.html', aircraft=aircraft, now=now)
    
    @app.route('/aircraft/<int:aircraft_id>')
    def aircraft_detail(aircraft_id):
        aircraft = Aircraft.query.get_or_404(aircraft_id)
        
        # Get upcoming flights for this aircraft
        now = datetime.utcnow()
        upcoming_flights = Flight.query.filter(
            Flight.aircraft_id == aircraft_id,
            Flight.scheduled_departure > now
        ).order_by(Flight.scheduled_departure).all()
        
        return render_template('aircraft_detail.html', aircraft=aircraft, upcoming_flights=upcoming_flights, now=now)

    # Schedule management routes
    @app.route('/schedule')
    def schedule_overview():
        now = datetime.utcnow()
        start_date = request.args.get('start_date', now.date().isoformat())
        try:
            start_date = datetime.strptime(start_date, '%Y-%m-%d').date()
        except ValueError:
            start_date = now.date()
        
        end_date = start_date + timedelta(days=1)
        
        start_datetime = datetime.combine(start_date, datetime.min.time())
        end_datetime = datetime.combine(end_date, datetime.min.time())
        
        flights = Flight.query.filter(
            Flight.scheduled_departure >= start_datetime,
            Flight.scheduled_departure < end_datetime
        ).order_by(Flight.scheduled_departure).all()
        
        vulnerabilities = analyze_schedule_vulnerabilities(start_date=start_date)
        
        return render_template(
            'schedule.html', 
            flights=flights, 
            start_date=start_date,
            vulnerabilities=vulnerabilities,
            now=now
        )

    # Simulation routes
    @app.route('/simulation')
    def simulation():
        # Get active alerts that might need simulation
        active_alerts = OperationalAlert.query.filter(
            OperationalAlert.resolved_at == None
        ).order_by(OperationalAlert.severity.desc(), OperationalAlert.created_at.desc()).all()
        
        # Get all flights that can be used for simulation
        now = datetime.utcnow()
        upcoming_flights = Flight.query.filter(
            Flight.scheduled_departure > now,
            Flight.scheduled_departure < now + timedelta(days=2)
        ).order_by(Flight.scheduled_departure).all()
        
        # Get all available crew and aircraft for reassignment
        available_crew = Crew.query.filter(
            Crew.status == CREW_STATUS_AVAILABLE
        ).all()
        
        available_aircraft = Aircraft.query.filter(
            Aircraft.status == AIRCRAFT_STATUS_AVAILABLE
        ).all()
        
        return render_template(
            'simulation.html',
            active_alerts=active_alerts,
            upcoming_flights=upcoming_flights,
            available_crew=available_crew,
            available_aircraft=available_aircraft,
            now=now
        )
    
    @app.route('/simulation/run', methods=['POST'])
    def run_simulation():
        now = datetime.utcnow()
        simulation_type = request.form.get('simulation_type')
        flight_id = request.form.get('flight_id')
        delay_minutes = request.form.get('delay_minutes', 0, type=int)
        cancellation_reason = request.form.get('cancellation_reason')
        crew_id = request.form.get('crew_id')
        aircraft_id = request.form.get('aircraft_id')
        
        if not flight_id:
            flash('Flight must be selected for simulation', 'danger')
            return redirect(url_for('simulation'))
        
        flight = Flight.query.get(flight_id)
        if not flight:
            flash('Invalid flight selected', 'danger')
            return redirect(url_for('simulation'))
        
        # Generate decision options based on the simulation
        decision_options = generate_decision_options(
            simulation_type=simulation_type,
            flight=flight,
            delay_minutes=delay_minutes,
            cancellation_reason=cancellation_reason,
            crew_id=crew_id,
            aircraft_id=aircraft_id
        )
        
        # Store simulation results in session for the results page
        session_data = {
            'simulation_type': simulation_type,
            'flight_id': flight_id,
            'decision_options': [
                {
                    'id': i,
                    'type': option['type'],
                    'description': option['description'],
                    'impact_score': option['impact_score'],
                    'cost_impact': option['cost_impact'],
                    'performance_impact': option['performance_impact']
                }
                for i, option in enumerate(decision_options)
            ]
        }
        
        return render_template(
            'simulation_results.html',
            flight=flight,
            simulation_type=simulation_type,
            decision_options=decision_options,
            now=now
        )
    
    @app.route('/simulation/implement', methods=['POST'])
    def implement_simulation():
        decision_id = request.form.get('decision_id', type=int)
        flight_id = request.form.get('flight_id', type=int)
        
        flight = Flight.query.get_or_404(flight_id)
        
        # Implement the selected decision
        success, message = implement_decision(decision_id, flight)
        
        if success:
            flash(f'Decision implemented successfully: {message}', 'success')
        else:
            flash(f'Failed to implement decision: {message}', 'danger')
        
        return redirect(url_for('flight_detail', flight_id=flight_id))

    # History/replay routes
    @app.route('/history')
    def history():
        now = datetime.utcnow()
        # Get past decisions for review
        decisions = OperationalDecision.query.order_by(
            OperationalDecision.created_at.desc()
        ).limit(100).all()
        
        return render_template('history.html', decisions=decisions, now=now)
    
    @app.route('/history/decision/<int:decision_id>')
    def decision_detail(decision_id):
        now = datetime.utcnow()
        decision = OperationalDecision.query.get_or_404(decision_id)
        
        # Get related data
        flight = decision.flight
        crew = decision.crew
        aircraft = decision.aircraft
        
        # Calculate the actual impact if decision was implemented
        if decision.implemented_at:
            # Calculate actual metrics
            actual_impact = evaluate_decision(decision)
        else:
            actual_impact = None
        
        return render_template(
            'decision_detail.html',
            decision=decision,
            flight=flight,
            crew=crew,
            aircraft=aircraft,
            actual_impact=actual_impact,
            now=now
        )

    # Alerts routes
    @app.route('/alerts')
    def alerts():
        now = datetime.utcnow()
        active_alerts = OperationalAlert.query.filter(
            OperationalAlert.resolved_at == None
        ).order_by(OperationalAlert.severity.desc(), OperationalAlert.created_at.desc()).all()
        
        resolved_alerts = OperationalAlert.query.filter(
            OperationalAlert.resolved_at != None
        ).order_by(OperationalAlert.resolved_at.desc()).limit(50).all()
        
        return render_template(
            'alerts.html',
            active_alerts=active_alerts,
            resolved_alerts=resolved_alerts,
            now=now
        )
    
    @app.route('/alerts/<int:alert_id>/resolve', methods=['POST'])
    def resolve_alert(alert_id):
        alert = OperationalAlert.query.get_or_404(alert_id)
        resolution_notes = request.form.get('resolution_notes', '')
        
        alert.resolved_at = datetime.utcnow()
        alert.resolution_notes = resolution_notes
        db.session.commit()
        
        flash('Alert marked as resolved', 'success')
        return redirect(url_for('alerts'))

    # API routes for AJAX calls
    @app.route('/api/alerts')
    def api_alerts():
        active_alerts = OperationalAlert.query.filter(
            OperationalAlert.resolved_at == None
        ).order_by(OperationalAlert.severity.desc(), OperationalAlert.created_at.desc()).limit(5).all()
        
        alert_data = []
        for alert in active_alerts:
            alert_data.append({
                'id': alert.id,
                'type': alert.alert_type,
                'description': alert.description,
                'severity': alert.severity,
                'time': alert.created_at.strftime('%H:%M:%S')
            })
        
        return jsonify({'alerts': alert_data})
        
    @app.route('/api/crew-availability')
    def api_crew_availability():
        date_str = request.args.get('date')
        try:
            if date_str:
                date = datetime.strptime(date_str, '%Y-%m-%d').date()
            else:
                date = datetime.utcnow().date()
        except ValueError:
            date = datetime.utcnow().date()
        
        availability = get_crew_availability(date)
        return jsonify(availability)
    
    @app.route('/api/aircraft-availability')
    def api_aircraft_availability():
        date_str = request.args.get('date')
        try:
            if date_str:
                date = datetime.strptime(date_str, '%Y-%m-%d').date()
            else:
                date = datetime.utcnow().date()
        except ValueError:
            date = datetime.utcnow().date()
        
        availability = get_aircraft_availability(date)
        return jsonify(availability)
    
    @app.route('/api/schedule-risk')
    def api_schedule_risk():
        flight_id = request.args.get('flight_id', type=int)
        
        if not flight_id:
            return jsonify({'error': 'Flight ID is required'}), 400
        
        flight = Flight.query.get(flight_id)
        if not flight:
            return jsonify({'error': 'Flight not found'}), 404
        
        risk_score = calculate_risk_score(flight)
        
        return jsonify({
            'flight_id': flight_id,
            'risk_score': risk_score['score'],
            'risk_factors': risk_score['factors']
        })
    
    @app.route('/api/flights-status')
    def api_flights_status():
        flight_ids = request.args.get('ids', '')
        if not flight_ids:
            return jsonify({'error': 'No flight IDs provided'}), 400
            
        flight_ids = [int(id) for id in flight_ids.split(',') if id.strip().isdigit()]
        if not flight_ids:
            return jsonify({'error': 'Invalid flight IDs'}), 400
            
        flights = Flight.query.filter(Flight.id.in_(flight_ids)).all()
        
        flight_data = []
        for flight in flights:
            flight_data.append({
                'id': flight.id,
                'status': flight.status,
                'departure': flight.scheduled_departure.strftime('%H:%M') if flight.scheduled_departure else '',
                'arrival': flight.scheduled_arrival.strftime('%H:%M') if flight.scheduled_arrival else ''
            })
        
        return jsonify({'flights': flight_data})

    # Error handlers
    @app.errorhandler(404)
    def page_not_found(e):
        now = datetime.utcnow()
        return render_template('error.html', now=now, error_code=404, error_message="Page not found"), 404
    
    @app.errorhandler(500)
    def server_error(e):
        now = datetime.utcnow()
        return render_template('error.html', now=now, error_code=500, error_message="Internal server error"), 500
