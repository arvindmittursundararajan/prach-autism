/**
 * Polish Airlines Operations Management System
 * Dashboard JavaScript
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize any charts if they exist on the page
    initializeCharts();
    
    // Setup auto-refresh for data that needs to be updated
    setupAutoRefresh();
    
    // Add event listeners for interactive elements
    setupEventListeners();
});

/**
 * Initialize charts on the dashboard
 */
function initializeCharts() {
    // Crew Status Chart
    const crewStatusCtx = document.getElementById('crewStatusChart');
    if (crewStatusCtx) {
        // Get data from data attributes
        const available = parseInt(crewStatusCtx.dataset.available || 0);
        const onDuty = parseInt(crewStatusCtx.dataset.onDuty || 0);
        const rest = parseInt(crewStatusCtx.dataset.rest || 0);
        const other = parseInt(crewStatusCtx.dataset.other || 0);
        
        new Chart(crewStatusCtx, {
            type: 'doughnut',
            data: {
                labels: ['Available', 'On Duty', 'Rest', 'Other'],
                datasets: [{
                    data: [available, onDuty, rest, other],
                    backgroundColor: ['#28A745', '#304CB2', '#FFBF27', '#CCCCCC'],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                legend: {
                    position: 'bottom'
                },
                title: {
                    display: true,
                    text: 'Crew Status Distribution'
                },
                layout: {
                    padding: {
                        bottom: 10
                    }
                }
            }
        });
    }
    
    // Aircraft Status Chart
    const aircraftStatusCtx = document.getElementById('aircraftStatusChart');
    if (aircraftStatusCtx) {
        // Get data from data attributes
        const available = parseInt(aircraftStatusCtx.dataset.available || 0);
        const inFlight = parseInt(aircraftStatusCtx.dataset.inFlight || 0);
        const maintenance = parseInt(aircraftStatusCtx.dataset.maintenance || 0);
        const other = parseInt(aircraftStatusCtx.dataset.other || 0);
        
        new Chart(aircraftStatusCtx, {
            type: 'doughnut',
            data: {
                labels: ['Available', 'In Flight', 'Maintenance', 'Other'],
                datasets: [{
                    data: [available, inFlight, maintenance, other],
                    backgroundColor: ['#28A745', '#304CB2', '#D5152E', '#CCCCCC'],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                legend: {
                    position: 'bottom'
                },
                title: {
                    display: true,
                    text: 'Aircraft Status Distribution'
                },
                layout: {
                    padding: {
                        bottom: 10
                    }
                }
            }
        });
    }
    
    // Performance Metrics Chart
    const performanceCtx = document.getElementById('performanceChart');
    if (performanceCtx) {
        // Get data from data attributes
        const completionFactor = parseFloat(performanceCtx.dataset.completionFactor || 0);
        const otp = parseFloat(performanceCtx.dataset.otp || 0);
        
        new Chart(performanceCtx, {
            type: 'bar',
            data: {
                labels: ['Completion Factor', 'On-Time Performance'],
                datasets: [{
                    data: [completionFactor, otp],
                    backgroundColor: ['#304CB2', '#FFBF27'],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                legend: {
                    display: false
                },
                title: {
                    display: true,
                    text: 'Key Performance Indicators (%)'
                },
                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero: true,
                            max: 100
                        }
                    }]
                },
                layout: {
                    padding: {
                        bottom: 10
                    }
                }
            }
        });
    }
}

/**
 * Setup auto-refresh for parts of the dashboard that need real-time updates
 */
function setupAutoRefresh() {
    // Auto-refresh alerts every 60 seconds
    if (document.getElementById('alertsPanel')) {
        setInterval(refreshAlerts, 60000);
    }
    
    // Auto-refresh flight status every 2 minutes
    if (document.getElementById('flightsTable')) {
        setInterval(refreshFlightStatus, 120000);
    }
}

/**
 * Refresh alerts via AJAX
 */
function refreshAlerts() {
    fetch('/api/alerts')
        .then(response => response.json())
        .then(data => {
            const alertsPanel = document.getElementById('alertsPanel');
            if (alertsPanel && data.alerts && data.alerts.length > 0) {
                let alertsHtml = '';
                
                data.alerts.forEach(alert => {
                    alertsHtml += `
                        <div class="alert-item ${alert.severity}">
                            <div class="d-flex justify-content-between">
                                <strong>${alert.type}</strong>
                                <span class="badge badge-${getSeverityClass(alert.severity)}">${alert.severity}</span>
                            </div>
                            <p class="mb-1">${alert.description}</p>
                            <small class="text-muted">${alert.time}</small>
                        </div>
                    `;
                });
                
                alertsPanel.innerHTML = alertsHtml;
            }
        })
        .catch(error => console.error('Error refreshing alerts:', error));
}

/**
 * Refresh flight status via AJAX
 */
function refreshFlightStatus() {
    const flightsTable = document.getElementById('flightsTable');
    if (!flightsTable) return;
    
    const flightIds = flightsTable.dataset.flightIds;
    if (!flightIds) return;
    
    fetch(`/api/flights-status?ids=${flightIds}`)
        .then(response => response.json())
        .then(data => {
            if (data.flights) {
                data.flights.forEach(flight => {
                    const statusCell = document.getElementById(`flight-status-${flight.id}`);
                    if (statusCell) {
                        statusCell.innerHTML = `
                            <span class="status-badge ${flight.status.toLowerCase()}">${flight.status}</span>
                        `;
                    }
                    
                    const departureCell = document.getElementById(`flight-departure-${flight.id}`);
                    if (departureCell) {
                        departureCell.textContent = flight.departure;
                    }
                    
                    const arrivalCell = document.getElementById(`flight-arrival-${flight.id}`);
                    if (arrivalCell) {
                        arrivalCell.textContent = flight.arrival;
                    }
                });
            }
        })
        .catch(error => console.error('Error refreshing flight status:', error));
}

/**
 * Setup event listeners for interactive elements
 */
function setupEventListeners() {
    // Flight detail modals
    const flightDetailLinks = document.querySelectorAll('.flight-detail-link');
    flightDetailLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const flightId = this.dataset.flightId;
            openFlightDetailModal(flightId);
        });
    });
    
    // Risk score tooltips
    const riskScores = document.querySelectorAll('.risk-score');
    riskScores.forEach(score => {
        score.addEventListener('mouseenter', function() {
            const flightId = this.dataset.flightId;
            loadRiskFactors(flightId, this);
        });
    });
}

/**
 * Load risk factors for a flight
 */
function loadRiskFactors(flightId, element) {
    fetch(`/api/schedule-risk?flight_id=${flightId}`)
        .then(response => response.json())
        .then(data => {
            let tooltipContent = '<strong>Risk Factors:</strong><ul>';
            
            if (data.risk_factors && data.risk_factors.length > 0) {
                data.risk_factors.forEach(factor => {
                    tooltipContent += `<li>${factor}</li>`;
                });
            } else {
                tooltipContent += '<li>No risk factors identified</li>';
            }
            
            tooltipContent += '</ul>';
            
            // Initialize or update tooltip
            if (element._tippy) {
                element._tippy.setContent(tooltipContent);
            } else if (window.tippy) {
                tippy(element, { 
                    content: tooltipContent,
                    allowHTML: true,
                    placement: 'right'
                });
            } else {
                // Fallback if tippy.js is not available
                element.title = data.risk_factors.join(', ') || 'No risk factors';
            }
        })
        .catch(error => console.error('Error loading risk factors:', error));
}

/**
 * Open flight detail modal
 */
function openFlightDetailModal(flightId) {
    // This would typically load flight details via AJAX and show in a modal
    // For this simplified version, we'll just redirect to a flight detail page
    window.location.href = `/flight/${flightId}`;
}

/**
 * Helper function to map severity to Bootstrap class
 */
function getSeverityClass(severity) {
    switch (severity.toLowerCase()) {
        case 'critical':
            return 'danger';
        case 'high':
            return 'warning';
        case 'medium':
            return 'primary';
        case 'low':
            return 'info';
        default:
            return 'secondary';
    }
}
