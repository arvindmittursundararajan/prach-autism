from datetime import datetime
from app import db

# Crew status constants
CREW_STATUS_AVAILABLE = 'available'
CREW_STATUS_ON_DUTY = 'on_duty'
CREW_STATUS_REST = 'rest'
CREW_STATUS_TRAINING = 'training'
CREW_STATUS_SICK = 'sick'
CREW_STATUS_VACATION = 'vacation'

# Aircraft status constants
AIRCRAFT_STATUS_AVAILABLE = 'available'
AIRCRAFT_STATUS_IN_FLIGHT = 'in_flight'
AIRCRAFT_STATUS_MAINTENANCE = 'maintenance'
AIRCRAFT_STATUS_GROUNDED = 'grounded'

# Flight status constants
FLIGHT_STATUS_SCHEDULED = 'scheduled'
FLIGHT_STATUS_DELAYED = 'delayed'
FLIGHT_STATUS_CANCELLED = 'cancelled'
FLIGHT_STATUS_COMPLETED = 'completed'
FLIGHT_STATUS_BOARDING = 'boarding'
FLIGHT_STATUS_IN_AIR = 'in_air'
FLIGHT_STATUS_DIVERTED = 'diverted'

# Alert severity constants
ALERT_SEVERITY_LOW = 'low'
ALERT_SEVERITY_MEDIUM = 'medium'
ALERT_SEVERITY_HIGH = 'high'
ALERT_SEVERITY_CRITICAL = 'critical'

# Crew position constants
CREW_POSITION_CAPTAIN = 'captain'
CREW_POSITION_FIRST_OFFICER = 'first_officer'
CREW_POSITION_FLIGHT_ATTENDANT = 'flight_attendant'
CREW_POSITION_PURSER = 'purser'

# Crew-Flight association table
crew_flight = db.Table('crew_flight',
    db.Column('crew_id', db.Integer, db.ForeignKey('crew.id'), primary_key=True),
    db.Column('flight_id', db.Integer, db.ForeignKey('flight.id'), primary_key=True),
    db.Column('position', db.String(20), nullable=False)
)

class Crew(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    employee_id = db.Column(db.String(10), unique=True, nullable=False)
    first_name = db.Column(db.String(50), nullable=False)
    last_name = db.Column(db.String(50), nullable=False)
    position = db.Column(db.String(20), nullable=False)  # captain, first_officer, flight_attendant, purser
    status = db.Column(db.String(20), nullable=False, default=CREW_STATUS_AVAILABLE)
    base_airport_id = db.Column(db.Integer, db.ForeignKey('airport.id'))
    qualification = db.Column(db.String(50))  # aircraft type qualification
    hours_flown = db.Column(db.Integer, default=0)
    rest_hours_required = db.Column(db.Integer, default=12)
    flight_duty_period = db.Column(db.Integer, default=0)  # current duty period in hours
    contact_number = db.Column(db.String(20))
    email = db.Column(db.String(100))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    base_airport = db.relationship('Airport', backref='based_crew')
    flights = db.relationship('Flight', secondary=crew_flight, back_populates='assigned_crew')
    
    def __repr__(self):
        return f"<Crew {self.employee_id}: {self.first_name} {self.last_name}>"

class Aircraft(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    registration = db.Column(db.String(10), unique=True, nullable=False)
    aircraft_type = db.Column(db.String(30), nullable=False)
    status = db.Column(db.String(20), nullable=False, default=AIRCRAFT_STATUS_AVAILABLE)
    seat_capacity = db.Column(db.Integer, nullable=False)
    current_airport_id = db.Column(db.Integer, db.ForeignKey('airport.id'))
    maintenance_due_hours = db.Column(db.Integer, default=0)
    total_flight_hours = db.Column(db.Integer, default=0)
    fuel_capacity = db.Column(db.Integer)  # in liters
    current_fuel = db.Column(db.Integer)  # in liters
    manufacturing_date = db.Column(db.Date)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    current_airport = db.relationship('Airport', backref='stationed_aircraft')
    flights = db.relationship('Flight', backref='aircraft')
    
    def __repr__(self):
        return f"<Aircraft {self.registration}: {self.aircraft_type}>"

class Airport(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(3), unique=True, nullable=False)
    name = db.Column(db.String(100), nullable=False)
    city = db.Column(db.String(50), nullable=False)
    country = db.Column(db.String(50), nullable=False)
    timezone = db.Column(db.String(50))
    gate_capacity = db.Column(db.Integer)
    staff_count = db.Column(db.Integer)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships in other models: based_crew, stationed_aircraft, departure_flights, arrival_flights
    
    def __repr__(self):
        return f"<Airport {self.code}: {self.name}>"

class Flight(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    flight_number = db.Column(db.String(10), nullable=False)
    departure_airport_id = db.Column(db.Integer, db.ForeignKey('airport.id'), nullable=False)
    arrival_airport_id = db.Column(db.Integer, db.ForeignKey('airport.id'), nullable=False)
    scheduled_departure = db.Column(db.DateTime, nullable=False)
    scheduled_arrival = db.Column(db.DateTime, nullable=False)
    actual_departure = db.Column(db.DateTime)
    actual_arrival = db.Column(db.DateTime)
    status = db.Column(db.String(20), nullable=False, default=FLIGHT_STATUS_SCHEDULED)
    aircraft_id = db.Column(db.Integer, db.ForeignKey('aircraft.id'))
    estimated_fuel = db.Column(db.Integer)  # in liters
    passenger_count = db.Column(db.Integer, default=0)
    distance = db.Column(db.Integer)  # in kilometers
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    departure_airport = db.relationship('Airport', foreign_keys=[departure_airport_id], backref='departure_flights')
    arrival_airport = db.relationship('Airport', foreign_keys=[arrival_airport_id], backref='arrival_flights')
    assigned_crew = db.relationship('Crew', secondary=crew_flight, back_populates='flights')
    
    def __repr__(self):
        return f"<Flight {self.flight_number}: {self.departure_airport.code} to {self.arrival_airport.code}>"

class Schedule(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    crew_id = db.Column(db.Integer, db.ForeignKey('crew.id'))
    flight_id = db.Column(db.Integer, db.ForeignKey('flight.id'))
    duty_start = db.Column(db.DateTime, nullable=False)
    duty_end = db.Column(db.DateTime, nullable=False)
    position = db.Column(db.String(20), nullable=False)
    is_reserve = db.Column(db.Boolean, default=False)
    remarks = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    crew = db.relationship('Crew', backref='schedule')
    flight = db.relationship('Flight', backref='crew_schedule')
    
    def __repr__(self):
        return f"<Schedule: {self.crew.employee_id} on {self.flight.flight_number}>"

class OperationalAlert(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    alert_type = db.Column(db.String(50), nullable=False)
    description = db.Column(db.Text, nullable=False)
    severity = db.Column(db.String(20), nullable=False)
    flight_id = db.Column(db.Integer, db.ForeignKey('flight.id'))
    crew_id = db.Column(db.Integer, db.ForeignKey('crew.id'))
    aircraft_id = db.Column(db.Integer, db.ForeignKey('aircraft.id'))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    resolved_at = db.Column(db.DateTime)
    resolution_notes = db.Column(db.Text)
    
    # Relationships
    flight = db.relationship('Flight', backref='alerts')
    crew = db.relationship('Crew', backref='alerts')
    aircraft = db.relationship('Aircraft', backref='alerts')
    
    def __repr__(self):
        return f"<Alert {self.id}: {self.alert_type} ({self.severity})>"

class OperationalDecision(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    decision_type = db.Column(db.String(50), nullable=False)
    description = db.Column(db.Text, nullable=False)
    flight_id = db.Column(db.Integer, db.ForeignKey('flight.id'))
    crew_id = db.Column(db.Integer, db.ForeignKey('crew.id'))
    aircraft_id = db.Column(db.Integer, db.ForeignKey('aircraft.id'))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    implemented_at = db.Column(db.DateTime)
    impact_score = db.Column(db.Integer)  # 1-100 score of decision effectiveness
    cost_impact = db.Column(db.Float)  # monetary impact
    performance_impact = db.Column(db.Text)  # impact on KPIs
    made_by = db.Column(db.String(100))  # user or system
    
    # Relationships
    flight = db.relationship('Flight', backref='decisions')
    crew = db.relationship('Crew', backref='impacted_decisions')
    aircraft = db.relationship('Aircraft', backref='impacted_decisions')
    
    def __repr__(self):
        return f"<Decision {self.id}: {self.decision_type}>"
